"""
FEM (Focus-Exposure Matrix) Analysis Routes
API endpoints for FEM analysis functionality
"""

from flask import Blueprint, request, jsonify, send_file, current_app
from werkzeug.utils import secure_filename
import os
import numpy as np
from app.services.fem_service import FEMService
from app.utils.file_handler import allowed_file, save_upload_file

fem_bp = Blueprint('fem', __name__)
fem_service = FEMService()


@fem_bp.route('/upload', methods=['POST'])
def upload_fem_data():
    """
    Upload FEM data CSV file.
    
    Expected CSV format:
    exposure_dose,focus,critical_dimension
    
    Returns:
    --------
    JSON response with file info and data preview
    """
    try:
        # Check if file is present
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename, current_app.config['ALLOWED_EXTENSIONS']):
            return jsonify({
                'error': 'Invalid file type. Allowed: CSV, TXT, XLSX'
            }), 400
        
        # Save file
        filename = secure_filename(file.filename)
        filepath = save_upload_file(
            file,
            filename,
            current_app.config['UPLOAD_FOLDER']
        )
        
        # Read and validate data
        import pandas as pd
        data = pd.read_csv(filepath)
        
        # Validate required columns
        required_cols = ['exposure_dose', 'focus', 'critical_dimension']
        missing_cols = [col for col in required_cols if col not in data.columns]
        
        if missing_cols:
            return jsonify({
                'error': f'Missing required columns: {", ".join(missing_cols)}',
                'required': required_cols,
                'found': list(data.columns)
            }), 400
        
        # Get data summary
        summary = {
            'filename': filename,
            'filepath': filepath,
            'rows': len(data),
            'columns': list(data.columns),
            'exposure_range': {
                'min': float(data['exposure_dose'].min()),
                'max': float(data['exposure_dose'].max()),
                'unique': int(data['exposure_dose'].nunique())
            },
            'focus_range': {
                'min': float(data['focus'].min()),
                'max': float(data['focus'].max()),
                'unique': int(data['focus'].nunique())
            },
            'cd_range': {
                'min': float(data['critical_dimension'].min()),
                'max': float(data['critical_dimension'].max()),
                'mean': float(data['critical_dimension'].mean()),
                'std': float(data['critical_dimension'].std())
            },
            'preview': data.head(10).to_dict('records')
        }
        
        return jsonify({
            'success': True,
            'message': 'File uploaded successfully',
            'data': summary
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Upload failed: {str(e)}'}), 500


@fem_bp.route('/analyze', methods=['POST'])
def analyze_fem():
    """
    Analyze FEM data and calculate process window metrics.
    
    Request JSON:
    {
        "filepath": "path/to/data.csv",
        "pattern_name": "Dense_250nm",
        "target_cd": 250.0,
        "cd_tolerance": 0.10
    }
    
    Returns:
    --------
    JSON response with analysis results and chart data
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        filepath = data.get('filepath')
        pattern_name = data.get('pattern_name', 'default')
        target_cd = data.get('target_cd', 250.0)
        cd_tolerance = data.get('cd_tolerance', 0.10)
        
        if not filepath or not os.path.exists(filepath):
            return jsonify({'error': 'Invalid file path'}), 400
        
        # Perform analysis
        results = fem_service.analyze_fem_data(
            filepath=filepath,
            pattern_name=pattern_name,
            target_cd=target_cd,
            cd_tolerance=cd_tolerance
        )
        
        if not results['success']:
            return jsonify({'error': results['error']}), 500
        
        return jsonify({
            'success': True,
            'results': results
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500


@fem_bp.route('/generate-mock-data', methods=['POST'])
def generate_mock_data():
    """
    Generate mock FEM data for testing.
    
    Request JSON:
    {
        "pattern_type": "dense",  # line, contact, via, dense, isolated
        "target_cd": 250.0
    }
    
    Returns:
    --------
    JSON response with generated data info
    """
    try:
        data = request.get_json() or {}
        
        pattern_type = data.get('pattern_type', 'dense')
        target_cd = data.get('target_cd', 250.0)
        
        # Generate mock data
        upload_folder = current_app.config['UPLOAD_FOLDER']
        result = fem_service.generate_mock_data(
            pattern_type=pattern_type,
            target_cd=target_cd,
            output_folder=upload_folder
        )
        
        if not result['success']:
            return jsonify({'error': result['error']}), 500
        
        return jsonify({
            'success': True,
            'message': 'Mock data generated successfully',
            'data': result
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Mock data generation failed: {str(e)}'}), 500


@fem_bp.route('/generate-plots', methods=['POST'])
def generate_plots():
    """
    Generate FEM visualization plots.
    
    Request JSON:
    {
        "pattern_name": "Dense_250nm",
        "target_cd": 250.0,
        "cd_tolerance": 0.10,
        "plot_types": ["contour", "process_window", "dof_el"]
    }
    
    Returns:
    --------
    JSON response with plot file paths
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        pattern_name = data.get('pattern_name', 'default')
        target_cd = data.get('target_cd', 250.0)
        cd_tolerance = data.get('cd_tolerance', 0.10)
        plot_types = data.get('plot_types', ['contour', 'process_window', 'dof_el'])
        
        # Generate plots
        output_folder = current_app.config['OUTPUT_FOLDER']
        result = fem_service.generate_visualizations(
            pattern_name=pattern_name,
            target_cd=target_cd,
            cd_tolerance=cd_tolerance,
            output_folder=output_folder,
            plot_types=plot_types
        )
        
        if not result['success']:
            return jsonify({'error': result['error']}), 500
        
        return jsonify({
            'success': True,
            'plots': result['plots']
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Plot generation failed: {str(e)}'}), 500


@fem_bp.route('/compare-patterns', methods=['POST'])
def compare_patterns():
    """
    Compare multiple loaded patterns.
    
    Request JSON:
    {
        "target_cd": 250.0,
        "cd_tolerance": 0.10
    }
    
    Returns:
    --------
    JSON response with comparison results
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        target_cd = data.get('target_cd', 250.0)
        cd_tolerance = data.get('cd_tolerance', 0.10)
        
        # Compare patterns
        result = fem_service.compare_patterns(
            target_cd=target_cd,
            cd_tolerance=cd_tolerance
        )
        
        if not result['success']:
            return jsonify({'error': result['error']}), 500
        
        return jsonify({
            'success': True,
            'comparison': result
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Comparison failed: {str(e)}'}), 500


@fem_bp.route('/patterns', methods=['GET'])
def list_patterns():
    """
    Get list of loaded patterns.
    
    Returns:
    --------
    JSON response with pattern list
    """
    try:
        patterns = fem_service.get_pattern_list()
        
        return jsonify({
            'success': True,
            'patterns': patterns,
            'count': len(patterns)
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Failed to list patterns: {str(e)}'}), 500


@fem_bp.route('/download/<filename>', methods=['GET'])
def download_file(filename):
    """
    Download generated plot or data file.
    
    Parameters:
    -----------
    filename : str
        Name of file to download
    
    Returns:
    --------
    File download
    """
    try:
        output_folder = current_app.config['OUTPUT_FOLDER']
        filepath = os.path.join(output_folder, secure_filename(filename))
        
        if not os.path.exists(filepath):
            return jsonify({'error': 'File not found'}), 404
        
        return send_file(filepath, as_attachment=True)
        
    except Exception as e:
        return jsonify({'error': f'Download failed: {str(e)}'}), 500


@fem_bp.route('/clear', methods=['POST'])
def clear_patterns():
    """
    Clear all loaded patterns.
    
    Returns:
    --------
    JSON response with success message
    """
    try:
        fem_service.clear_patterns()
        
        return jsonify({
            'success': True,
            'message': 'All patterns cleared'
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Clear failed: {str(e)}'}), 500


@fem_bp.route('/advanced-analysis', methods=['POST'])
def advanced_analysis():
    """
    Perform advanced FEM analysis including:
    - Bossung curves
    - Iso-focal point detection
    - DOF at EL% calculation
    - Inscribed rectangle
    - Process robustness score
    - OPC bias recommendation
    
    Request JSON:
    {
        "pattern_name": "Dense_250nm",
        "target_cd": 250.0,
        "cd_tolerance": 0.10
    }
    
    Returns:
    --------
    JSON response with advanced analysis results
    """
    try:
        from app.services.fem_advanced import AdvancedFEMAnalyzer
        from shapely.geometry import Polygon
        
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        pattern_name = data.get('pattern_name', 'default')
        target_cd = data.get('target_cd', 250.0)
        cd_tolerance = data.get('cd_tolerance', 0.10)
        
        # Get FEM matrix
        fem_matrix = fem_service.processor.get_matrix(pattern_name)
        if fem_matrix is None:
            return jsonify({'error': f'Pattern {pattern_name} not found'}), 404
        
        # Initialize advanced analyzer
        analyzer = AdvancedFEMAnalyzer()
        
        # Generate Bossung curves
        bossung_data = analyzer.generate_bossung_curves(fem_matrix)
        
        # Calculate DOF at EL%
        dof_at_el = analyzer.calculate_dof_at_el(
            fem_matrix,
            target_cd,
            cd_tolerance,
            el_percentages=[5, 10, 15, 20]
        )
        
        # Get process window and optimal point
        process_window = fem_service.processor.extract_process_window(
            pattern_name,
            target_cd,
            cd_tolerance
        )
        
        dof_el = fem_service.processor.calculate_dof_el(
            pattern_name,
            target_cd,
            cd_tolerance
        )
        
        optimal_point = fem_service.processor.get_optimal_point(
            pattern_name,
            target_cd,
            cd_tolerance
        )
        
        # Calculate inscribed rectangle (if process window found)
        inscribed_rect = {'found': False}
        if process_window.get('found', False):
            inscribed_rect = analyzer.find_inscribed_rectangle(
                process_window,
                (float(fem_matrix.focus_values.min()), float(fem_matrix.focus_values.max())),
                (float(fem_matrix.exposure_values.min()), float(fem_matrix.exposure_values.max()))
            )
        
        # Calculate process robustness score
        robustness = analyzer.calculate_process_robustness_score(
            process_window,
            dof_el,
            optimal_point
        )
        
        # OPC bias recommendation
        opc_bias = analyzer.recommend_opc_bias(optimal_point, target_cd)
        
        return jsonify({
            'success': True,
            'advanced_metrics': {
                'bossung_curves': bossung_data,
                'dof_at_el': dof_at_el,
                'inscribed_rectangle': inscribed_rect,
                'process_robustness_score': robustness,
                'opc_bias_recommendation': opc_bias
            }
        }), 200
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Advanced analysis failed: {str(e)}'}), 500
