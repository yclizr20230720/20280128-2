"""
Authentication routes - Login, Register, User management
"""
from flask import Blueprint, request, jsonify
from app.models.user import UserModel
from app.utils.auth import generate_token, token_required, admin_required

auth_bp = Blueprint('auth', __name__)
user_model = UserModel()

@auth_bp.route('/register', methods=['POST'])
def register():
    """Register a new user"""
    try:
        data = request.get_json()
        
        # Validate input
        required_fields = ['username', 'email', 'password']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'{field} is required'}), 400
        
        username = data['username'].strip()
        email = data['email'].strip()
        password = data['password']
        
        # Validate username
        if len(username) < 3:
            return jsonify({'error': 'Username must be at least 3 characters'}), 400
        
        # Validate email
        if '@' not in email:
            return jsonify({'error': 'Invalid email format'}), 400
        
        # Validate password
        if len(password) < 6:
            return jsonify({'error': 'Password must be at least 6 characters'}), 400
        
        # Create user
        user_data, error = user_model.create_user(username, email, password, role='user')
        
        if error:
            return jsonify({'error': error}), 400
        
        # Generate token
        token = generate_token(user_data)
        
        return jsonify({
            'success': True,
            'message': 'User registered successfully',
            'user': user_data,
            'token': token
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    """Login user"""
    try:
        data = request.get_json()
        
        # Validate input
        if 'username' not in data or 'password' not in data:
            return jsonify({'error': 'Username and password are required'}), 400
        
        username = data['username'].strip()
        password = data['password']
        
        # Authenticate user
        user_data, error = user_model.authenticate(username, password)
        
        if error:
            return jsonify({'error': error}), 401
        
        # Generate token
        token = generate_token(user_data)
        
        return jsonify({
            'success': True,
            'message': 'Login successful',
            'user': user_data,
            'token': token
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/me', methods=['GET'])
@token_required
def get_current_user():
    """Get current user info"""
    try:
        username = request.user['username']
        user_data = user_model.get_user(username)
        
        if not user_data:
            return jsonify({'error': 'User not found'}), 404
        
        return jsonify({
            'success': True,
            'user': user_data
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/users', methods=['GET'])
@admin_required
def get_all_users():
    """Get all users (admin only)"""
    try:
        users = user_model.get_all_users()
        
        return jsonify({
            'success': True,
            'users': users,
            'count': len(users)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/users/<username>', methods=['PUT'])
@admin_required
def update_user(username):
    """Update user (admin only)"""
    try:
        data = request.get_json()
        
        user_data, error = user_model.update_user(username, **data)
        
        if error:
            return jsonify({'error': error}), 400
        
        return jsonify({
            'success': True,
            'message': 'User updated successfully',
            'user': user_data
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/users/<username>', methods=['DELETE'])
@admin_required
def delete_user(username):
    """Delete user (admin only)"""
    try:
        success, error = user_model.delete_user(username)
        
        if error:
            return jsonify({'error': error}), 400
        
        return jsonify({
            'success': True,
            'message': 'User deleted successfully'
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/change-password', methods=['POST'])
@token_required
def change_password():
    """Change user password"""
    try:
        data = request.get_json()
        username = request.user['username']
        
        if 'current_password' not in data or 'new_password' not in data:
            return jsonify({'error': 'Current and new password are required'}), 400
        
        # Verify current password
        user_data, error = user_model.authenticate(username, data['current_password'])
        
        if error:
            return jsonify({'error': 'Current password is incorrect'}), 401
        
        # Validate new password
        if len(data['new_password']) < 6:
            return jsonify({'error': 'New password must be at least 6 characters'}), 400
        
        # Update password
        user_data, error = user_model.update_user(username, password=data['new_password'])
        
        if error:
            return jsonify({'error': error}), 400
        
        return jsonify({
            'success': True,
            'message': 'Password changed successfully'
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500
