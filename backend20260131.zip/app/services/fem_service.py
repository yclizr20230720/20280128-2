"""
FEM (Focus-Exposure Matrix) Analysis Service
Integrates FEM analysis capabilities into VSMC Litho Platform
"""

import os
import sys
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Dict, List, Optional, Tuple

# Add FEM module to path
FEM_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), 'FEM')
if FEM_PATH not in sys.path:
    sys.path.insert(0, FEM_PATH)

from fem_processor import FEMProcessor, FEMMatrix, PatternInfo, MultiPatternAnalyzer
from fem_visualizer import FEMVisualizer
from fem_data_generator import FEMDataGenerator


class FEMService:
    """
    Service for FEM analysis operations.
    
    Provides high-level interface for FEM analysis including:
    - Data loading and processing
    - Process window analysis
    - Optimal point detection
    - Multi-pattern comparison
    - Visualization generation
    """
    
    def __init__(self):
        """Initialize FEM service."""
        self.processor = FEMProcessor()
        self.visualizer = FEMVisualizer(dpi=300)
        self.generator = FEMDataGenerator(seed=42)
    
    def analyze_fem_data(self,
                        filepath: str,
                        pattern_name: str = 'default',
                        target_cd: float = 250.0,
                        cd_tolerance: float = 0.10) -> Dict:
        """
        Analyze FEM data from CSV file with advanced metrics.
        
        Args:
            filepath: Path to CSV file
            pattern_name: Name for this pattern
            target_cd: Target CD in nm
            cd_tolerance: CD tolerance as fraction
            
        Returns:
            Dictionary with comprehensive analysis results
        """
        try:
            # Load data
            pattern_info = PatternInfo(
                name=pattern_name,
                pattern_type='unknown',
                target_cd=target_cd,
                cd_tolerance=cd_tolerance
            )
            
            fem_matrix = self.processor.load_matrix_from_csv(
                filepath,
                pattern_name=pattern_name,
                pattern_info=pattern_info
            )
            
            # Get matrix statistics
            stats = fem_matrix.get_statistics()
            
            # Extract process window
            process_window = self.processor.extract_process_window(
                pattern_name=pattern_name,
                target_cd=target_cd,
                tolerance=cd_tolerance
            )
            
            # Calculate DOF/EL
            dof_el = self.processor.calculate_dof_el(
                pattern_name=pattern_name,
                target_cd=target_cd,
                tolerance=cd_tolerance
            )
            
            # Find optimal point
            optimal_point = self.processor.get_optimal_point(
                pattern_name=pattern_name,
                target_cd=target_cd,
                tolerance=cd_tolerance
            )
            
            # Advanced analysis
            advanced_metrics = self._calculate_advanced_metrics(
                fem_matrix,
                target_cd,
                cd_tolerance,
                process_window,
                dof_el
            )
            
            # Get chart data for web visualization
            chart_data = self._generate_chart_data(
                fem_matrix,
                target_cd,
                cd_tolerance
            )
            
            # Bossung curves data
            bossung_data = self._generate_bossung_data(fem_matrix, target_cd)
            
            # DOF at EL data
            dof_at_el_data = self._calculate_dof_at_el(
                fem_matrix,
                target_cd,
                cd_tolerance,
                el_percentages=[5, 10, 15, 20]
            )
            
            return {
                'success': True,
                'pattern_name': pattern_name,
                'statistics': stats,
                'process_window': process_window,
                'dof_el': dof_el,
                'optimal_point': optimal_point,
                'advanced_metrics': advanced_metrics,
                'chart_data': chart_data,
                'bossung_data': bossung_data,
                'dof_at_el': dof_at_el_data,
                'matrix_shape': fem_matrix.get_shape()
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def generate_mock_data(self,
                          pattern_type: str = 'dense',
                          target_cd: float = 250.0,
                          output_folder: str = None) -> Dict:
        """
        Generate mock FEM data for testing.
        
        Args:
            pattern_type: Type of pattern ('line', 'contact', 'via', 'dense', 'isolated')
            target_cd: Target CD in nm
            output_folder: Folder to save data
            
        Returns:
            Dictionary with generated data info
        """
        try:
            # Pattern configurations
            pattern_configs = {
                'line': {'name': 'Line_45nm', 'cd': 45.0},
                'contact': {'name': 'Contact_50nm', 'cd': 50.0},
                'via': {'name': 'Via_60nm', 'cd': 60.0},
                'dense': {'name': 'Dense_250nm', 'cd': 250.0},
                'isolated': {'name': 'Isolated_300nm', 'cd': 300.0}
            }
            
            if pattern_type not in pattern_configs:
                pattern_type = 'dense'
            
            config = pattern_configs[pattern_type]
            pattern_name = config['name']
            pattern_cd = config['cd']
            
            # Generate FEM matrix
            fem_matrix = self.generator.generate_pattern_matrix(
                pattern_name=pattern_name,
                pattern_type=pattern_type,
                target_cd=pattern_cd
            )
            
            # Save to file if output folder provided
            if output_folder:
                os.makedirs(output_folder, exist_ok=True)
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                filename = f'{pattern_name}_fem_data_{timestamp}.csv'
                filepath = os.path.join(output_folder, filename)
                fem_matrix.to_csv(filepath)
            else:
                filepath = None
            
            # Add to processor
            self.processor.matrices[pattern_name] = fem_matrix
            
            return {
                'success': True,
                'pattern_name': pattern_name,
                'pattern_type': pattern_type,
                'target_cd': pattern_cd,
                'filepath': filepath,
                'matrix_shape': fem_matrix.get_shape(),
                'exposure_range': (
                    float(fem_matrix.exposure_values.min()),
                    float(fem_matrix.exposure_values.max())
                ),
                'focus_range': (
                    float(fem_matrix.focus_values.min()),
                    float(fem_matrix.focus_values.max())
                )
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def generate_visualizations(self,
                               pattern_name: str,
                               target_cd: float,
                               cd_tolerance: float,
                               output_folder: str,
                               plot_types: List[str] = None) -> Dict:
        """
        Generate FEM visualizations.
        
        Args:
            pattern_name: Pattern name
            target_cd: Target CD
            cd_tolerance: CD tolerance
            output_folder: Output folder for plots
            plot_types: List of plot types to generate
            
        Returns:
            Dictionary with generated plot paths
        """
        try:
            fem_matrix = self.processor.get_matrix(pattern_name)
            if fem_matrix is None:
                return {
                    'success': False,
                    'error': f'Pattern {pattern_name} not found'
                }
            
            os.makedirs(output_folder, exist_ok=True)
            
            if plot_types is None:
                plot_types = ['contour', 'process_window', 'dof_el']
            
            generated_plots = {}
            
            # Contour plot
            if 'contour' in plot_types:
                self.visualizer.plot_fem_contour(
                    fem_matrix,
                    target_cd=target_cd,
                    cd_tolerance=cd_tolerance,
                    levels=20
                )
                filename = f'{pattern_name}_contour.png'
                contour_path = os.path.join(output_folder, filename)
                self.visualizer.save_figure(contour_path)
                self.visualizer.close()
                generated_plots['contour'] = filename
            
            # Process window overlay
            if 'process_window' in plot_types:
                self.visualizer.plot_process_window_overlay(
                    fem_matrix,
                    target_cd=target_cd,
                    cd_tolerance=cd_tolerance
                )
                filename = f'{pattern_name}_process_window.png'
                pw_path = os.path.join(output_folder, filename)
                self.visualizer.save_figure(pw_path)
                self.visualizer.close()
                generated_plots['process_window'] = filename
            
            # DOF/EL analysis
            if 'dof_el' in plot_types:
                self.visualizer.plot_dof_el_analysis(
                    self.processor,
                    pattern_name=pattern_name,
                    target_cd=target_cd,
                    cd_tolerance=cd_tolerance
                )
                filename = f'{pattern_name}_dof_el.png'
                dof_el_path = os.path.join(output_folder, filename)
                self.visualizer.save_figure(dof_el_path)
                self.visualizer.close()
                generated_plots['dof_el'] = filename
            
            # Heatmap
            if 'heatmap' in plot_types:
                self.visualizer.plot_fem_heatmap(fem_matrix)
                filename = f'{pattern_name}_heatmap.png'
                heatmap_path = os.path.join(output_folder, filename)
                self.visualizer.save_figure(heatmap_path)
                self.visualizer.close()
                generated_plots['heatmap'] = filename
            
            # Gradient field
            if 'gradient' in plot_types:
                self.visualizer.plot_gradient_field(fem_matrix)
                filename = f'{pattern_name}_gradient.png'
                gradient_path = os.path.join(output_folder, filename)
                self.visualizer.save_figure(gradient_path)
                self.visualizer.close()
                generated_plots['gradient'] = filename
            
            return {
                'success': True,
                'plots': generated_plots
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def compare_patterns(self,
                        target_cd: float,
                        cd_tolerance: float) -> Dict:
        """
        Compare multiple patterns.
        
        Args:
            target_cd: Target CD
            cd_tolerance: CD tolerance
            
        Returns:
            Dictionary with comparison results
        """
        try:
            analyzer = MultiPatternAnalyzer(self.processor)
            
            # Generate comparison report
            report = analyzer.generate_comparison_report(target_cd, cd_tolerance)
            
            # Get pattern ranking
            ranking_area = analyzer.get_pattern_ranking(metric='area')
            ranking_dof = analyzer.get_pattern_ranking(metric='dof')
            ranking_el = analyzer.get_pattern_ranking(metric='el')
            
            # Get best pattern
            best_area = analyzer.get_best_pattern(metric='area')
            best_dof = analyzer.get_best_pattern(metric='dof')
            best_el = analyzer.get_best_pattern(metric='el')
            
            return {
                'success': True,
                'report': report,
                'rankings': {
                    'area': ranking_area.to_dict('records'),
                    'dof': ranking_dof.to_dict('records'),
                    'el': ranking_el.to_dict('records')
                },
                'best_patterns': {
                    'area': best_area,
                    'dof': best_dof,
                    'el': best_el
                }
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def _generate_chart_data(self,
                            fem_matrix: FEMMatrix,
                            target_cd: float,
                            cd_tolerance: float) -> Dict:
        """
        Generate data for frontend charts.
        
        Args:
            fem_matrix: FEM matrix
            target_cd: Target CD
            cd_tolerance: CD tolerance
            
        Returns:
            Dictionary with chart data
        """
        # Contour data
        contour_data = {
            'exposure_grid': fem_matrix.exp_grid.tolist(),
            'focus_grid': fem_matrix.foc_grid.tolist(),
            'cd_matrix': fem_matrix.cd_matrix.tolist(),
            'exposure_values': fem_matrix.exposure_values.tolist(),
            'focus_values': fem_matrix.focus_values.tolist()
        }
        
        # Spec limits
        cd_min = target_cd * (1 - cd_tolerance)
        cd_max = target_cd * (1 + cd_tolerance)
        
        spec_limits = {
            'target_cd': target_cd,
            'cd_min': cd_min,
            'cd_max': cd_max,
            'tolerance_percent': cd_tolerance * 100
        }
        
        # In-spec region
        in_spec = (fem_matrix.cd_matrix >= cd_min) & (fem_matrix.cd_matrix <= cd_max)
        in_spec_points = []
        
        for i, focus in enumerate(fem_matrix.focus_values):
            for j, exposure in enumerate(fem_matrix.exposure_values):
                if in_spec[i, j]:
                    in_spec_points.append({
                        'exposure': float(exposure),
                        'focus': float(focus),
                        'cd': float(fem_matrix.cd_matrix[i, j])
                    })
        
        return {
            'contour': contour_data,
            'spec_limits': spec_limits,
            'in_spec_points': in_spec_points
        }
    
    def _generate_bossung_data(self,
                              fem_matrix: FEMMatrix,
                              target_cd: float) -> Dict:
        """
        Generate Bossung curve data for multiple exposure doses.
        
        Args:
            fem_matrix: FEM matrix
            target_cd: Target CD
            
        Returns:
            Dictionary with Bossung curve data
        """
        bossung_curves = []
        
        for j, exposure in enumerate(fem_matrix.exposure_values):
            curve_data = []
            for i, focus in enumerate(fem_matrix.focus_values):
                curve_data.append({
                    'focus': float(focus),
                    'cd': float(fem_matrix.cd_matrix[i, j]),
                    'exposure': float(exposure)
                })
            bossung_curves.append({
                'exposure': float(exposure),
                'data': curve_data
            })
        
        # Find iso-focal point (where curves intersect)
        iso_focal = self._find_iso_focal_point(fem_matrix)
        
        return {
            'curves': bossung_curves,
            'iso_focal_point': iso_focal,
            'target_cd': target_cd
        }
    
    def _find_iso_focal_point(self, fem_matrix: FEMMatrix) -> Dict:
        """
        Find the iso-focal point where CD is least sensitive to dose.
        
        Args:
            fem_matrix: FEM matrix
            
        Returns:
            Dictionary with iso-focal point info
        """
        # Calculate CD variance across exposures for each focus
        cd_variance = np.var(fem_matrix.cd_matrix, axis=1)
        
        # Find focus with minimum variance
        min_var_idx = np.argmin(cd_variance)
        iso_focal_focus = fem_matrix.focus_values[min_var_idx]
        iso_focal_cd = np.mean(fem_matrix.cd_matrix[min_var_idx, :])
        
        return {
            'focus': float(iso_focal_focus),
            'cd': float(iso_focal_cd),
            'variance': float(cd_variance[min_var_idx])
        }
    
    def _calculate_dof_at_el(self,
                            fem_matrix: FEMMatrix,
                            target_cd: float,
                            cd_tolerance: float,
                            el_percentages: List[float]) -> Dict:
        """
        Calculate DOF at specific EL percentages (industry standard metric).
        
        Args:
            fem_matrix: FEM matrix
            target_cd: Target CD
            cd_tolerance: CD tolerance
            el_percentages: List of EL percentages to calculate (e.g., [5, 10, 15])
            
        Returns:
            Dictionary with DOF at EL data
        """
        results = []
        
        # Get optimal exposure
        optimal = self.processor.get_optimal_point(
            pattern_name=list(self.processor.matrices.keys())[0],
            target_cd=target_cd,
            tolerance=cd_tolerance
        )
        
        if not optimal['found']:
            return {'results': [], 'error': 'No optimal point found'}
        
        optimal_exposure = optimal['exposure']
        
        for el_pct in el_percentages:
            # Calculate exposure range at this EL
            el_fraction = el_pct / 100.0
            exp_min = optimal_exposure * (1 - el_fraction)
            exp_max = optimal_exposure * (1 + el_fraction)
            
            # Find exposures within this range
            exp_mask = (fem_matrix.exposure_values >= exp_min) & (fem_matrix.exposure_values <= exp_max)
            valid_exposures = fem_matrix.exposure_values[exp_mask]
            
            if len(valid_exposures) == 0:
                continue
            
            # For each valid exposure, find DOF
            dof_values = []
            for exp in valid_exposures:
                exp_idx = np.argmin(np.abs(fem_matrix.exposure_values - exp))
                cd_at_exp = fem_matrix.cd_matrix[:, exp_idx]
                
                # Find in-spec focus range
                cd_min = target_cd * (1 - cd_tolerance)
                cd_max = target_cd * (1 + cd_tolerance)
                in_spec = (cd_at_exp >= cd_min) & (cd_at_exp <= cd_max)
                
                if np.any(in_spec):
                    in_spec_indices = np.where(in_spec)[0]
                    focus_min = fem_matrix.focus_values[in_spec_indices.min()]
                    focus_max = fem_matrix.focus_values[in_spec_indices.max()]
                    dof = focus_max - focus_min
                    dof_values.append(dof)
            
            if dof_values:
                results.append({
                    'el_percent': el_pct,
                    'dof': float(np.mean(dof_values)),
                    'min_dof': float(np.min(dof_values)),
                    'max_dof': float(np.max(dof_values))
                })
        
        return {'results': results}
    
    def _calculate_advanced_metrics(self,
                                   fem_matrix: FEMMatrix,
                                   target_cd: float,
                                   cd_tolerance: float,
                                   process_window: Dict,
                                   dof_el: Dict) -> Dict:
        """
        Calculate advanced FEM metrics.
        
        Args:
            fem_matrix: FEM matrix
            target_cd: Target CD
            cd_tolerance: CD tolerance
            process_window: Process window data
            dof_el: DOF/EL data
            
        Returns:
            Dictionary with advanced metrics
        """
        # Calculate inscribed rectangle dimensions
        inscribed_rect = self._calculate_inscribed_rectangle(
            fem_matrix, target_cd, cd_tolerance
        )
        
        # Calculate process capability metrics
        capability = self._calculate_process_capability(
            fem_matrix, target_cd, cd_tolerance
        )
        
        # Calculate sensitivity metrics
        sensitivity = self._calculate_sensitivity_metrics(fem_matrix)
        
        # Determine curve shape (smile vs frown)
        curve_shape = self._analyze_curve_shape(fem_matrix)
        
        return {
            'inscribed_rectangle': inscribed_rect,
            'process_capability': capability,
            'sensitivity': sensitivity,
            'curve_shape': curve_shape,
            'usable_dof': self._calculate_usable_dof(dof_el),
            'process_robustness_score': self._calculate_robustness_score(
                process_window, dof_el, capability
            )
        }
    
    def _calculate_inscribed_rectangle(self,
                                      fem_matrix: FEMMatrix,
                                      target_cd: float,
                                      cd_tolerance: float) -> Dict:
        """
        Calculate maximum inscribed rectangle in process window.
        
        Args:
            fem_matrix: FEM matrix
            target_cd: Target CD
            cd_tolerance: CD tolerance
            
        Returns:
            Dictionary with rectangle dimensions
        """
        cd_min = target_cd * (1 - cd_tolerance)
        cd_max = target_cd * (1 + cd_tolerance)
        in_spec = (fem_matrix.cd_matrix >= cd_min) & (fem_matrix.cd_matrix <= cd_max)
        
        if not np.any(in_spec):
            return {'width': 0, 'height': 0, 'area': 0}
        
        # Find largest rectangle (simplified algorithm)
        max_area = 0
        best_width = 0
        best_height = 0
        
        # For each focus level, find continuous exposure range
        for i in range(len(fem_matrix.focus_values)):
            in_spec_row = in_spec[i, :]
            if not np.any(in_spec_row):
                continue
            
            # Find continuous segments
            indices = np.where(in_spec_row)[0]
            if len(indices) > 0:
                width = fem_matrix.exposure_values[indices[-1]] - fem_matrix.exposure_values[indices[0]]
                
                # Find height at this width
                height = 0
                for j in range(i, len(fem_matrix.focus_values)):
                    if np.all(in_spec[j, indices[0]:indices[-1]+1]):
                        height = fem_matrix.focus_values[j] - fem_matrix.focus_values[i]
                    else:
                        break
                
                area = width * abs(height)
                if area > max_area:
                    max_area = area
                    best_width = width
                    best_height = abs(height)
        
        return {
            'width': float(best_width),
            'height': float(best_height),
            'area': float(max_area)
        }
    
    def _calculate_process_capability(self,
                                     fem_matrix: FEMMatrix,
                                     target_cd: float,
                                     cd_tolerance: float) -> Dict:
        """
        Calculate process capability indices.
        
        Args:
            fem_matrix: FEM matrix
            target_cd: Target CD
            cd_tolerance: CD tolerance
            
        Returns:
            Dictionary with capability metrics
        """
        cd_mean = np.mean(fem_matrix.cd_matrix)
        cd_std = np.std(fem_matrix.cd_matrix)
        
        usl = target_cd * (1 + cd_tolerance)
        lsl = target_cd * (1 - cd_tolerance)
        
        # Cp: Process capability (potential)
        cp = (usl - lsl) / (6 * cd_std) if cd_std > 0 else 0
        
        # Cpk: Process capability (actual)
        cpu = (usl - cd_mean) / (3 * cd_std) if cd_std > 0 else 0
        cpl = (cd_mean - lsl) / (3 * cd_std) if cd_std > 0 else 0
        cpk = min(cpu, cpl)
        
        return {
            'cp': float(cp),
            'cpk': float(cpk),
            'mean_cd': float(cd_mean),
            'std_cd': float(cd_std),
            'interpretation': self._interpret_cpk(cpk)
        }
    
    def _interpret_cpk(self, cpk: float) -> str:
        """Interpret Cpk value."""
        if cpk >= 2.0:
            return 'Excellent (6-sigma capable)'
        elif cpk >= 1.67:
            return 'Very Good (5-sigma capable)'
        elif cpk >= 1.33:
            return 'Good (4-sigma capable)'
        elif cpk >= 1.0:
            return 'Adequate (3-sigma capable)'
        else:
            return 'Poor (needs improvement)'
    
    def _calculate_sensitivity_metrics(self, fem_matrix: FEMMatrix) -> Dict:
        """
        Calculate focus and dose sensitivity.
        
        Args:
            fem_matrix: FEM matrix
            
        Returns:
            Dictionary with sensitivity metrics
        """
        grad_e, grad_f = fem_matrix.get_gradient()
        
        return {
            'focus_sensitivity': float(np.mean(np.abs(grad_f))),
            'dose_sensitivity': float(np.mean(np.abs(grad_e))),
            'max_focus_sensitivity': float(np.max(np.abs(grad_f))),
            'max_dose_sensitivity': float(np.max(np.abs(grad_e)))
        }
    
    def _analyze_curve_shape(self, fem_matrix: FEMMatrix) -> Dict:
        """
        Analyze Bossung curve shape (smile vs frown).
        
        Args:
            fem_matrix: FEM matrix
            
        Returns:
            Dictionary with curve shape analysis
        """
        # Calculate curvature
        curvature = fem_matrix.get_curvature()
        avg_curvature = np.mean(curvature)
        
        if avg_curvature > 0.1:
            shape = 'smile'
            interpretation = 'Isolated space or contact hole behavior'
        elif avg_curvature < -0.1:
            shape = 'frown'
            interpretation = 'Isolated line behavior'
        else:
            shape = 'neutral'
            interpretation = 'Balanced feature response'
        
        return {
            'shape': shape,
            'curvature': float(avg_curvature),
            'interpretation': interpretation
        }
    
    def _calculate_usable_dof(self, dof_el: Dict) -> float:
        """
        Calculate usable DOF accounting for systematic errors.
        Assumes 20% reduction for field curvature and leveling errors.
        
        Args:
            dof_el: DOF/EL data
            
        Returns:
            Usable DOF value
        """
        return float(dof_el['avg_dof'] * 0.8)
    
    def _calculate_robustness_score(self,
                                   process_window: Dict,
                                   dof_el: Dict,
                                   capability: Dict) -> Dict:
        """
        Calculate overall process robustness score (0-100).
        
        Args:
            process_window: Process window data
            dof_el: DOF/EL data
            capability: Capability data
            
        Returns:
            Dictionary with robustness score and rating
        """
        # Scoring components (0-100 each)
        pw_score = min(100, (process_window.get('area', 0) / 100) * 100)
        dof_score = min(100, (dof_el.get('avg_dof', 0) / 1.0) * 100)
        el_score = min(100, (dof_el.get('avg_el', 0) / 80) * 100)
        cpk_score = min(100, capability.get('cpk', 0) * 50)
        
        # Weighted average
        total_score = (pw_score * 0.3 + dof_score * 0.3 + el_score * 0.2 + cpk_score * 0.2)
        
        if total_score >= 80:
            rating = 'Excellent'
        elif total_score >= 60:
            rating = 'Good'
        elif total_score >= 40:
            rating = 'Adequate'
        else:
            rating = 'Poor'
        
        return {
            'score': float(total_score),
            'rating': rating,
            'components': {
                'process_window': float(pw_score),
                'dof': float(dof_score),
                'el': float(el_score),
                'capability': float(cpk_score)
            }
        }
    
    def get_pattern_list(self) -> List[str]:
        """Get list of loaded patterns."""
        return self.processor.list_patterns()
    
    def clear_patterns(self) -> None:
        """Clear all loaded patterns."""
        self.processor.matrices.clear()
        self.processor.patterns.clear()
