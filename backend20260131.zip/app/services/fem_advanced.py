"""
Advanced FEM Analysis Features
Implements industry-standard metrics and analysis techniques
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
from scipy.optimize import minimize
from scipy.interpolate import interp1d


class AdvancedFEMAnalyzer:
    """
    Advanced FEM analysis capabilities including:
    - Bossung curve generation and analysis
    - Iso-focal point detection
    - DOF at EL% calculation (industry standard)
    - Maximum inscribed rectangle/ellipse
    - Process robustness scoring
    - OPC bias recommendations
    """
    
    def __init__(self):
        """Initialize advanced analyzer."""
        pass
    
    def generate_bossung_curves(self,
                                fem_matrix,
                                exposure_doses: Optional[List[float]] = None) -> Dict:
        """
        Generate Bossung curves (CD vs Focus at constant Exposure).
        
        Args:
            fem_matrix: FEMMatrix object
            exposure_doses: List of exposure doses to plot (if None, use all)
            
        Returns:
            Dictionary with Bossung curve data
        """
        if exposure_doses is None:
            exposure_doses = fem_matrix.exposure_values.tolist()
        
        curves = []
        for exposure in exposure_doses:
            focus_vals, cd_vals = fem_matrix.get_bossung_curve(exposure)
            curves.append({
                'exposure': float(exposure),
                'data': [
                    {'focus': float(f), 'cd': float(cd)}
                    for f, cd in zip(focus_vals, cd_vals)
                ]
            })
        
        # Detect iso-focal point
        iso_focal = self._detect_iso_focal_point(fem_matrix, exposure_doses)
        
        # Detect curve shape (smile vs frown)
        curve_shape = self._analyze_curve_shape(fem_matrix, exposure_doses)
        
        return {
            'curves': curves,
            'iso_focal_point': iso_focal,
            'curve_shape': curve_shape
        }
    
    def _detect_iso_focal_point(self, fem_matrix, exposure_doses: List[float]) -> Optional[Dict]:
        """
        Detect iso-focal point where curves intersect (minimum dose sensitivity).
        
        Args:
            fem_matrix: FEMMatrix object
            exposure_doses: List of exposure doses
            
        Returns:
            Dictionary with iso-focal point info or None
        """
        # Find focus where CD variance across doses is minimum
        cd_variance = np.var(fem_matrix.cd_matrix, axis=1)
        min_var_idx = np.argmin(cd_variance)
        
        iso_focal_focus = fem_matrix.focus_values[min_var_idx]
        iso_focal_cd = np.mean(fem_matrix.cd_matrix[min_var_idx, :])
        
        return {
            'focus': float(iso_focal_focus),
            'cd': float(iso_focal_cd),
            'variance': float(cd_variance[min_var_idx])
        }
    
    def _analyze_curve_shape(self, fem_matrix, exposure_doses: List[float]) -> Dict:
        """
        Analyze Bossung curve shape (smile vs frown).
        
        Args:
            fem_matrix: FEMMatrix object
            exposure_doses: List of exposure doses
            
        Returns:
            Dictionary with shape analysis
        """
        # Fit quadratic to middle exposure curve
        mid_idx = len(fem_matrix.exposure_values) // 2
        focus_vals = fem_matrix.focus_values
        cd_vals = fem_matrix.cd_matrix[:, mid_idx]
        
        # Fit: CD = a*F^2 + b*F + c
        coeffs = np.polyfit(focus_vals, cd_vals, 2)
        a = coeffs[0]
        
        if a > 0:
            shape = 'smile'  # Upward curvature (isolated space/contact)
            description = 'Isolated space or contact hole behavior'
        else:
            shape = 'frown'  # Downward curvature (isolated line)
            description = 'Isolated line behavior'
        
        return {
            'shape': shape,
            'description': description,
            'curvature_coefficient': float(a)
        }
    
    def calculate_dof_at_el(self,
                           fem_matrix,
                           target_cd: float,
                           cd_tolerance: float,
                           el_percentages: List[float] = [5, 10, 15, 20]) -> Dict:
        """
        Calculate DOF at specific EL% values (industry standard metric).
        
        Args:
            fem_matrix: FEMMatrix object
            target_cd: Target CD
            cd_tolerance: CD tolerance as fraction
            el_percentages: List of EL percentages to calculate
            
        Returns:
            Dictionary with DOF at EL results
        """
        cd_min = target_cd * (1 - cd_tolerance)
        cd_max = target_cd * (1 + cd_tolerance)
        
        results = []
        
        for el_pct in el_percentages:
            # Calculate dose range for this EL%
            el_fraction = el_pct / 100.0
            
            # Find DOF at each exposure within EL range
            dof_values = []
            
            for exp_idx, exposure in enumerate(fem_matrix.exposure_values):
                # Check if this exposure is within EL% of any in-spec exposure
                cd_col = fem_matrix.cd_matrix[:, exp_idx]
                in_spec_mask = (cd_col >= cd_min) & (cd_col <= cd_max)
                
                if np.any(in_spec_mask):
                    # Find focus range at this exposure
                    in_spec_indices = np.where(in_spec_mask)[0]
                    focus_min = fem_matrix.focus_values[in_spec_indices.min()]
                    focus_max = fem_matrix.focus_values[in_spec_indices.max()]
                    dof = focus_max - focus_min
                    dof_values.append(dof)
            
            if dof_values:
                avg_dof = np.mean(dof_values)
                min_dof = np.min(dof_values)
                max_dof = np.max(dof_values)
            else:
                avg_dof = 0
                min_dof = 0
                max_dof = 0
            
            results.append({
                'el_percent': el_pct,
                'dof': avg_dof,
                'min_dof': min_dof,
                'max_dof': max_dof
            })
        
        return {
            'results': results,
            'standard_metric': f"DOF at {el_percentages[0]}% EL: {results[0]['dof']:.4f} μm" if results else None
        }
    
    def find_inscribed_rectangle(self,
                                 process_window_data: Dict,
                                 focus_range: Tuple[float, float],
                                 exposure_range: Tuple[float, float]) -> Dict:
        """
        Find maximum inscribed rectangle in process window (simplified version).
        
        Args:
            process_window_data: Process window information
            focus_range: (min, max) focus values
            exposure_range: (min, max) exposure values
            
        Returns:
            Dictionary with inscribed rectangle info
        """
        if not process_window_data.get('found', False):
            return {
                'found': False,
                'area': 0,
                'width': 0,
                'height': 0,
                'center_focus': 0,
                'center_exposure': 0
            }
        
        # Simple bounding box approach
        exp_range = process_window_data.get('exposure_range', (0, 0))
        foc_range = process_window_data.get('focus_range', (0, 0))
        
        width = exp_range[1] - exp_range[0]
        height = foc_range[1] - foc_range[0]
        area = width * height
        
        center_exposure = (exp_range[0] + exp_range[1]) / 2
        center_focus = (foc_range[0] + foc_range[1]) / 2
        
        return {
            'found': True,
            'width': float(width),
            'height': float(height),
            'area': float(area),
            'center_focus': float(center_focus),
            'center_exposure': float(center_exposure)
        }
    
    def calculate_process_robustness_score(self,
                                          process_window: Dict,
                                          dof_el: Dict,
                                          optimal_point: Dict) -> Dict:
        """
        Calculate overall process robustness score (0-100).
        
        Args:
            process_window: Process window metrics
            dof_el: DOF/EL metrics
            optimal_point: Optimal point info
            
        Returns:
            Dictionary with robustness score and rating
        """
        score = 0
        max_score = 100
        
        # Process window area (30 points)
        if process_window.get('found', False):
            area = process_window.get('area', 0)
            if area >= 50:
                score += 30
            elif area >= 20:
                score += 20
            elif area >= 10:
                score += 10
        
        # DOF (30 points)
        avg_dof = dof_el.get('avg_dof', 0)
        if avg_dof >= 0.8:
            score += 30
        elif avg_dof >= 0.5:
            score += 20
        elif avg_dof >= 0.3:
            score += 10
        
        # EL (20 points)
        avg_el = dof_el.get('avg_el', 0)
        if avg_el >= 80:
            score += 20
        elif avg_el >= 50:
            score += 15
        elif avg_el >= 30:
            score += 10
        
        # In-spec coverage (10 points)
        if process_window.get('found', False):
            coverage = process_window.get('in_spec_points', 0) / max(process_window.get('total_points', 1), 1)
            score += int(coverage * 10)
        
        # Optimal point centering (10 points)
        if optimal_point.get('found', False):
            cd_dev = abs(optimal_point.get('cd_deviation', 999))
            if cd_dev < 2:
                score += 10
            elif cd_dev < 5:
                score += 5
        
        # Rating
        if score >= 80:
            rating = 'Excellent'
        elif score >= 60:
            rating = 'Good'
        elif score >= 40:
            rating = 'Adequate'
        else:
            rating = 'Poor'
        
        return {
            'score': score,
            'max_score': max_score,
            'rating': rating,
            'percentage': (score / max_score) * 100
        }
    
    def recommend_opc_bias(self,
                          optimal_point: Dict,
                          target_cd: float) -> Dict:
        """
        Recommend OPC bias adjustment.
        
        Args:
            optimal_point: Optimal point info
            target_cd: Target CD
            
        Returns:
            Dictionary with OPC bias recommendation
        """
        if not optimal_point.get('found', False):
            return {
                'recommended': False,
                'bias': 0,
                'reason': 'No optimal point found'
            }
        
        cd_deviation = optimal_point.get('cd_deviation', 0)
        
        # Recommend bias if deviation > 2nm
        if abs(cd_deviation) > 2:
            recommended_bias = -cd_deviation  # Opposite sign to correct
            return {
                'recommended': True,
                'bias': recommended_bias,
                'current_cd': optimal_point.get('cd', target_cd),
                'target_cd': target_cd,
                'deviation': cd_deviation,
                'reason': f'CD deviates {cd_deviation:.2f} nm from target. Apply {recommended_bias:.2f} nm OPC bias to center process window.'
            }
        else:
            return {
                'recommended': False,
                'bias': 0,
                'current_cd': optimal_point.get('cd', target_cd),
                'target_cd': target_cd,
                'deviation': cd_deviation,
                'reason': 'CD is well-centered. No bias adjustment needed.'
            }
    
    def analyze_multi_pattern_overlap(self,
                                     pattern_windows: Dict[str, Dict]) -> Dict:
        """
        Analyze overlapping process windows for multiple patterns (simplified).
        
        Args:
            pattern_windows: Dictionary of pattern_name -> process window dict
            
        Returns:
            Dictionary with overlap analysis
        """
        if not pattern_windows:
            return {
                'common_window_found': False,
                'common_area': 0,
                'limiting_pattern': None
            }
        
        # Find pattern with smallest area
        areas = {name: window.get('area', 0) for name, window in pattern_windows.items()}
        limiting_pattern = min(areas, key=areas.get) if areas else None
        
        # Check if all patterns have valid windows
        all_valid = all(window.get('found', False) for window in pattern_windows.values())
        
        if not all_valid:
            return {
                'common_window_found': False,
                'common_area': 0,
                'limiting_pattern': limiting_pattern,
                'individual_areas': areas,
                'recommendation': 'Window collapse detected. OPC/SMO optimization or reticle redesign required.'
            }
        else:
            # Use smallest area as approximation of common window
            common_area = min(areas.values()) if areas else 0
            
            return {
                'common_window_found': True,
                'common_area': common_area,
                'individual_areas': areas,
                'limiting_pattern': limiting_pattern,
                'coverage_ratio': common_area / max(areas.values()) if areas else 0,
                'recommendation': 'Common process window found. All patterns can be printed with same conditions.'
            }
