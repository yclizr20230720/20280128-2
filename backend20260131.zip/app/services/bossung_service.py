"""
Bossung Curve Analysis Service
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
from datetime import datetime

# Use our wrapper to avoid path issues
from app.services.bossung_wrapper import BossungPlotterWrapper as BossungPlotter
from app.services.bossung_wrapper import generate_mock_data_wrapper


class BossungService:
    """
    Service class for Bossung curve analysis operations
    """
    
    def __init__(self):
        """Initialize the service"""
        self.plotter = None
    
    def analyze(self, filepath, target_cd, tolerance_percent):
        """
        Perform Bossung curve analysis
        
        Parameters:
        -----------
        filepath : str
            Path to CSV data file
        target_cd : float
            Target critical dimension (nm)
        tolerance_percent : float
            Tolerance as percentage of target CD
        
        Returns:
        --------
        dict : Analysis results
        """
        # Create plotter instance
        self.plotter = BossungPlotter(data_file=filepath)
        self.plotter.set_target_specs(target_cd, tolerance_percent)
        
        # Calculate metrics
        metrics = self.plotter.calculate_process_window_metrics()
        
        # Get data statistics
        data = self.plotter.data
        
        results = {
            'process_window': {
                'dof': float(metrics['DOF']),
                'el': float(metrics['EL']),
                'optimal_dose': float(metrics['optimal_dose']),
                'optimal_focus': float(metrics['optimal_focus']),
                'in_spec_points': int(metrics['in_spec_points']),
                'total_points': int(metrics['total_points']),
                'yield_percent': float(metrics['in_spec_points'] / metrics['total_points'] * 100)
            },
            'cd_statistics': {
                'mean': float(data['CD'].mean()),
                'std': float(data['CD'].std()),
                'min': float(data['CD'].min()),
                'max': float(data['CD'].max()),
                'range': float(data['CD'].max() - data['CD'].min())
            },
            'specifications': {
                'target_cd': float(target_cd),
                'tolerance': float(target_cd * tolerance_percent / 100),
                'tolerance_percent': float(tolerance_percent),
                'cd_min': float(target_cd * (1 - tolerance_percent / 100)),
                'cd_max': float(target_cd * (1 + tolerance_percent / 100))
            },
            'data_summary': {
                'total_points': len(data),
                'unique_doses': int(data['Dose'].nunique()),
                'unique_defocus': int(data['Defocus'].nunique()),
                'dose_range': {
                    'min': float(data['Dose'].min()),
                    'max': float(data['Dose'].max())
                },
                'defocus_range': {
                    'min': float(data['Defocus'].min()),
                    'max': float(data['Defocus'].max())
                }
            }
        }
        
        return results
    
    def get_chart_data(self, filepath, target_cd, tolerance_percent):
        """
        Get formatted data for frontend chart rendering including advanced analysis
        
        Parameters:
        -----------
        filepath : str
            Path to CSV data file
        target_cd : float
            Target critical dimension (nm)
        tolerance_percent : float
            Tolerance as percentage of target CD
        
        Returns:
        --------
        dict : Chart data formatted for Recharts including advanced metrics
        """
        # Create plotter instance if not exists
        if self.plotter is None:
            self.plotter = BossungPlotter(data_file=filepath)
            self.plotter.set_target_specs(target_cd, tolerance_percent)
        
        data = self.plotter.data
        
        # Format data for Bossung curves (line chart)
        bossung_data = []
        doses = sorted(data['Dose'].unique())
        
        for dose in doses:
            dose_data = data[data['Dose'] == dose].sort_values('Defocus')
            for _, row in dose_data.iterrows():
                bossung_data.append({
                    'defocus': float(row['Defocus']),
                    'cd': float(row['CD']),
                    'dose': float(dose),
                    'dose_label': f'{dose:.1f} mJ/cm²'
                })
        
        # Format data for process window (contour/heatmap)
        process_window_data = []
        for _, row in data.iterrows():
            process_window_data.append({
                'dose': float(row['Dose']),
                'defocus': float(row['Defocus']),
                'cd': float(row['CD'])
            })
        
        # CD distribution data
        cd_distribution = data['CD'].value_counts(bins=20).sort_index()
        distribution_data = []
        for bin_range, count in cd_distribution.items():
            distribution_data.append({
                'cd_range': f'{bin_range.left:.1f}-{bin_range.right:.1f}',
                'cd_mid': float((bin_range.left + bin_range.right) / 2),
                'count': int(count)
            })
        
        # Dose sensitivity data (CD vs Dose at different defocus)
        dose_sensitivity_data = []
        for _, row in data.iterrows():
            dose_sensitivity_data.append({
                'dose': float(row['Dose']),
                'defocus': float(row['Defocus']),
                'cd': float(row['CD'])
            })
        
        # Advanced analysis: Fit Bossung curves and extract parameters
        advanced_metrics = self._calculate_advanced_metrics(data, doses)
        
        # Target lines
        target_lines = {
            'target_cd': float(target_cd),
            'upper_limit': float(target_cd + target_cd * tolerance_percent / 100),
            'lower_limit': float(target_cd - target_cd * tolerance_percent / 100)
        }
        
        # Dose list for legend
        dose_list = [{'dose': float(d), 'label': f'{d:.1f} mJ/cm²'} for d in doses]
        
        return {
            'bossung_curves': bossung_data,
            'process_window': process_window_data,
            'cd_distribution': distribution_data,
            'dose_sensitivity': dose_sensitivity_data,
            'advanced_metrics': advanced_metrics,
            'target_lines': target_lines,
            'doses': dose_list,
            'defocus_range': {
                'min': float(data['Defocus'].min()),
                'max': float(data['Defocus'].max())
            },
            'dose_range': {
                'min': float(data['Dose'].min()),
                'max': float(data['Dose'].max())
            },
            'cd_range': {
                'min': float(data['CD'].min()),
                'max': float(data['CD'].max())
            }
        }
    
    def _calculate_advanced_metrics(self, data, doses):
        """
        Calculate advanced metrics: best focus, curvature, model fit quality
        
        Parameters:
        -----------
        data : DataFrame
            Lithography data
        doses : list
            List of dose values
        
        Returns:
        --------
        dict : Advanced metrics for each dose
        """
        from scipy.optimize import curve_fit
        
        advanced_data = {
            'best_focus_vs_dose': [],
            'cd_at_best_focus': [],
            'curvature_vs_dose': [],
            'model_fit_quality': []
        }
        
        for dose in doses:
            dose_data = data[data['Dose'] == dose].sort_values('Defocus')
            
            if len(dose_data) < 3:
                continue
            
            defocus = dose_data['Defocus'].values
            cd = dose_data['CD'].values
            
            # Parabolic model: CD = a * defocus^2 + b * defocus + c
            def parabola(x, a, b, c):
                return a * x**2 + b * x + c
            
            try:
                params, _ = curve_fit(parabola, defocus, cd)
                a, b, c = params
                
                # Calculate R-squared
                cd_pred = parabola(defocus, a, b, c)
                ss_res = np.sum((cd - cd_pred)**2)
                ss_tot = np.sum((cd - np.mean(cd))**2)
                r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
                
                # Find best focus (minimum of parabola)
                best_focus = -b / (2 * a) if a != 0 else 0
                cd_at_best_focus = parabola(best_focus, a, b, c)
                
                advanced_data['best_focus_vs_dose'].append({
                    'dose': float(dose),
                    'best_focus': float(best_focus)
                })
                
                advanced_data['cd_at_best_focus'].append({
                    'dose': float(dose),
                    'cd': float(cd_at_best_focus)
                })
                
                advanced_data['curvature_vs_dose'].append({
                    'dose': float(dose),
                    'curvature': float(a)
                })
                
                advanced_data['model_fit_quality'].append({
                    'dose': float(dose),
                    'r_squared': float(r_squared)
                })
                
            except Exception:
                continue
        
        return advanced_data
    
    def generate_plots(self, filepath, target_cd, tolerance_percent, plot_types, output_folder):
        """
        Generate Bossung curve plots
        
        Parameters:
        -----------
        filepath : str
            Path to CSV data file
        target_cd : float
            Target critical dimension (nm)
        tolerance_percent : float
            Tolerance as percentage of target CD
        plot_types : list
            List of plot types to generate
        output_folder : str
            Output folder for plots
        
        Returns:
        --------
        dict : Dictionary of generated plot file paths
        """
        # Create plotter instance if not exists
        if self.plotter is None:
            self.plotter = BossungPlotter(data_file=filepath)
            self.plotter.set_target_specs(target_cd, tolerance_percent)
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        plot_files = {}
        
        # Generate requested plots
        if 'bossung' in plot_types:
            fig, ax = self.plotter.plot_bossung_curves()
            filename = f'bossung_curves_{timestamp}.png'
            filepath = os.path.join(output_folder, filename)
            fig.savefig(filepath, dpi=300, bbox_inches='tight')
            plt.close(fig)
            plot_files['bossung_curves'] = filename
        
        if 'process_window' in plot_types:
            fig, ax = self.plotter.plot_process_window()
            filename = f'process_window_{timestamp}.png'
            filepath = os.path.join(output_folder, filename)
            fig.savefig(filepath, dpi=300, bbox_inches='tight')
            plt.close(fig)
            plot_files['process_window'] = filename
        
        if 'comprehensive' in plot_types:
            fig = self.plotter.plot_comprehensive_analysis()
            filename = f'comprehensive_{timestamp}.png'
            filepath = os.path.join(output_folder, filename)
            fig.savefig(filepath, dpi=300, bbox_inches='tight')
            plt.close(fig)
            plot_files['comprehensive'] = filename
        
        return plot_files
    
    def generate_mock_data(self, output_folder, doses=9, defocus_points=17, target_cd=45.0):
        """
        Generate mock lithography data
        """
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'mock_litho_data_{timestamp}.csv'
        filepath = os.path.join(output_folder, filename)
        
        # Generate data using wrapper function
        generate_mock_data_wrapper(filepath, doses, defocus_points, target_cd)
        
        return filepath
