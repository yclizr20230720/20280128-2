const About = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h1 className="text-4xl font-bold gradient-text mb-6">About VSMC Litho Platform</h1>
          
          <div className="prose prose-lg max-w-none">
            <p className="text-gray-700 mb-4">
              The VSMC Litho Platform is a modern web-based analysis suite designed for semiconductor 
              lithography engineers and process integration teams. Our platform provides comprehensive 
              tools for analyzing Scanner, Track, and Lithography Process data.
            </p>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Key Features</h2>
            <ul className="space-y-2 text-gray-700">
              <li>✓ Real-time data analysis and visualization</li>
              <li>✓ Advanced process window evaluation</li>
              <li>✓ Interactive Bossung curve generation</li>
              <li>✓ Equipment performance monitoring</li>
              <li>✓ Defect analysis and classification</li>
              <li>✓ ML-based yield prediction</li>
              <li>✓ Export-ready reports and plots</li>
            </ul>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Technology Stack</h2>
            <div className="grid grid-cols-2 gap-4 mt-4">
              <div className="bg-primary-50 rounded-lg p-4">
                <h3 className="font-semibold text-primary-900 mb-2">Frontend</h3>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• React 18</li>
                  <li>• Vite</li>
                  <li>• TailwindCSS</li>
                  <li>• Recharts</li>
                </ul>
              </div>
              <div className="bg-secondary-50 rounded-lg p-4">
                <h3 className="font-semibold text-secondary-900 mb-2">Backend</h3>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Python Flask</li>
                  <li>• NumPy & Pandas</li>
                  <li>• Matplotlib</li>
                  <li>• SciPy</li>
                </ul>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Version</h2>
            <p className="text-gray-700">
              Current Version: <span className="font-semibold">1.0.0</span>
            </p>
            <p className="text-gray-700 mt-2">
              Last Updated: <span className="font-semibold">January 2026</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default About
