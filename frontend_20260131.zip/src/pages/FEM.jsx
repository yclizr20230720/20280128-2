import { useState, useEffect } from 'react';
import { Upload, Target, TrendingUp, Grid, RefreshCw, BarChart3, Sparkles, Save } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import api, { saveAnalysis } from '../services/api';
import FEMBossungChart from '../components/FEMBossungChart';
import FEMContourChart from '../components/FEMContourChart';
import DOFatELChart from '../components/DOFatELChart';
import FEMTechnicalGuide from '../components/FEMTechnicalGuide';

export default function FEM() {
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [generating, setGenerating] = useState(false);
  
  const [uploadedData, setUploadedData] = useState(null);
  const [analysisResults, setAnalysisResults] = useState(null);
  const [advancedMetrics, setAdvancedMetrics] = useState(null);
  const [plots, setPlots] = useState(null);
  const [saving, setSaving] = useState(false);
  
  const [parameters, setParameters] = useState({
    patternName: 'Dense_250nm',
    targetCD: 250.0,
    cdTolerance: 10,
    patternType: 'dense'
  });
  
  const [activeTab, setActiveTab] = useState('upload');

  useEffect(() => {
    if (!user) {
      navigate('/login');
    }
  }, [user, navigate]);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
    }
  };

  const handleUpload = async () => {
    if (!file) {
      alert('Please select a file first');
      return;
    }

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await api.post('/fem/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setUploadedData(response.data.data);
      setActiveTab('analyze');
      alert('File uploaded successfully!');
    } catch (error) {
      console.error('Upload error:', error);
      alert(error.response?.data?.error || 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleGenerateMockData = async () => {
    setGenerating(true);
    
    try {
      const response = await api.post('/fem/generate-mock-data', {
        pattern_type: parameters.patternType,
        target_cd: parameters.targetCD
      });

      setUploadedData({
        ...response.data.data,
        filepath: response.data.data.filepath
      });
      setActiveTab('analyze');
      alert('Mock data generated successfully!');
    } catch (error) {
      console.error('Generate error:', error);
      alert(error.response?.data?.error || 'Generation failed');
    } finally {
      setGenerating(false);
    }
  };

  const handleAnalyze = async () => {
    if (!uploadedData || !uploadedData.filepath) {
      alert('Please upload data first');
      return;
    }

    setAnalyzing(true);

    try {
      // Standard analysis
      const response = await api.post('/fem/analyze', {
        filepath: uploadedData.filepath,
        pattern_name: parameters.patternName,
        target_cd: parameters.targetCD,
        cd_tolerance: parameters.cdTolerance / 100
      });

      setAnalysisResults(response.data.results);
      
      // Advanced analysis
      const advancedResponse = await api.post('/fem/advanced-analysis', {
        pattern_name: parameters.patternName,
        target_cd: parameters.targetCD,
        cd_tolerance: parameters.cdTolerance / 100
      });

      setAdvancedMetrics(advancedResponse.data.advanced_metrics);
      
      // Generate plots
      const plotResponse = await api.post('/fem/generate-plots', {
        pattern_name: parameters.patternName,
        target_cd: parameters.targetCD,
        cd_tolerance: parameters.cdTolerance / 100,
        plot_types: ['contour', 'process_window', 'dof_el']
      });

      setPlots(plotResponse.data.plots);
      setActiveTab('results');
      alert('Analysis completed successfully!');
    } catch (error) {
      console.error('Analysis error:', error);
      alert(error.response?.data?.error || 'Analysis failed');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleReset = () => {
    setFile(null);
    setUploadedData(null);
    setAnalysisResults(null);
    setAdvancedMetrics(null);
    setPlots(null);
    setActiveTab('upload');
  };

  const handleSaveAnalysis = async () => {
    if (!user || !user.username) {
      alert('Please log in to save analysis');
      return;
    }

    if (!analysisResults) {
      alert('No analysis results to save');
      return;
    }

    setSaving(true);

    try {
      const result = await saveAnalysis(
        user.username,
        {
          ...analysisResults,
          advanced_metrics: advancedMetrics
        },
        analysisResults.chart_data,
        {
          tool: 'FEM',
          pattern_name: parameters.patternName,
          target_cd: parameters.targetCD,
          cd_tolerance: parameters.cdTolerance,
          pattern_type: parameters.patternType,
          data_source: uploadedData?.filepath ? 'uploaded' : 'mock',
          timestamp: new Date().toISOString()
        }
      );

      if (result.success) {
        alert(`Analysis saved successfully! ID: ${result.analysis_id}`);
      } else {
        alert('Failed to save analysis: ' + (result.error || 'Unknown error'));
      }
    } catch (error) {
      console.error('Save error:', error);
      alert('Failed to save analysis: ' + (error.response?.data?.error || error.message));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Focus-Exposure Matrix (FEM) Analysis
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Analyze dose-focus matrices to identify optimal lithography conditions and process margins
          </p>
        </div>

        {/* Tabs */}
        <div className="mb-6 border-b border-gray-200 dark:border-gray-700">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('upload')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'upload'
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
            >
              <Upload className="inline-block w-5 h-5 mr-2" />
              Upload Data
            </button>
            <button
              onClick={() => setActiveTab('analyze')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'analyze'
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
              disabled={!uploadedData}
            >
              <Target className="inline-block w-5 h-5 mr-2" />
              Configure Analysis
            </button>
            <button
              onClick={() => setActiveTab('results')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'results'
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
              disabled={!analysisResults}
            >
              <BarChart3 className="inline-block w-5 h-5 mr-2" />
              Results
            </button>
            <button
              onClick={() => setActiveTab('advanced')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'advanced'
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
              disabled={!advancedMetrics}
            >
              <Sparkles className="inline-block w-5 h-5 mr-2" />
              Advanced Analysis
            </button>
          </nav>
        </div>

        {/* Upload Tab */}
        {activeTab === 'upload' && (
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
              Upload FEM Data
            </h2>
            
            <div className="space-y-6">
              {/* File Upload */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Upload CSV File
                </label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-md">
                  <div className="space-y-1 text-center">
                    <Upload className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600 dark:text-gray-400">
                      <label className="relative cursor-pointer bg-white dark:bg-gray-800 rounded-md font-medium text-blue-600 hover:text-blue-500">
                        <span>Upload a file</span>
                        <input
                          type="file"
                          className="sr-only"
                          accept=".csv"
                          onChange={handleFileChange}
                        />
                      </label>
                      <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      CSV file with columns: exposure_dose, focus, critical_dimension
                    </p>
                  </div>
                </div>
                {file && (
                  <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                    Selected: {file.name}
                  </p>
                )}
              </div>

              <button
                onClick={handleUpload}
                disabled={!file || uploading}
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {uploading ? (
                  <>
                    <RefreshCw className="animate-spin mr-2 h-5 w-5" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-5 w-5" />
                    Upload File
                  </>
                )}
              </button>

              {/* Divider */}
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300 dark:border-gray-600"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400">
                    Or generate mock data
                  </span>
                </div>
              </div>

              {/* Mock Data Generation */}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Pattern Type
                  </label>
                  <select
                    value={parameters.patternType}
                    onChange={(e) => setParameters({ ...parameters, patternType: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="line">Line Pattern (45nm)</option>
                    <option value="contact">Contact Pattern (50nm)</option>
                    <option value="via">Via Pattern (60nm)</option>
                    <option value="dense">Dense Pattern (250nm)</option>
                    <option value="isolated">Isolated Pattern (300nm)</option>
                  </select>
                </div>

                <button
                  onClick={handleGenerateMockData}
                  disabled={generating}
                  className="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {generating ? (
                    <>
                      <RefreshCw className="animate-spin mr-2 h-5 w-5" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Grid className="mr-2 h-5 w-5" />
                      Generate Mock Data
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Analyze Tab */}
        {activeTab === 'analyze' && uploadedData && (
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
              Configure Analysis Parameters
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {/* Data Summary */}
              <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-3">
                  Data Summary
                </h3>
                <div className="space-y-2 text-sm">
                  <p className="text-gray-700 dark:text-gray-300">
                    <span className="font-medium">Data Points:</span> {uploadedData.rows || 'N/A'}
                  </p>
                  <p className="text-gray-700 dark:text-gray-300">
                    <span className="font-medium">Exposure Range:</span>{' '}
                    {uploadedData.exposure_range ? 
                      `${uploadedData.exposure_range.min.toFixed(1)} - ${uploadedData.exposure_range.max.toFixed(1)} mJ/cm²` 
                      : 'N/A'}
                  </p>
                  <p className="text-gray-700 dark:text-gray-300">
                    <span className="font-medium">Focus Range:</span>{' '}
                    {uploadedData.focus_range ? 
                      `${uploadedData.focus_range.min.toFixed(2)} - ${uploadedData.focus_range.max.toFixed(2)} μm` 
                      : 'N/A'}
                  </p>
                  <p className="text-gray-700 dark:text-gray-300">
                    <span className="font-medium">CD Range:</span>{' '}
                    {uploadedData.cd_range ? 
                      `${uploadedData.cd_range.min.toFixed(1)} - ${uploadedData.cd_range.max.toFixed(1)} nm` 
                      : 'N/A'}
                  </p>
                </div>
              </div>

              {/* Parameters */}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Pattern Name
                  </label>
                  <input
                    type="text"
                    value={parameters.patternName}
                    onChange={(e) => setParameters({ ...parameters, patternName: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Target CD (nm)
                  </label>
                  <input
                    type="number"
                    value={parameters.targetCD}
                    onChange={(e) => setParameters({ ...parameters, targetCD: parseFloat(e.target.value) })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    CD Tolerance (%)
                  </label>
                  <input
                    type="number"
                    value={parameters.cdTolerance}
                    onChange={(e) => setParameters({ ...parameters, cdTolerance: parseFloat(e.target.value) })}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  />
                </div>
              </div>
            </div>

            <button
              onClick={handleAnalyze}
              disabled={analyzing}
              className="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center text-lg font-medium"
            >
              {analyzing ? (
                <>
                  <RefreshCw className="animate-spin mr-2 h-6 w-6" />
                  Analyzing...
                </>
              ) : (
                <>
                  <TrendingUp className="mr-2 h-6 w-6" />
                  Analyze FEM Data
                </>
              )}
            </button>
          </div>
        )}

        {/* Results Tab */}
        {activeTab === 'results' && analysisResults && (
          <div className="space-y-6">
            {/* Metrics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Process Window */}
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Process Window
                </h3>
                {analysisResults.process_window.found ? (
                  <div className="space-y-2 text-sm">
                    <p className="text-gray-700 dark:text-gray-300">
                      <span className="font-medium">Exposure Range:</span><br />
                      {analysisResults.process_window.exposure_range[0].toFixed(1)} - {analysisResults.process_window.exposure_range[1].toFixed(1)} mJ/cm²
                    </p>
                    <p className="text-gray-700 dark:text-gray-300">
                      <span className="font-medium">Focus Range:</span><br />
                      {analysisResults.process_window.focus_range[0].toFixed(3)} - {analysisResults.process_window.focus_range[1].toFixed(3)} μm
                    </p>
                    <p className="text-gray-700 dark:text-gray-300">
                      <span className="font-medium">Area:</span> {analysisResults.process_window.area.toFixed(2)}
                    </p>
                    <p className="text-gray-700 dark:text-gray-300">
                      <span className="font-medium">In-Spec Points:</span> {analysisResults.process_window.in_spec_points}/{analysisResults.process_window.total_points}
                    </p>
                  </div>
                ) : (
                  <p className="text-red-600 dark:text-red-400">No in-spec region found</p>
                )}
              </div>

              {/* DOF/EL Metrics */}
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  DOF/EL Metrics
                </h3>
                <div className="space-y-2 text-sm">
                  <p className="text-gray-700 dark:text-gray-300">
                    <span className="font-medium">Average DOF:</span><br />
                    {analysisResults.dof_el.avg_dof.toFixed(4)} μm
                  </p>
                  <p className="text-gray-700 dark:text-gray-300">
                    <span className="font-medium">Max DOF:</span><br />
                    {analysisResults.dof_el.max_dof.toFixed(4)} μm
                  </p>
                  <p className="text-gray-700 dark:text-gray-300">
                    <span className="font-medium">Average EL:</span><br />
                    {analysisResults.dof_el.avg_el.toFixed(2)} mJ/cm²
                  </p>
                  <p className="text-gray-700 dark:text-gray-300">
                    <span className="font-medium">Max EL:</span><br />
                    {analysisResults.dof_el.max_el.toFixed(2)} mJ/cm²
                  </p>
                </div>
              </div>

              {/* Optimal Point */}
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Optimal Process Point
                </h3>
                {analysisResults.optimal_point.found ? (
                  <div className="space-y-2 text-sm">
                    <p className="text-gray-700 dark:text-gray-300">
                      <span className="font-medium">Exposure:</span><br />
                      {analysisResults.optimal_point.exposure.toFixed(1)} mJ/cm²
                    </p>
                    <p className="text-gray-700 dark:text-gray-300">
                      <span className="font-medium">Focus:</span><br />
                      {analysisResults.optimal_point.focus.toFixed(3)} μm
                    </p>
                    <p className="text-gray-700 dark:text-gray-300">
                      <span className="font-medium">CD:</span><br />
                      {analysisResults.optimal_point.cd.toFixed(2)} nm
                    </p>
                    <p className="text-gray-700 dark:text-gray-300">
                      <span className="font-medium">CD Deviation:</span><br />
                      {analysisResults.optimal_point.cd_deviation > 0 ? '+' : ''}{analysisResults.optimal_point.cd_deviation.toFixed(2)} nm
                    </p>
                  </div>
                ) : (
                  <p className="text-red-600 dark:text-red-400">No optimal point found</p>
                )}
              </div>
            </div>

            {/* Visualizations */}
            {plots && (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Visualizations
                </h3>

                {/* Interpretation Guide Banner */}
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-l-4 border-blue-500 p-4 mb-6">
                  <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2 flex items-center">
                    <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                    </svg>
                    How to Read FEM Contour Maps
                  </h4>
                  <div className="text-sm text-blue-800 dark:text-blue-200 space-y-2">
                    <p><strong>Axes:</strong> X-axis = Exposure Dose (mJ/cm²), Y-axis = Focus Position (μm)</p>
                    <p><strong>Contour Lines:</strong> Connect points with the same CD value (like elevation lines on a topographic map)</p>
                    <p><strong>Color Scale:</strong> Shows CD values - warmer colors (yellow/green) = larger CD, cooler colors (blue/purple) = smaller CD</p>
                    <p><strong>Process Window:</strong> The region where CD stays within specification (typically marked with red boundaries)</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-6">
                  {plots.contour && (
                    <div>
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="text-md font-medium text-gray-900 dark:text-white mb-1">
                            FEM Contour Map
                          </h4>
                          <p className="text-xs text-gray-600 dark:text-gray-400">
                            2D visualization of CD across exposure-focus space
                          </p>
                        </div>
                      </div>

                      {/* Reading Guide for Contour Map */}
                      <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg p-3 mb-3">
                        <p className="text-sm font-semibold text-purple-900 dark:text-purple-100 mb-2">📖 Reading This Map:</p>
                        <ul className="text-xs text-purple-800 dark:text-purple-200 space-y-1">
                          <li>• <strong>Contour Lines:</strong> Each line represents a constant CD value</li>
                          <li>• <strong>Line Spacing:</strong> Closely spaced lines = rapid CD change (high sensitivity)</li>
                          <li>• <strong>Wide Spacing:</strong> Gradual CD change (low sensitivity, more robust)</li>
                          <li>• <strong>Red Boundaries:</strong> Upper and lower spec limits (±{parameters.cdTolerance}% of target)</li>
                          <li>• <strong>Green Region:</strong> Process window where CD is in specification</li>
                          <li>• <strong>Optimal Point:</strong> Center of process window (best operating conditions)</li>
                        </ul>
                      </div>

                      <img 
                        src={`/api/v1/fem/download/${plots.contour}`}
                        alt="FEM Contour"
                        className="w-full rounded-lg border border-gray-300 dark:border-gray-600"
                      />

                      {/* Key Observations */}
                      <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded border border-green-200 dark:border-green-800">
                          <p className="text-xs font-semibold text-green-900 dark:text-green-100 mb-1">✓ Good Signs:</p>
                          <ul className="text-xs text-green-800 dark:text-green-200 space-y-1">
                            <li>• Large green region</li>
                            <li>• Widely spaced contours</li>
                            <li>• Centered optimal point</li>
                          </ul>
                        </div>
                        <div className="bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded border border-yellow-200 dark:border-yellow-800">
                          <p className="text-xs font-semibold text-yellow-900 dark:text-yellow-100 mb-1">⚠ Warning Signs:</p>
                          <ul className="text-xs text-yellow-800 dark:text-yellow-200 space-y-1">
                            <li>• Small green region</li>
                            <li>• Tightly packed contours</li>
                            <li>• Off-center optimal point</li>
                          </ul>
                        </div>
                        <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded border border-blue-200 dark:border-blue-800">
                          <p className="text-xs font-semibold text-blue-900 dark:text-blue-100 mb-1">📊 What to Report:</p>
                          <ul className="text-xs text-blue-800 dark:text-blue-200 space-y-1">
                            <li>• Process window size</li>
                            <li>• Optimal dose & focus</li>
                            <li>• CD sensitivity regions</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  )}

                  {plots.process_window && (
                    <div>
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="text-md font-medium text-gray-900 dark:text-white mb-1">
                            Process Window
                          </h4>
                          <p className="text-xs text-gray-600 dark:text-gray-400">
                            In-specification region with overlays
                          </p>
                        </div>
                      </div>

                      {/* Reading Guide for Process Window */}
                      <div className="bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800 rounded-lg p-3 mb-3">
                        <p className="text-sm font-semibold text-indigo-900 dark:text-indigo-100 mb-2">📖 Understanding Process Window:</p>
                        <ul className="text-xs text-indigo-800 dark:text-indigo-200 space-y-1">
                          <li>• <strong>Hatched/Shaded Region:</strong> Where CD meets specification</li>
                          <li>• <strong>Window Shape:</strong> Often tilted ellipse or irregular polygon</li>
                          <li>• <strong>Tilt Angle:</strong> Indicates correlation between dose and focus</li>
                          <li>• <strong>Window Size:</strong> Larger = more robust process, easier to control</li>
                          <li>• <strong>Multiple Islands:</strong> Disconnected regions may indicate process issues</li>
                        </ul>
                      </div>

                      <img 
                        src={`/api/v1/fem/download/${plots.process_window}`}
                        alt="Process Window"
                        className="w-full rounded-lg border border-gray-300 dark:border-gray-600"
                      />

                      {/* Process Window Interpretation */}
                      {analysisResults.process_window.found && (
                        <div className="mt-3 bg-gray-50 dark:bg-gray-700 p-3 rounded">
                          <p className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-2">Your Process Window Analysis:</p>
                          <div className="grid grid-cols-2 gap-3 text-xs">
                            <div>
                              <p className="text-gray-600 dark:text-gray-400 mb-1">Exposure Latitude (EL):</p>
                              <p className="font-mono text-gray-900 dark:text-gray-100">
                                {(analysisResults.process_window.exposure_range[1] - analysisResults.process_window.exposure_range[0]).toFixed(1)} mJ/cm²
                              </p>
                              <p className="text-gray-500 dark:text-gray-400 text-xs mt-1">
                                ({((analysisResults.process_window.exposure_range[1] - analysisResults.process_window.exposure_range[0]) / parameters.targetCD * 100).toFixed(1)}% of nominal)
                              </p>
                            </div>
                            <div>
                              <p className="text-gray-600 dark:text-gray-400 mb-1">Depth of Focus (DOF):</p>
                              <p className="font-mono text-gray-900 dark:text-gray-100">
                                {(analysisResults.process_window.focus_range[1] - analysisResults.process_window.focus_range[0]).toFixed(3)} μm
                              </p>
                              <p className="text-gray-500 dark:text-gray-400 text-xs mt-1">
                                ({(analysisResults.process_window.focus_range[1] - analysisResults.process_window.focus_range[0]) * 1000} nm)
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {plots.dof_el && (
                    <div>
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="text-md font-medium text-gray-900 dark:text-white mb-1">
                            DOF/EL Analysis
                          </h4>
                          <p className="text-xs text-gray-600 dark:text-gray-400">
                            Process margin trends across exposure and focus
                          </p>
                        </div>
                      </div>

                      {/* Reading Guide for DOF/EL */}
                      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-3 mb-3">
                        <p className="text-sm font-semibold text-amber-900 dark:text-amber-100 mb-2">📖 Interpreting DOF/EL Plots:</p>
                        <ul className="text-xs text-amber-800 dark:text-amber-200 space-y-1">
                          <li>• <strong>Top Plot (DOF vs Exposure):</strong> Shows how focus tolerance changes with dose</li>
                          <li>• <strong>Bottom Plot (EL vs Focus):</strong> Shows how dose tolerance changes with focus</li>
                          <li>• <strong>Peak Values:</strong> Indicate the best exposure or focus for maximum margin</li>
                          <li>• <strong>Flat Regions:</strong> Indicate robust operating conditions</li>
                          <li>• <strong>Sharp Drops:</strong> Indicate sensitive regions to avoid</li>
                        </ul>
                      </div>

                      <img 
                        src={`/api/v1/fem/download/${plots.dof_el}`}
                        alt="DOF/EL Analysis"
                        className="w-full rounded-lg border border-gray-300 dark:border-gray-600"
                      />

                      {/* Practical Recommendations */}
                      <div className="mt-3 bg-blue-50 dark:bg-blue-900/20 p-3 rounded border border-blue-200 dark:border-blue-800">
                        <p className="text-sm font-semibold text-blue-900 dark:text-blue-100 mb-2">💡 Practical Recommendations:</p>
                        <ul className="text-xs text-blue-800 dark:text-blue-200 space-y-1">
                          <li>• <strong>For Scanner Setup:</strong> Use exposure with maximum DOF</li>
                          <li>• <strong>For Focus Control:</strong> Operate at focus with maximum EL</li>
                          <li>• <strong>For Optimization:</strong> Balance DOF and EL based on your tool capabilities</li>
                          <li>• <strong>For Monitoring:</strong> Track these metrics over time to detect process drift</li>
                        </ul>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-4">
              <button
                onClick={handleSaveAnalysis}
                disabled={saving}
                className="flex-1 bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {saving ? (
                  <>
                    <RefreshCw className="animate-spin mr-2 h-5 w-5" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-5 w-5" />
                    Save to History
                  </>
                )}
              </button>
              <button
                onClick={handleReset}
                className="flex-1 bg-gray-600 text-white py-2 px-4 rounded-md hover:bg-gray-700 flex items-center justify-center"
              >
                <RefreshCw className="mr-2 h-5 w-5" />
                New Analysis
              </button>
            </div>
          </div>
        )}

        {/* Advanced Analysis Tab */}
        {activeTab === 'advanced' && advancedMetrics && analysisResults && (
          <div className="space-y-6">
            {/* Header Banner */}
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg shadow-lg p-6">
              <div className="flex items-center space-x-4">
                <Sparkles className="w-12 h-12" />
                <div>
                  <h2 className="text-2xl font-bold mb-1">Advanced FEM Analysis</h2>
                  <p className="text-blue-100">
                    Industry-standard metrics including Bossung curves, DOF at EL%, and process robustness scoring
                  </p>
                </div>
              </div>
            </div>

            {/* Bossung Curves */}
            {advancedMetrics.bossung_curves && (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  Bossung Curve Analysis
                </h3>
                <FEMBossungChart 
                  bossungData={advancedMetrics.bossung_curves}
                  targetCD={parameters.targetCD}
                  specLimits={analysisResults.chart_data?.spec_limits}
                />
              </div>
            )}

            {/* FEM Contour Map */}
            {analysisResults.chart_data && (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  FEM Contour Map (Interactive)
                </h3>
                <FEMContourChart 
                  chartData={analysisResults.chart_data}
                  optimalPoint={analysisResults.optimal_point}
                  advancedMetrics={advancedMetrics}
                />
              </div>
            )}

            {/* DOF at EL% */}
            {advancedMetrics.dof_at_el && (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  DOF at EL% (Industry Standard Metric)
                </h3>
                <DOFatELChart dofAtElData={advancedMetrics.dof_at_el} />
              </div>
            )}

            {/* Process Robustness Score */}
            {advancedMetrics.process_robustness_score && (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  Process Robustness Assessment
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className={`p-6 rounded-lg border-2 ${
                    advancedMetrics.process_robustness_score.score >= 80 
                      ? 'bg-green-50 dark:bg-green-900/20 border-green-500'
                      : advancedMetrics.process_robustness_score.score >= 60
                      ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-500'
                      : advancedMetrics.process_robustness_score.score >= 40
                      ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-500'
                      : 'bg-red-50 dark:bg-red-900/20 border-red-500'
                  }`}>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">
                      Overall Robustness Score
                    </p>
                    <p className="text-6xl font-bold mb-2">
                      {advancedMetrics.process_robustness_score.score}
                    </p>
                    <p className="text-2xl font-semibold mb-1">
                      {advancedMetrics.process_robustness_score.rating}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      out of {advancedMetrics.process_robustness_score.max_score} points
                    </p>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-semibold text-gray-900 dark:text-white">Score Breakdown:</h4>
                    <div className="space-y-3 text-sm">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-gray-700 dark:text-gray-300">Process Window Area</span>
                          <span className="font-medium">30 pts</span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div className="bg-blue-600 h-2 rounded-full" style={{width: '30%'}}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-gray-700 dark:text-gray-300">Depth of Focus</span>
                          <span className="font-medium">30 pts</span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div className="bg-green-600 h-2 rounded-full" style={{width: '30%'}}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-gray-700 dark:text-gray-300">Exposure Latitude</span>
                          <span className="font-medium">20 pts</span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div className="bg-purple-600 h-2 rounded-full" style={{width: '20%'}}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-gray-700 dark:text-gray-300">In-Spec Coverage</span>
                          <span className="font-medium">10 pts</span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div className="bg-yellow-600 h-2 rounded-full" style={{width: '10%'}}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-gray-700 dark:text-gray-300">Optimal Point Centering</span>
                          <span className="font-medium">10 pts</span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div className="bg-orange-600 h-2 rounded-full" style={{width: '10%'}}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* OPC Bias Recommendation */}
            {advancedMetrics.opc_bias_recommendation && (
              <div className={`rounded-lg shadow-md p-6 ${
                advancedMetrics.opc_bias_recommendation.recommended
                  ? 'bg-amber-50 dark:bg-amber-900/20 border-2 border-amber-500'
                  : 'bg-green-50 dark:bg-green-900/20 border-2 border-green-500'
              }`}>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  OPC Bias Recommendation
                </h3>
                <div className="space-y-3">
                  {advancedMetrics.opc_bias_recommendation.recommended ? (
                    <>
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0 w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                          !
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-amber-900 dark:text-amber-100 text-lg mb-2">
                            OPC Bias Adjustment Recommended
                          </p>
                          <p className="text-amber-800 dark:text-amber-200 mb-3">
                            {advancedMetrics.opc_bias_recommendation.reason}
                          </p>
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div className="bg-white dark:bg-gray-800 p-3 rounded">
                              <p className="text-gray-600 dark:text-gray-400 mb-1">Current CD</p>
                              <p className="text-xl font-bold text-gray-900 dark:text-white">
                                {advancedMetrics.opc_bias_recommendation.current_cd.toFixed(2)} nm
                              </p>
                            </div>
                            <div className="bg-white dark:bg-gray-800 p-3 rounded">
                              <p className="text-gray-600 dark:text-gray-400 mb-1">Target CD</p>
                              <p className="text-xl font-bold text-gray-900 dark:text-white">
                                {advancedMetrics.opc_bias_recommendation.target_cd.toFixed(2)} nm
                              </p>
                            </div>
                            <div className="bg-amber-100 dark:bg-amber-900/40 p-3 rounded">
                              <p className="text-amber-700 dark:text-amber-300 mb-1">Recommended Bias</p>
                              <p className="text-xl font-bold text-amber-900 dark:text-amber-100">
                                {advancedMetrics.opc_bias_recommendation.bias > 0 ? '+' : ''}
                                {advancedMetrics.opc_bias_recommendation.bias.toFixed(2)} nm
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-12 h-12 bg-green-500 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                        ✓
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-green-900 dark:text-green-100 text-lg mb-2">
                          No Bias Adjustment Needed
                        </p>
                        <p className="text-green-800 dark:text-green-200">
                          {advancedMetrics.opc_bias_recommendation.reason}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Technical Guide */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                Technical Guide & Recommendations
              </h3>
              <FEMTechnicalGuide 
                advancedMetrics={advancedMetrics}
                processWindow={analysisResults.process_window}
                dofEl={analysisResults.dof_el}
                optimalPoint={analysisResults.optimal_point}
              />
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <button
                onClick={handleSaveAnalysis}
                disabled={saving}
                className="flex-1 bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {saving ? (
                  <>
                    <RefreshCw className="animate-spin mr-2 h-5 w-5" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-5 w-5" />
                    Save to History
                  </>
                )}
              </button>
              <button
                onClick={() => setActiveTab('results')}
                className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 flex items-center justify-center"
              >
                <BarChart3 className="mr-2 h-5 w-5" />
                Back to Basic Results
              </button>
              <button
                onClick={handleReset}
                className="flex-1 bg-gray-600 text-white py-2 px-4 rounded-md hover:bg-gray-700 flex items-center justify-center"
              >
                <RefreshCw className="mr-2 h-5 w-5" />
                New Analysis
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
