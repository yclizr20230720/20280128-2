import { useState, useEffect } from 'react'
import { Clock, User, Download, Trash2, Eye, Search, Filter, AlertCircle, CheckCircle, Loader } from 'lucide-react'
import { listHistory, loadAnalysis, deleteAnalysis, exportAnalysis, getHistoryStats } from '../services/api'
import BossungChart from '../components/BossungChart'
import ProcessWindowChart from '../components/ProcessWindowChart'
import ProcessWindow3D from '../components/ProcessWindow3D'
import CDDistributionChart from '../components/CDDistributionChart'
import DoseSensitivityChart from '../components/DoseSensitivityChart'
import BestFocusChart from '../components/BestFocusChart'
import CDBestFocusChart from '../components/CDBestFocusChart'
import CurvatureChart from '../components/CurvatureChart'
import ModelFitChart from '../components/ModelFitChart'
import FEMBossungChart from '../components/FEMBossungChart'
import FEMContourChart from '../components/FEMContourChart'
import DOFatELChart from '../components/DOFatELChart'

const History = () => {
  const [historyList, setHistoryList] = useState([])
  const [stats, setStats] = useState(null)
  const [selectedAnalysis, setSelectedAnalysis] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [filterUsername, setFilterUsername] = useState('')
  const [filterTool, setFilterTool] = useState('all') // 'all', 'EDForest', 'FEM'
  const [viewMode, setViewMode] = useState('list') // 'list' or 'detail'

  useEffect(() => {
    loadHistoryList()
    loadStats()
  }, [])

  const loadHistoryList = async (username = null) => {
    setLoading(true)
    setError(null)
    try {
      const result = await listHistory(username)
      let filteredHistory = result.history || []
      
      // Filter by tool if not 'all'
      if (filterTool !== 'all') {
        filteredHistory = filteredHistory.filter(item => {
          const tool = item.parameters?.tool || 'EDForest' // Default to EDForest for backward compatibility
          return tool === filterTool
        })
      }
      
      setHistoryList(filteredHistory)
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to load history')
    } finally {
      setLoading(false)
    }
  }

  const loadStats = async () => {
    try {
      const result = await getHistoryStats()
      setStats(result.stats)
    } catch (err) {
      console.error('Failed to load stats:', err)
    }
  }

  const handleViewAnalysis = async (analysisId) => {
    setLoading(true)
    setError(null)
    try {
      const result = await loadAnalysis(analysisId)
      setSelectedAnalysis(result.data)
      setViewMode('detail')
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to load analysis')
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteAnalysis = async (analysisId) => {
    if (!confirm('Are you sure you want to delete this analysis?')) {
      return
    }

    setLoading(true)
    setError(null)
    try {
      await deleteAnalysis(analysisId)
      setSuccess('Analysis deleted successfully')
      loadHistoryList(filterUsername || null)
      loadStats()
      if (selectedAnalysis?.metadata?.timestamp === analysisId) {
        setSelectedAnalysis(null)
        setViewMode('list')
      }
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to delete analysis')
    } finally {
      setLoading(false)
    }
  }

  const handleExportAnalysis = async (analysisId, filename) => {
    try {
      await exportAnalysis(analysisId, filename)
      setSuccess('Analysis exported successfully')
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to export analysis')
    }
  }

  const handleFilterChange = (username) => {
    setFilterUsername(username)
    loadHistoryList(username || null)
  }

  const handleToolFilterChange = (tool) => {
    setFilterTool(tool)
    loadHistoryList(filterUsername || null)
  }

  const handleBackToList = () => {
    setSelectedAnalysis(null)
    setViewMode('list')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h1 className="text-4xl font-bold gradient-text mb-2">Analysis History</h1>
          <p className="text-gray-600">
            Review and manage your saved analyses from EDForest and FEM tools
          </p>
        </div>

        {/* Alerts */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-start">
            <AlertCircle className="w-5 h-5 text-red-600 mr-3 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-medium text-red-800">Error</h3>
              <p className="text-sm text-red-700 mt-1">{error}</p>
            </div>
          </div>
        )}

        {success && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6 flex items-start">
            <CheckCircle className="w-5 h-5 text-green-600 mr-3 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-medium text-green-800">Success</h3>
              <p className="text-sm text-green-700 mt-1">{success}</p>
            </div>
          </div>
        )}

        {viewMode === 'list' ? (
          <>
            {/* Statistics */}
            {stats && (
              <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Statistics</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <StatCard label="Total Analyses" value={stats.total_analyses} />
                  <StatCard label="Unique Users" value={stats.unique_users} />
                  <StatCard label="Your Analyses" value={stats.by_user[filterUsername] || 0} />
                  <StatCard label="This Month" value="N/A" />
                </div>
              </div>
            )}

            {/* Filters */}
            <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
              <div className="space-y-4">
                {/* Tool Filter */}
                <div className="flex items-center space-x-4">
                  <Filter className="w-5 h-5 text-gray-500" />
                  <span className="text-sm font-medium text-gray-700">Tool:</span>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleToolFilterChange('all')}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        filterTool === 'all'
                          ? 'bg-primary-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      All Tools
                    </button>
                    <button
                      onClick={() => handleToolFilterChange('EDForest')}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        filterTool === 'EDForest'
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      EDForest (Bossung)
                    </button>
                    <button
                      onClick={() => handleToolFilterChange('FEM')}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        filterTool === 'FEM'
                          ? 'bg-purple-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      FEM Analysis
                    </button>
                  </div>
                </div>

                {/* Username Filter */}
                <div className="flex items-center space-x-4">
                  <Search className="w-5 h-5 text-gray-500" />
                  <input
                    type="text"
                    placeholder="Filter by username..."
                    value={filterUsername}
                    onChange={(e) => handleFilterChange(e.target.value)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  />
                  {filterUsername && (
                    <button
                      onClick={() => handleFilterChange('')}
                      className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* History List */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">
                Saved Analyses ({historyList.length})
              </h2>

              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader className="w-8 h-8 animate-spin text-primary-600" />
                </div>
              ) : historyList.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-gray-500">No saved analyses found</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {historyList.map((item) => (
                    <HistoryCard
                      key={item.id}
                      item={item}
                      onView={() => handleViewAnalysis(item.id)}
                      onDelete={() => handleDeleteAnalysis(item.id)}
                      onExport={() => handleExportAnalysis(item.id, item.filename)}
                    />
                  ))}
                </div>
              )}
            </div>
          </>
        ) : (
          /* Detail View */
          <div className="space-y-8">
            {/* Back Button */}
            <button
              onClick={handleBackToList}
              className="flex items-center space-x-2 text-primary-600 hover:text-primary-700"
            >
              <span>← Back to List</span>
            </button>

            {selectedAnalysis && (
              <>
                {/* Analysis Info */}
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">Analysis Details</h2>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <InfoCard label="Username" value={selectedAnalysis.metadata.username} />
                    <InfoCard label="Date" value={selectedAnalysis.metadata.datetime} />
                    <InfoCard label="Target CD" value={`${selectedAnalysis.parameters.target_cd} nm`} />
                    <InfoCard label="Tolerance" value={`${selectedAnalysis.parameters.tolerance}%`} />
                  </div>
                </div>

                {/* Charts */}
                {selectedAnalysis.chart_data && (
                  <div className="space-y-8">
                    {/* Determine tool type */}
                    {(() => {
                      const toolType = selectedAnalysis.parameters?.tool || 'EDForest';
                      
                      if (toolType === 'FEM') {
                        // FEM Analysis Visualization
                        return (
                          <>
                            {/* FEM Main Analysis */}
                            <div className="space-y-6">
                              <div className="border-l-4 border-purple-500 pl-4">
                                <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-1">FEM Analysis</h2>
                                <p className="text-sm text-gray-600 dark:text-gray-300">Focus-Exposure Matrix analysis and process window evaluation</p>
                              </div>

                              {/* FEM Contour Chart */}
                              {selectedAnalysis.chart_data.contour && (
                                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                                    FEM Contour Map
                                  </h3>
                                  <FEMContourChart 
                                    chartData={selectedAnalysis.chart_data}
                                    optimalPoint={selectedAnalysis.analysis_results?.optimal_point}
                                    advancedMetrics={selectedAnalysis.analysis_results?.advanced_metrics}
                                  />
                                </div>
                              )}

                              {/* Bossung Curves */}
                              {selectedAnalysis.analysis_results?.advanced_metrics?.bossung_curves && (
                                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                                    Bossung Curve Analysis
                                  </h3>
                                  <FEMBossungChart 
                                    bossungData={selectedAnalysis.analysis_results.advanced_metrics.bossung_curves}
                                    targetCD={selectedAnalysis.parameters.target_cd}
                                    specLimits={selectedAnalysis.chart_data.spec_limits}
                                  />
                                </div>
                              )}

                              {/* DOF at EL% */}
                              {selectedAnalysis.analysis_results?.advanced_metrics?.dof_at_el && (
                                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                                    DOF at EL% Analysis
                                  </h3>
                                  <DOFatELChart 
                                    dofAtElData={selectedAnalysis.analysis_results.advanced_metrics.dof_at_el}
                                  />
                                </div>
                              )}
                            </div>

                            {/* FEM Process Metrics */}
                            {selectedAnalysis.analysis_results && (
                              <div className="space-y-6">
                                <div className="border-l-4 border-green-500 pl-4">
                                  <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-1">Process Metrics</h2>
                                  <p className="text-sm text-gray-600 dark:text-gray-300">Key performance indicators</p>
                                </div>

                                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                  {selectedAnalysis.analysis_results.process_window && (
                                    <>
                                      <MetricCard
                                        label="DOF"
                                        value={(selectedAnalysis.analysis_results.process_window.focus_range?.[1] - selectedAnalysis.analysis_results.process_window.focus_range?.[0])?.toFixed(3) || 'N/A'}
                                        unit="μm"
                                      />
                                      <MetricCard
                                        label="EL"
                                        value={(selectedAnalysis.analysis_results.process_window.exposure_range?.[1] - selectedAnalysis.analysis_results.process_window.exposure_range?.[0])?.toFixed(2) || 'N/A'}
                                        unit="mJ/cm²"
                                      />
                                    </>
                                  )}
                                  {selectedAnalysis.analysis_results.optimal_point && (
                                    <>
                                      <MetricCard
                                        label="Optimal Dose"
                                        value={selectedAnalysis.analysis_results.optimal_point.exposure?.toFixed(2) || 'N/A'}
                                        unit="mJ/cm²"
                                      />
                                      <MetricCard
                                        label="Optimal Focus"
                                        value={selectedAnalysis.analysis_results.optimal_point.focus?.toFixed(3) || 'N/A'}
                                        unit="μm"
                                      />
                                      <MetricCard
                                        label="Optimal CD"
                                        value={selectedAnalysis.analysis_results.optimal_point.cd?.toFixed(2) || 'N/A'}
                                        unit="nm"
                                      />
                                    </>
                                  )}
                                  {selectedAnalysis.analysis_results.process_window && (
                                    <MetricCard
                                      label="Process Window Area"
                                      value={selectedAnalysis.analysis_results.process_window.area?.toFixed(2) || 'N/A'}
                                      unit="units²"
                                    />
                                  )}
                                </div>
                              </div>
                            )}
                          </>
                        );
                      } else {
                        // EDForest (Bossung) Analysis Visualization
                        return (
                          <>
                            {/* Section 1: Main Analysis */}
                            <div className="space-y-6">
                              <div className="border-l-4 border-blue-500 pl-4">
                                <h2 className="text-2xl font-bold text-gray-900 mb-1">Main Analysis</h2>
                                <p className="text-sm text-gray-600">Core Bossung curve analysis and process window evaluation</p>
                              </div>

                              {/* 3D Process Window */}
                              <ProcessWindow3D 
                                data={selectedAnalysis.chart_data.process_window}
                                targetLines={selectedAnalysis.chart_data.target_lines}
                              />

                              <BossungChart 
                                data={selectedAnalysis.chart_data.bossung_curves}
                                targetLines={selectedAnalysis.chart_data.target_lines}
                                doses={selectedAnalysis.chart_data.doses}
                              />

                              <ProcessWindowChart 
                                data={selectedAnalysis.chart_data.process_window}
                                targetLines={selectedAnalysis.chart_data.target_lines}
                              />

                              <CDDistributionChart 
                                data={selectedAnalysis.chart_data.cd_distribution}
                                targetLines={selectedAnalysis.chart_data.target_lines}
                              />
                            </div>

                            {/* Section 2: Advanced Analysis */}
                            {selectedAnalysis.chart_data.advanced_metrics && (
                              <div className="space-y-6">
                                <div className="border-l-4 border-purple-500 pl-4">
                                  <h2 className="text-2xl font-bold text-gray-900 mb-1">Advanced Analysis</h2>
                                  <p className="text-sm text-gray-600">Curve fitting analysis and dose optimization metrics</p>
                                </div>

                                <DoseSensitivityChart 
                                  data={selectedAnalysis.chart_data.bossung_curves}
                                  targetLines={selectedAnalysis.chart_data.target_lines}
                                />

                                {selectedAnalysis.chart_data.advanced_metrics.best_focus_vs_dose?.length > 0 && (
                                  <BestFocusChart 
                                    data={selectedAnalysis.chart_data.advanced_metrics.best_focus_vs_dose}
                                  />
                                )}

                                {selectedAnalysis.chart_data.advanced_metrics.cd_at_best_focus?.length > 0 && (
                                  <CDBestFocusChart 
                                    data={selectedAnalysis.chart_data.advanced_metrics.cd_at_best_focus}
                                    targetLines={selectedAnalysis.chart_data.target_lines}
                                  />
                                )}
                              </div>
                            )}

                            {/* Section 3: Model Quality */}
                            {selectedAnalysis.chart_data.advanced_metrics && (
                              <div className="space-y-6">
                                <div className="border-l-4 border-orange-500 pl-4">
                                  <h2 className="text-2xl font-bold text-gray-900 mb-1">Model Quality</h2>
                                  <p className="text-sm text-gray-600">Curve fitting quality and process robustness indicators</p>
                                </div>

                                {selectedAnalysis.chart_data.advanced_metrics.curvature_vs_dose?.length > 0 && (
                                  <CurvatureChart 
                                    data={selectedAnalysis.chart_data.advanced_metrics.curvature_vs_dose}
                                  />
                                )}

                                {selectedAnalysis.chart_data.advanced_metrics.model_fit_quality?.length > 0 && (
                                  <ModelFitChart 
                                    data={selectedAnalysis.chart_data.advanced_metrics.model_fit_quality}
                                  />
                                )}
                              </div>
                            )}

                            {/* Process Metrics */}
                            {selectedAnalysis.analysis_results && (
                              <div className="space-y-6">
                                <div className="border-l-4 border-green-500 pl-4">
                                  <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-1">Process Metrics</h2>
                                  <p className="text-sm text-gray-600 dark:text-gray-300">Key performance indicators</p>
                                </div>

                                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                  <MetricCard
                                    label="DOF"
                                    value={selectedAnalysis.analysis_results.process_window.dof.toFixed(3)}
                                    unit="μm"
                                  />
                                  <MetricCard
                                    label="EL"
                                    value={selectedAnalysis.analysis_results.process_window.el.toFixed(2)}
                                    unit="mJ/cm²"
                                  />
                                  <MetricCard
                                    label="Optimal Dose"
                                    value={selectedAnalysis.analysis_results.process_window.optimal_dose.toFixed(2)}
                                    unit="mJ/cm²"
                                  />
                                  <MetricCard
                                    label="Yield"
                                    value={selectedAnalysis.analysis_results.process_window.yield_percent.toFixed(1)}
                                    unit="%"
                                  />
                                  <MetricCard
                                    label="Mean CD"
                                    value={selectedAnalysis.analysis_results.cd_statistics.mean.toFixed(2)}
                                    unit="nm"
                                  />
                                  <MetricCard
                                    label="Std Dev"
                                    value={selectedAnalysis.analysis_results.cd_statistics.std.toFixed(2)}
                                    unit="nm"
                                  />
                                </div>
                              </div>
                            )}
                          </>
                        );
                      }
                    })()}
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

const HistoryCard = ({ item, onView, onDelete, onExport }) => (
  <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:border-primary-400 dark:hover:border-primary-500 hover:shadow-md transition-all bg-white dark:bg-gray-800">
    <div className="flex items-start justify-between">
      <div className="flex-1">
        <div className="flex items-center space-x-3 mb-2">
          <User className="w-5 h-5 text-gray-500 dark:text-gray-400" />
          <span className="font-semibold text-gray-900 dark:text-gray-100">{item.username}</span>
          <Clock className="w-4 h-4 text-gray-400 dark:text-gray-500" />
          <span className="text-sm text-gray-600 dark:text-gray-300">{item.datetime}</span>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm mt-3">
          <div>
            <span className="text-gray-500 dark:text-gray-400">Target CD:</span>
            <span className="ml-2 font-medium text-gray-900 dark:text-gray-100">{item.parameters.target_cd} nm</span>
          </div>
          <div>
            <span className="text-gray-500 dark:text-gray-400">Tolerance:</span>
            <span className="ml-2 font-medium text-gray-900 dark:text-gray-100">{item.parameters.tolerance}%</span>
          </div>
          <div>
            <span className="text-gray-500 dark:text-gray-400">DOF:</span>
            <span className="ml-2 font-medium text-gray-900 dark:text-gray-100">{item.summary.dof?.toFixed(3)} μm</span>
          </div>
          <div>
            <span className="text-gray-500 dark:text-gray-400">Yield:</span>
            <span className="ml-2 font-medium text-gray-900 dark:text-gray-100">{item.summary.yield?.toFixed(1)}%</span>
          </div>
        </div>
      </div>

      <div className="flex items-center space-x-2 ml-4">
        <button
          onClick={onView}
          className="p-2 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg transition-colors"
          title="View Analysis"
        >
          <Eye className="w-5 h-5" />
        </button>
        <button
          onClick={onExport}
          className="p-2 text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900/30 rounded-lg transition-colors"
          title="Export JSON"
        >
          <Download className="w-5 h-5" />
        </button>
        <button
          onClick={onDelete}
          className="p-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg transition-colors"
          title="Delete"
        >
          <Trash2 className="w-5 h-5" />
        </button>
      </div>
    </div>
  </div>
)

const StatCard = ({ label, value }) => (
  <div className="bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-primary-900/30 dark:to-secondary-900/30 rounded-lg p-4 border border-primary-100 dark:border-primary-800">
    <div className="text-sm text-gray-600 dark:text-gray-300 mb-1 font-medium">{label}</div>
    <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">{value}</div>
  </div>
)

const InfoCard = ({ label, value }) => (
  <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 border border-gray-200 dark:border-gray-700">
    <div className="text-xs text-gray-600 dark:text-gray-400 mb-1 font-medium">{label}</div>
    <div className="text-sm font-semibold text-gray-900 dark:text-gray-100">{value}</div>
  </div>
)

const MetricCard = ({ label, value, unit }) => (
  <div className="bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-primary-900/30 dark:to-secondary-900/30 rounded-lg p-4 border border-primary-100 dark:border-primary-800">
    <div className="text-sm text-gray-600 dark:text-gray-300 mb-1 font-medium">{label}</div>
    <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">
      {value} <span className="text-sm font-normal text-gray-600 dark:text-gray-400">{unit}</span>
    </div>
  </div>
)

export default History
