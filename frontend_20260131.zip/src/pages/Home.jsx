import { Link } from 'react-router-dom'
import { useState, useEffect } from 'react'
import ToolCard from '../components/ToolCard'
import { 
  BarChart3, 
  Target, 
  Ruler, 
  RefreshCw, 
  Microscope, 
  Settings, 
  Search, 
  TrendingUp,
  CheckCircle,
  ArrowRight,
  Sparkles
} from 'lucide-react'
import { getHistoryStats } from '../services/api'

const Home = () => {
  const [stats, setStats] = useState({
    total_analyses: 0,
    unique_users: 0,
    monthly_count: 0,
    by_tool: {}
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadStats()
  }, [])

  const loadStats = async () => {
    try {
      const result = await getHistoryStats()
      if (result.success) {
        setStats({
          total_analyses: result.stats.total_analyses || 0,
          unique_users: result.stats.unique_users || 0,
          monthly_count: result.stats.monthly_count || 0,
          by_tool: result.stats.by_tool || {},
          users_per_tool: result.stats.users_per_tool || {}
        })
      }
    } catch (error) {
      console.error('Failed to load stats:', error)
    } finally {
      setLoading(false)
    }
  }

  const tools = [
    {
      icon: BarChart3,
      title: 'EDForest - Bossung Curve Analysis',
      description: 'Generate professional Bossung curves and analyze process windows with advanced DOF and EL metrics calculation.',
      features: [
        'Upload CSV data or generate mock data',
        'Interactive Bossung curves visualization',
        'Process window metrics (DOF, EL)',
        'Export plots in PNG/PDF formats'
      ],
      link: '/edforest',
      status: 'active'
    },
    {
      icon: Target,
      title: 'Focus-Exposure Matrix (FEM)',
      description: 'Analyze dose-focus matrices to identify optimal lithography conditions and process margins.',
      features: [
        'Contour map visualization',
        'Optimal point detection',
        'Process window extraction',
        'Multi-pattern analysis'
      ],
      link: '/fem',
      status: 'active'
    },
    {
      icon: Ruler,
      title: 'CD Uniformity Analysis',
      description: 'Evaluate critical dimension uniformity across wafer with statistical analysis and trend monitoring.',
      features: [
        'Wafer map visualization',
        'Statistical analysis (mean, std, range)',
        'Trend charts and histograms',
        'Zone-based analysis'
      ],
      link: '/cd-uniformity',
      status: 'coming-soon'
    },
    {
      icon: RefreshCw,
      title: 'Overlay Analysis',
      description: 'Analyze overlay performance and alignment accuracy with vector plots and CPK analysis.',
      features: [
        'Vector field plots',
        'CPK and PPK analysis',
        'Trend monitoring',
        'Correctables extraction'
      ],
      link: '/overlay',
      status: 'coming-soon'
    },
    {
      icon: Microscope,
      title: 'Scanner Performance Monitor',
      description: 'Real-time scanner performance tracking with comprehensive diagnostics and alert system.',
      features: [
        'Live performance dashboards',
        'Alert and notification system',
        'Historical trend analysis',
        'Equipment health scoring'
      ],
      link: '/scanner-monitor',
      status: 'coming-soon'
    },
    {
      icon: Settings,
      title: 'Track Equipment Monitor',
      description: 'Monitor track equipment parameters including temperature, humidity, and maintenance status.',
      features: [
        'Real-time parameter tracking',
        'Maintenance alerts',
        'Recipe management',
        'Performance trending'
      ],
      link: '/track-monitor',
      status: 'coming-soon'
    },
    {
      icon: Search,
      title: 'Defect Analysis',
      description: 'Comprehensive defect pattern analysis with root cause identification and classification.',
      features: [
        'Pareto charts',
        'Spatial defect mapping',
        'Defect classification',
        'Root cause analysis'
      ],
      link: '/defect-analysis',
      status: 'coming-soon'
    },
    {
      icon: TrendingUp,
      title: 'Yield Prediction',
      description: 'Predict yield based on process parameters using machine learning models and what-if analysis.',
      features: [
        'ML-based predictions',
        'What-if scenario analysis',
        'Parameter optimization',
        'Actionable recommendations'
      ],
      link: '/yield-prediction',
      status: 'coming-soon'
    }
  ]

  const benefits = [
    'Reduce analysis time by 80% with automated workflows',
    'Improve process yield through data-driven insights',
    'Standardize analysis methods across teams',
    'Track historical trends and process improvements',
    'Export publication-ready charts and reports',
    'Integrate with existing fab data systems'
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-primary-600 to-secondary-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid md:grid-cols-2 gap-6 items-center">
            <div className="animate-fade-in">
              <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-3">
                <Sparkles className="w-4 h-4" />
                <span className="text-sm font-medium">Advanced Lithography Analytics</span>
              </div>
              <h1 className="text-4xl font-extrabold mb-3">
                VSMC Litho Platform
              </h1>
              <p className="text-lg text-blue-100 mb-4">
                Modern web portal for scanner, track, and lithography process data analysis. 
                Transform your fab data into actionable insights.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link
                  to="/edforest"
                  className="inline-flex items-center space-x-2 bg-white text-primary-600 px-5 py-2.5 rounded-lg font-semibold hover:bg-blue-50 transition-colors text-sm"
                >
                  <span>Start Analysis</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  to="/history"
                  className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-sm text-white px-5 py-2.5 rounded-lg font-semibold hover:bg-white/20 transition-colors border border-white/30 text-sm"
                >
                  <span>View History</span>
                </Link>
              </div>
            </div>

            {/* Compact Stats Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
                <div className="text-3xl font-bold mb-1">
                  {loading ? '...' : `2/${tools.length}`}
                </div>
                <div className="text-xs text-blue-100">Available Tools</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
                <div className="text-3xl font-bold mb-1">
                  {loading ? '...' : stats.unique_users}
                </div>
                <div className="text-xs text-blue-100">Active Users</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
                <div className="text-3xl font-bold mb-1">
                  {loading ? '...' : stats.monthly_count}
                </div>
                <div className="text-xs text-blue-100">This Month</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
                <div className="text-3xl font-bold mb-1">
                  {loading ? '...' : stats.total_analyses}
                </div>
                <div className="text-xs text-blue-100">Total Cases</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tools Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Analysis Tools</h2>
          <p className="text-gray-600">
            Comprehensive suite of lithography analysis tools for process optimization
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {tools.map((tool, index) => (
            <div key={index} className="animate-fade-in" style={{ animationDelay: `${index * 0.05}s` }}>
              <ToolCard 
                {...tool} 
                caseCount={tool.status === 'active' ? (stats.by_tool?.EDForest || 0) : 0}
                userCount={tool.status === 'active' ? (stats.users_per_tool?.EDForest || 0) : 0}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Benefits Section */}
      <div className="bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">
                Why Choose VSMC Litho Platform?
              </h2>
              <p className="text-gray-600 mb-4 text-sm">
                Streamline your lithography data analysis workflow with our comprehensive platform. 
                Built by engineers, for engineers.
              </p>
              <div className="space-y-2">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700 text-sm">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-primary-900/30 dark:to-secondary-900/30 rounded-xl p-6 border border-primary-200 dark:border-primary-700">
              <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-3">Get Started Today</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4 text-sm">
                Start analyzing your lithography data in minutes. No installation required, 
                just upload your data and get instant insights.
              </p>
              <div className="space-y-3">
                <Link
                  to="/edforest"
                  className="block w-full bg-primary-600 text-white text-center px-5 py-2.5 rounded-lg font-semibold hover:bg-primary-700 transition-colors text-sm"
                >
                  Try EDForest Tool
                </Link>
                <Link
                  to="/about"
                  className="block w-full bg-white text-primary-600 text-center px-5 py-2.5 rounded-lg font-semibold hover:bg-gray-50 transition-colors border border-primary-200 text-sm"
                >
                  Learn More
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-primary-600 to-secondary-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-3">Ready to Optimize Your Process?</h2>
            <p className="text-lg text-blue-100 mb-6 max-w-2xl mx-auto">
              Join leading semiconductor fabs using VSMC Litho Platform for data-driven process optimization
            </p>
            <Link
              to="/edforest"
              className="inline-flex items-center space-x-2 bg-white text-primary-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              <span>Start Free Analysis</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home
