import { useMemo } from 'react'
import { Info } from 'lucide-react'

const ProcessWindowChart = ({ data, targetLines }) => {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-50 rounded-lg">
        <p className="text-gray-500">No data available</p>
      </div>
    )
  }

  // Create a grid for heatmap visualization
  const { gridData, doses, defocusValues, cdMin, cdMax } = useMemo(() => {
    const uniqueDoses = [...new Set(data.map(d => d.dose))].sort((a, b) => a - b)
    const uniqueDefocus = [...new Set(data.map(d => d.defocus))].sort((a, b) => a - b)
    
    // Create grid
    const grid = {}
    data.forEach(point => {
      const key = `${point.dose}_${point.defocus}`
      grid[key] = point.cd
    })
    
    const cdValues = data.map(d => d.cd)
    
    return {
      gridData: grid,
      doses: uniqueDoses,
      defocusValues: uniqueDefocus,
      cdMin: Math.min(...cdValues),
      cdMax: Math.max(...cdValues)
    }
  }, [data])

  // Color scale function (RdYlGn_r - Red-Yellow-Green reversed)
  const getColor = (cd) => {
    if (!targetLines) {
      // Default gradient from blue to red
      const normalized = (cd - cdMin) / (cdMax - cdMin)
      const r = Math.round(normalized * 255)
      const b = Math.round((1 - normalized) * 255)
      return `rgb(${r}, 100, ${b})`
    }
    
    const { target_cd, upper_limit, lower_limit } = targetLines
    const tolerance = upper_limit - target_cd
    
    // Calculate deviation from target
    const deviation = Math.abs(cd - target_cd) / tolerance
    
    if (cd >= lower_limit && cd <= upper_limit) {
      // Green zone - in spec
      const intensity = Math.max(0, 1 - deviation)
      return `rgb(${Math.round(255 * (1 - intensity))}, ${Math.round(200 + 55 * intensity)}, ${Math.round(100 * (1 - intensity))})`
    } else if (cd < lower_limit) {
      // Blue zone - below target
      const intensity = Math.min(1, (target_cd - cd) / tolerance)
      return `rgb(${Math.round(100 * (1 - intensity))}, ${Math.round(150 * (1 - intensity))}, ${Math.round(200 + 55 * intensity)})`
    } else {
      // Red zone - above target
      const intensity = Math.min(1, (cd - target_cd) / tolerance)
      return `rgb(${Math.round(200 + 55 * intensity)}, ${Math.round(100 * (1 - intensity))}, ${Math.round(100 * (1 - intensity))})`
    }
  }

  // Calculate cell dimensions
  const cellWidth = 600 / doses.length
  const cellHeight = 400 / defocusValues.length

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg border border-gray-200">
      {/* Header with explanation */}
      <div className="mb-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-xl font-bold text-gray-900">Process Window - Dose-Focus Matrix Heatmap</h3>
          <div className="group relative">
            <Info className="w-5 h-5 text-blue-500 cursor-help" />
            <div className="invisible group-hover:visible absolute right-0 w-96 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
              <p className="font-semibold mb-2">Understanding Process Window:</p>
              <ul className="space-y-1 text-xs">
                <li>• Heatmap shows CD values across all dose-focus combinations</li>
                <li>• Green cells = CD within specification (good process)</li>
                <li>• Blue cells = CD below target (underexposed)</li>
                <li>• Red cells = CD above target (overexposed)</li>
                <li>• Larger green region = more robust manufacturing process</li>
                <li>• Process window = area where CD stays within tolerance</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Manufacturing Insight:</span> The process window defines the safe operating region for your lithography tool. 
            A larger green area means your process can tolerate more variation in dose and focus, leading to higher yield and better manufacturability. 
            The optimal process point is typically at the center of the largest green region.
          </p>
        </div>
      </div>
      
      <div className="relative" style={{ width: '100%', maxWidth: '800px', margin: '0 auto' }}>
        {/* Chart container */}
        <div className="relative bg-gray-50 rounded-lg p-8">
          {/* Y-axis label */}
          <div className="absolute left-2 top-1/2 transform -translate-y-1/2 -rotate-90">
            <span className="text-sm font-bold text-gray-700">Defocus (μm)</span>
          </div>
          
          {/* Main heatmap */}
          <div className="ml-12 mb-12">
            <svg width="600" height="400" className="border border-gray-300">
              {/* Draw heatmap cells */}
              {defocusValues.map((defocus, i) => (
                doses.map((dose, j) => {
                  const cd = gridData[`${dose}_${defocus}`]
                  if (cd === undefined) return null
                  
                  return (
                    <g key={`${dose}_${defocus}`}>
                      <rect
                        x={j * cellWidth}
                        y={(defocusValues.length - 1 - i) * cellHeight}
                        width={cellWidth}
                        height={cellHeight}
                        fill={getColor(cd)}
                        stroke="#fff"
                        strokeWidth="1"
                      />
                      <title>{`Dose: ${dose.toFixed(1)} mJ/cm²\nDefocus: ${defocus.toFixed(2)} μm\nCD: ${cd.toFixed(2)} nm`}</title>
                    </g>
                  )
                })
              ))}
              
              {/* Y-axis ticks */}
              {defocusValues.filter((_, i) => i % 4 === 0).map((defocus, i) => {
                const y = (defocusValues.length - 1 - defocusValues.indexOf(defocus)) * cellHeight
                return (
                  <text
                    key={`y-${i}`}
                    x="-5"
                    y={y + cellHeight / 2}
                    textAnchor="end"
                    fontSize="11"
                    fill="#374151"
                    dominantBaseline="middle"
                  >
                    {defocus.toFixed(2)}
                  </text>
                )
              })}
              
              {/* X-axis ticks */}
              {doses.filter((_, i) => i % 2 === 0).map((dose, i) => {
                const x = doses.indexOf(dose) * cellWidth + cellWidth / 2
                return (
                  <text
                    key={`x-${i}`}
                    x={x}
                    y={410}
                    textAnchor="middle"
                    fontSize="11"
                    fill="#374151"
                  >
                    {dose.toFixed(1)}
                  </text>
                )
              })}
            </svg>
            
            {/* X-axis label */}
            <div className="text-center mt-2">
              <span className="text-sm font-bold text-gray-700">Exposure Dose (mJ/cm²)</span>
            </div>
          </div>
          
          {/* Color scale legend */}
          <div className="mt-6 flex items-center justify-center gap-4">
            <span className="text-xs text-gray-600">{cdMin.toFixed(1)} nm</span>
            <div className="flex h-6 w-64 rounded overflow-hidden border border-gray-300">
              {Array.from({ length: 50 }).map((_, i) => {
                const cd = cdMin + (cdMax - cdMin) * (i / 50)
                return (
                  <div
                    key={i}
                    style={{
                      width: '2%',
                      backgroundColor: getColor(cd)
                    }}
                  />
                )
              })}
            </div>
            <span className="text-xs text-gray-600">{cdMax.toFixed(1)} nm</span>
          </div>
          
          {/* Legend */}
          <div className="flex justify-center gap-6 mt-4 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: getColor(targetLines?.target_cd || cdMin) }}></div>
              <span className="text-gray-700">In Spec (Target ±{targetLines ? ((targetLines.upper_limit - targetLines.target_cd).toFixed(1)) : '0'}%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: getColor(cdMin) }}></div>
              <span className="text-gray-700">Below Target</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: getColor(cdMax) }}></div>
              <span className="text-gray-700">Above Target</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Key Takeaways */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 p-4 rounded-lg border border-green-200">
          <p className="text-xs font-semibold text-green-800 mb-1">✓ Large Green Area</p>
          <p className="text-xs text-gray-700">Indicates robust process with good tolerance to variations</p>
        </div>
        <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
          <p className="text-xs font-semibold text-yellow-800 mb-1">⚠ Narrow Window</p>
          <p className="text-xs text-gray-700">Small green region requires tight process control</p>
        </div>
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <p className="text-xs font-semibold text-blue-800 mb-1">💡 Optimal Point</p>
          <p className="text-xs text-gray-700">Center of green region provides maximum process margin</p>
        </div>
      </div>
    </div>
  )
}

export default ProcessWindowChart
