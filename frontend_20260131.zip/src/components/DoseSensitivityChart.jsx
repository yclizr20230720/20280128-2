import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts'
import { Info } from 'lucide-react'

const DoseSensitivityChart = ({ data, targetLines }) => {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-50 rounded-lg">
        <p className="text-gray-500">No data available</p>
      </div>
    )
  }

  // Select key defocus values for clarity
  const defocusValues = [...new Set(data.map(d => d.defocus))].sort((a, b) => a - b)
  const selectedDefocus = defocusValues.filter((_, i) => i % 4 === 0)
  
  // Group data by defocus
  const groupedData = {}
  data.forEach(point => {
    if (selectedDefocus.includes(point.defocus)) {
      const key = point.dose
      if (!groupedData[key]) {
        groupedData[key] = { dose: point.dose }
      }
      groupedData[key][`defocus_${point.defocus.toFixed(2)}`] = point.cd
    }
  })
  
  const chartData = Object.values(groupedData).sort((a, b) => a.dose - b.dose)
  
  const colors = ['#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981']

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg">
      {/* Header with explanation */}
      <div className="mb-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-xl font-bold text-gray-900">Dose Sensitivity at Different Defocus Values</h3>
          <div className="group relative">
            <Info className="w-5 h-5 text-blue-500 cursor-help" />
            <div className="invisible group-hover:visible absolute right-0 w-80 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
              <p className="font-semibold mb-2">Understanding Dose Sensitivity:</p>
              <ul className="space-y-1 text-xs">
                <li>• Shows how CD changes with exposure dose at different focus positions</li>
                <li>• Steeper slopes = higher dose sensitivity</li>
                <li>• Flatter curves = more robust process</li>
                <li>• Look for dose where curves intersect target CD</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Engineering Insight:</span> This chart helps identify the optimal exposure dose 
            by showing CD response across different focus conditions. The dose where multiple curves intersect near the target 
            CD indicates a robust process point with good focus tolerance.
          </p>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={500}>
        <LineChart data={chartData} margin={{ top: 20, right: 120, left: 20, bottom: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#d1d5db" opacity={0.5} />
          <XAxis 
            dataKey="dose" 
            label={{ value: 'Exposure Dose (mJ/cm²)', position: 'insideBottom', offset: -10, style: { fontSize: 14, fontWeight: 'bold' } }}
            stroke="#374151"
            tick={{ fontSize: 12 }}
          />
          <YAxis 
            label={{ value: 'Critical Dimension (nm)', angle: -90, position: 'insideLeft', style: { fontSize: 14, fontWeight: 'bold' } }}
            stroke="#374151"
            tick={{ fontSize: 12 }}
          />
          <Tooltip 
            contentStyle={{ backgroundColor: '#fff', border: '1px solid #d1d5db', borderRadius: '8px', padding: '12px' }}
            formatter={(value, name) => {
              if (value === undefined) return null
              const defocus = name.replace('defocus_', '')
              return [`${value.toFixed(2)} nm`, `Defocus: ${defocus} μm`]
            }}
            labelFormatter={(label) => `Dose: ${label.toFixed(1)} mJ/cm²`}
          />
          <Legend 
            wrapperStyle={{ paddingTop: '20px', fontSize: '11px' }}
            formatter={(value) => value.replace('defocus_', '') + ' μm'}
          />
          
          {targetLines && (
            <ReferenceLine 
              y={targetLines.target_cd} 
              stroke="#dc2626" 
              strokeDasharray="5 5"
              strokeWidth={2}
              label={{ value: 'Target CD', fill: '#dc2626', fontSize: 12, fontWeight: 'bold', position: 'right' }}
            />
          )}
          
          {selectedDefocus.map((defocus, index) => (
            <Line
              key={`defocus_${defocus.toFixed(2)}`}
              type="monotone"
              dataKey={`defocus_${defocus.toFixed(2)}`}
              stroke={colors[index % colors.length]}
              strokeWidth={2.5}
              dot={{ r: 5 }}
              activeDot={{ r: 7 }}
              connectNulls
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
      
      {/* Key Takeaways */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-green-800 mb-1">✓ Good Process</p>
          <p className="text-xs text-gray-700">Curves converge near target with minimal spread</p>
        </div>
        <div className="bg-yellow-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-yellow-800 mb-1">⚠ Watch Out</p>
          <p className="text-xs text-gray-700">Large separation between curves indicates focus sensitivity</p>
        </div>
        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-blue-800 mb-1">💡 Tip</p>
          <p className="text-xs text-gray-700">Choose dose where curves are closest together</p>
        </div>
      </div>
    </div>
  )
}

export default DoseSensitivityChart
