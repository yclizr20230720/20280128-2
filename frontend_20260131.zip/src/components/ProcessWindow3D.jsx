import { useState, useEffect } from 'react'
import Plot from 'react-plotly.js'
import { Info, Maximize2, RotateCcw } from 'lucide-react'

const ProcessWindow3D = ({ data, targetLines }) => {
  const [viewAngle, setViewAngle] = useState({ eye: { x: 1.5, y: 1.5, z: 1.3 } })
  const [showInfo, setShowInfo] = useState(false)

  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-50 rounded-lg">
        <p className="text-gray-500">No data available for 3D visualization</p>
      </div>
    )
  }

  // Prepare data for 3D surface plot
  const doses = [...new Set(data.map(d => d.dose))].sort((a, b) => a - b)
  const defocuses = [...new Set(data.map(d => d.defocus))].sort((a, b) => a - b)
  
  // Create 2D grid for CD values
  const cdGrid = []
  for (let i = 0; i < defocuses.length; i++) {
    const row = []
    for (let j = 0; j < doses.length; j++) {
      const point = data.find(d => 
        Math.abs(d.defocus - defocuses[i]) < 0.001 && 
        Math.abs(d.dose - doses[j]) < 0.001
      )
      row.push(point ? point.cd : null)
    }
    cdGrid.push(row)
  }

  // Create color scale based on spec limits
  const getColorScale = () => {
    if (!targetLines) {
      return 'Viridis'
    }

    const { target_cd, upper_limit, lower_limit } = targetLines
    
    // Custom colorscale: Red (out of spec) -> Green (in spec) -> Red (out of spec)
    return [
      [0, '#dc2626'],      // Red (low, out of spec)
      [0.2, '#f59e0b'],    // Orange (approaching spec)
      [0.3, '#fbbf24'],    // Yellow (edge of spec)
      [0.4, '#84cc16'],    // Light green (in spec)
      [0.5, '#22c55e'],    // Green (optimal)
      [0.6, '#84cc16'],    // Light green (in spec)
      [0.7, '#fbbf24'],    // Yellow (edge of spec)
      [0.8, '#f59e0b'],    // Orange (approaching spec)
      [1, '#dc2626']       // Red (high, out of spec)
    ]
  }

  // Create 3D surface trace
  const surfaceTrace = {
    type: 'surface',
    x: doses,
    y: defocuses,
    z: cdGrid,
    colorscale: getColorScale(),
    colorbar: {
      title: 'CD (nm)',
      titleside: 'right',
      thickness: 20,
      len: 0.7,
      tickfont: { size: 10 }
    },
    contours: {
      z: {
        show: true,
        usecolormap: true,
        highlightcolor: '#444',
        project: { z: true }
      }
    },
    lighting: {
      ambient: 0.8,
      diffuse: 0.8,
      specular: 0.2,
      roughness: 0.5,
      fresnel: 0.2
    },
    hovertemplate: 
      '<b>Dose</b>: %{x:.2f} mJ/cm²<br>' +
      '<b>Defocus</b>: %{y:.3f} μm<br>' +
      '<b>CD</b>: %{z:.2f} nm<br>' +
      '<extra></extra>'
  }

  // Add target plane if available
  const traces = [surfaceTrace]
  
  if (targetLines) {
    // Create a plane at target CD
    const targetPlane = {
      type: 'surface',
      x: doses,
      y: defocuses,
      z: Array(defocuses.length).fill(Array(doses.length).fill(targetLines.target_cd)),
      colorscale: [[0, 'rgba(220, 38, 38, 0.3)'], [1, 'rgba(220, 38, 38, 0.3)']],
      showscale: false,
      opacity: 0.3,
      hoverinfo: 'skip',
      name: 'Target CD'
    }
    traces.push(targetPlane)
  }

  const layout = {
    autosize: true,
    scene: {
      xaxis: {
        title: {
          text: 'Exposure Dose (mJ/cm²)',
          font: { size: 12, family: 'Arial, sans-serif', color: '#374151' }
        },
        gridcolor: '#d1d5db',
        showbackground: true,
        backgroundcolor: '#f9fafb'
      },
      yaxis: {
        title: {
          text: 'Defocus (μm)',
          font: { size: 12, family: 'Arial, sans-serif', color: '#374151' }
        },
        gridcolor: '#d1d5db',
        showbackground: true,
        backgroundcolor: '#f9fafb'
      },
      zaxis: {
        title: {
          text: 'Critical Dimension (nm)',
          font: { size: 12, family: 'Arial, sans-serif', color: '#374151' }
        },
        gridcolor: '#d1d5db',
        showbackground: true,
        backgroundcolor: '#f9fafb'
      },
      camera: {
        eye: viewAngle.eye,
        center: { x: 0, y: 0, z: 0 },
        up: { x: 0, y: 0, z: 1 }
      },
      aspectmode: 'cube'
    },
    margin: { l: 0, r: 0, t: 40, b: 0 },
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    font: {
      family: 'Arial, sans-serif',
      size: 11,
      color: '#374151'
    }
  }

  const config = {
    displayModeBar: true,
    displaylogo: false,
    modeBarButtonsToRemove: ['pan2d', 'lasso2d', 'select2d'],
    responsive: true
  }

  const resetView = () => {
    setViewAngle({ eye: { x: 1.5, y: 1.5, z: 1.3 } })
  }

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg">
      {/* Header */}
      <div className="mb-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              3D Process Window Visualization
            </h3>
            <p className="text-sm text-gray-600">
              Interactive 3D surface showing CD variation across dose-focus space. 
              Rotate, zoom, and explore the process window.
            </p>
          </div>
          <div className="flex items-center space-x-2 ml-4">
            <button
              onClick={resetView}
              className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              title="Reset View"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
            <button
              onClick={() => setShowInfo(!showInfo)}
              className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              title="Show Info"
            >
              <Info className="w-5 h-5" />
            </button>
          </div>
        </div>

        {showInfo && (
          <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded mb-4">
            <p className="text-sm text-gray-700 mb-2">
              <span className="font-semibold">How to Interact:</span>
            </p>
            <ul className="text-xs text-gray-700 space-y-1 ml-4">
              <li>• <strong>Rotate:</strong> Click and drag to rotate the 3D view</li>
              <li>• <strong>Zoom:</strong> Scroll or pinch to zoom in/out</li>
              <li>• <strong>Pan:</strong> Right-click and drag to pan</li>
              <li>• <strong>Hover:</strong> Hover over surface to see exact values</li>
              <li>• <strong>Reset:</strong> Click the reset button to restore default view</li>
            </ul>
          </div>
        )}

        <div className="bg-gradient-to-r from-green-50 to-blue-50 border-l-4 border-green-500 p-4 rounded">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Engineering Insight:</span> The 3D surface reveals the process window 
            landscape. Green regions indicate CD within specification - this is your safe operating zone. 
            The "valley" or "plateau" in the center represents the optimal process point with maximum tolerance 
            to dose and focus variations. Red regions show out-of-spec conditions to avoid.
          </p>
        </div>
      </div>

      {/* 3D Plot */}
      <div className="relative" style={{ height: '600px' }}>
        <Plot
          data={traces}
          layout={layout}
          config={config}
          style={{ width: '100%', height: '100%' }}
          useResizeHandler={true}
        />
      </div>

      {/* Legend and Interpretation */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 p-4 rounded-lg border border-green-200">
          <p className="text-xs font-semibold text-green-800 mb-1">✓ Green Region (In-Spec)</p>
          <p className="text-xs text-gray-700">
            CD within target ± tolerance. This is your process window - maximize this area for robust manufacturing.
          </p>
        </div>
        <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
          <p className="text-xs font-semibold text-yellow-800 mb-1">⚠ Yellow Region (Edge)</p>
          <p className="text-xs text-gray-700">
            CD approaching spec limits. Process is sensitive here - small variations can cause failures.
          </p>
        </div>
        <div className="bg-red-50 p-4 rounded-lg border border-red-200">
          <p className="text-xs font-semibold text-red-800 mb-1">✗ Red Region (Out-of-Spec)</p>
          <p className="text-xs text-gray-700">
            CD outside specifications. Avoid these dose-focus combinations - they will cause yield loss.
          </p>
        </div>
      </div>

      {/* Key Insights */}
      <div className="mt-6 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/30 dark:to-blue-900/30 rounded-lg p-6 border-l-4 border-purple-500">
        <h4 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">🎯 Key Insights from 3D View</h4>
        <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-700 dark:text-gray-200">
          <div>
            <p className="font-semibold mb-1 text-gray-900 dark:text-gray-100">Process Window Shape:</p>
            <ul className="text-xs space-y-1 ml-4 text-gray-700 dark:text-gray-300">
              <li>• Flat plateau = robust process with good margins</li>
              <li>• Steep slopes = sensitive to variations</li>
              <li>• Narrow valley = tight process control needed</li>
            </ul>
          </div>
          <div>
            <p className="font-semibold mb-1 text-gray-900 dark:text-gray-100">Optimal Point Selection:</p>
            <ul className="text-xs space-y-1 ml-4 text-gray-700 dark:text-gray-300">
              <li>• Choose center of green region for maximum margin</li>
              <li>• Avoid edges even if in-spec</li>
              <li>• Consider dose and focus control capabilities</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ProcessWindow3D
