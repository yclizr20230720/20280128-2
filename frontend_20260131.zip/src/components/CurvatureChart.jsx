import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts'
import { Info } from 'lucide-react'

const CurvatureChart = ({ data }) => {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-50 rounded-lg">
        <p className="text-gray-500">No data available</p>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg">
      {/* Header with explanation */}
      <div className="mb-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-xl font-bold text-gray-900">Bossung Curve Curvature vs Dose</h3>
          <div className="group relative">
            <Info className="w-5 h-5 text-blue-500 cursor-help" />
            <div className="invisible group-hover:visible absolute right-0 w-80 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
              <p className="font-semibold mb-2">Understanding Curvature:</p>
              <ul className="space-y-1 text-xs">
                <li>• Measures how "steep" the Bossung curve is</li>
                <li>• Higher curvature = CD changes rapidly with defocus</li>
                <li>• Lower curvature = more focus tolerance</li>
                <li>• Derived from parabolic fit coefficient (a)</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="bg-orange-50 border-l-4 border-orange-500 p-4 rounded">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Engineering Insight:</span> Curvature quantifies focus sensitivity. 
            Lower curvature values indicate a flatter Bossung curve, meaning your CD is less sensitive to focus 
            variations - this is desirable for a robust process. Higher curvature means you need tighter focus 
            control. Choose doses with lower curvature for better process stability.
          </p>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#d1d5db" opacity={0.5} />
          <XAxis 
            dataKey="dose" 
            label={{ value: 'Exposure Dose (mJ/cm²)', position: 'insideBottom', offset: -10, style: { fontSize: 14, fontWeight: 'bold' } }}
            stroke="#374151"
            tick={{ fontSize: 12 }}
          />
          <YAxis 
            label={{ value: 'Curvature (a coefficient)', angle: -90, position: 'insideLeft', style: { fontSize: 14, fontWeight: 'bold' } }}
            stroke="#374151"
            tick={{ fontSize: 12 }}
          />
          <Tooltip 
            contentStyle={{ backgroundColor: '#fff', border: '1px solid #d1d5db', borderRadius: '8px', padding: '12px' }}
            formatter={(value) => [`${value.toFixed(4)}`, 'Curvature']}
            labelFormatter={(label) => `Dose: ${label.toFixed(1)} mJ/cm²`}
          />
          <Legend wrapperStyle={{ paddingTop: '20px' }} />
          
          <Line
            type="monotone"
            dataKey="curvature"
            name="Curvature"
            stroke="#f59e0b"
            strokeWidth={3}
            dot={{ r: 6, fill: '#f59e0b' }}
            activeDot={{ r: 8 }}
          />
        </LineChart>
      </ResponsiveContainer>
      
      {/* Key Takeaways */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-green-800 mb-1">✓ Good Process</p>
          <p className="text-xs text-gray-700">Lower curvature = better focus tolerance</p>
        </div>
        <div className="bg-yellow-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-yellow-800 mb-1">⚠ Watch Out</p>
          <p className="text-xs text-gray-700">High curvature requires tight focus control</p>
        </div>
        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-blue-800 mb-1">💡 Tip</p>
          <p className="text-xs text-gray-700">Select dose with minimum curvature for robustness</p>
        </div>
      </div>
    </div>
  )
}

export default CurvatureChart
