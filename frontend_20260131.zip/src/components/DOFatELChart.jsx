import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';

export default function DOFatELChart({ dofAtElData }) {
  if (!dofAtElData || !dofAtElData.results || dofAtElData.results.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-500 dark:text-gray-400">
        No DOF at EL data available
      </div>
    );
  }

  const chartData = dofAtElData.results.map(item => ({
    el: `${item.el_percent}%`,
    dof: item.dof,
    min_dof: item.min_dof,
    max_dof: item.max_dof,
    el_value: item.el_percent
  }));

  // Color based on DOF value
  const getColor = (dof) => {
    if (dof >= 0.8) return '#10b981'; // Green - excellent
    if (dof >= 0.5) return '#3b82f6'; // Blue - good
    if (dof >= 0.3) return '#f59e0b'; // Orange - adequate
    return '#ef4444'; // Red - poor
  };

  return (
    <div className="space-y-4">
      <div className="bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800 rounded-lg p-4">
        <h4 className="font-semibold text-indigo-900 dark:text-indigo-100 mb-2 flex items-center">
          <span className="mr-2">📏</span>
          Understanding DOF at EL% (Industry Standard Metric)
        </h4>
        <div className="text-sm text-indigo-800 dark:text-indigo-200 space-y-2">
          <p>
            <strong>DOF at X% EL</strong> answers: "If my exposure has X% variation, how much focus range do I have?"
          </p>
          <ul className="space-y-1 ml-4">
            <li>• <strong>5% EL</strong>: Tight dose control (typical for critical layers)</li>
            <li>• <strong>10% EL</strong>: Standard production tolerance</li>
            <li>• <strong>15-20% EL</strong>: Relaxed requirements (non-critical layers)</li>
          </ul>
          <p className="text-xs mt-2 bg-indigo-100 dark:bg-indigo-900/40 p-2 rounded">
            <strong>Trade-off:</strong> Tighter dose control (lower EL%) gives you more focus budget (higher DOF).
            Choose based on your scanner's dose uniformity capability.
          </p>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={350}>
        <BarChart data={chartData} margin={{ top: 20, right: 30, bottom: 20, left: 20 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.3} />
          <XAxis 
            dataKey="el" 
            label={{ value: 'Exposure Latitude (%)', position: 'insideBottom', offset: -10 }}
            stroke="#6b7280"
          />
          <YAxis 
            label={{ value: 'Depth of Focus (μm)', angle: -90, position: 'insideLeft' }}
            stroke="#6b7280"
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: 'rgba(31, 41, 55, 0.95)', 
              border: '1px solid #4b5563',
              borderRadius: '8px',
              color: '#f3f4f6'
            }}
            formatter={(value, name) => {
              if (name === 'dof') return [`${value.toFixed(4)} μm`, 'Average DOF'];
              if (name === 'min_dof') return [`${value.toFixed(4)} μm`, 'Min DOF'];
              if (name === 'max_dof') return [`${value.toFixed(4)} μm`, 'Max DOF'];
              return value;
            }}
          />
          <Legend />
          
          <Bar dataKey="dof" name="Average DOF" radius={[8, 8, 0, 0]}>
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={getColor(entry.dof)} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>

      {/* Interpretation guide */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
          <h5 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">DOF Quality Guide</h5>
          <div className="space-y-2 text-sm">
            <div className="flex items-center">
              <div className="w-4 h-4 bg-green-500 rounded mr-2"></div>
              <span className="text-gray-700 dark:text-gray-300">≥ 0.8 μm: Excellent</span>
            </div>
            <div className="flex items-center">
              <div className="w-4 h-4 bg-blue-500 rounded mr-2"></div>
              <span className="text-gray-700 dark:text-gray-300">0.5-0.8 μm: Good</span>
            </div>
            <div className="flex items-center">
              <div className="w-4 h-4 bg-orange-500 rounded mr-2"></div>
              <span className="text-gray-700 dark:text-gray-300">0.3-0.5 μm: Adequate</span>
            </div>
            <div className="flex items-center">
              <div className="w-4 h-4 bg-red-500 rounded mr-2"></div>
              <span className="text-gray-700 dark:text-gray-300">&lt; 0.3 μm: Poor</span>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
          <h5 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Recommended Actions</h5>
          <div className="space-y-2 text-sm text-gray-700 dark:text-gray-300">
            {chartData[0]?.dof >= 0.8 ? (
              <p>✅ Excellent process window. Ready for production.</p>
            ) : chartData[0]?.dof >= 0.5 ? (
              <p>✓ Good process window. Monitor focus control closely.</p>
            ) : chartData[0]?.dof >= 0.3 ? (
              <p>⚠️ Marginal DOF. Consider process optimization or tighter focus control.</p>
            ) : (
              <p>❌ Insufficient DOF. Requires OPC/SMO optimization or reticle redesign.</p>
            )}
            <p className="text-xs mt-2 text-gray-600 dark:text-gray-400">
              Typical requirement: DOF at 10% EL should be &gt; 0.5 μm for production.
            </p>
          </div>
        </div>
      </div>

      {/* Detailed metrics table */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-800">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                EL %
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Average DOF (μm)
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Min DOF (μm)
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Max DOF (μm)
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Assessment
              </th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
            {dofAtElData.results.map((item, index) => (
              <tr key={index}>
                <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-gray-100">
                  {item.el_percent}%
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                  {item.dof.toFixed(4)}
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                  {item.min_dof.toFixed(4)}
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                  {item.max_dof.toFixed(4)}
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-sm">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    item.dof >= 0.8 
                      ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
                      : item.dof >= 0.5
                      ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300'
                      : item.dof >= 0.3
                      ? 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300'
                      : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                  }`}>
                    {item.dof >= 0.8 ? 'Excellent' : item.dof >= 0.5 ? 'Good' : item.dof >= 0.3 ? 'Adequate' : 'Poor'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
