import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, ReferenceDot } from 'recharts';

export default function FEMContourChart({ chartData, optimalPoint, advancedMetrics }) {
  if (!chartData || !chartData.contour) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-500 dark:text-gray-400">
        No contour data available
      </div>
    );
  }

  const { exposure_values, focus_values, cd_matrix } = chartData.contour;
  const { cd_min, cd_max, target_cd } = chartData.spec_limits;

  // Prepare scatter data with CD values
  const scatterData = [];
  for (let i = 0; i < focus_values.length; i++) {
    for (let j = 0; j < exposure_values.length; j++) {
      const cd = cd_matrix[i][j];
      const inSpec = cd >= cd_min && cd <= cd_max;
      scatterData.push({
        exposure: exposure_values[j],
        focus: focus_values[i],
        cd: cd,
        inSpec: inSpec
      });
    }
  }

  // Color function based on CD value
  const getColor = (cd) => {
    if (cd < cd_min) return '#ef4444'; // Red - below spec
    if (cd > cd_max) return '#f59e0b'; // Orange - above spec
    
    // Green gradient for in-spec
    const deviation = Math.abs(cd - target_cd) / (target_cd * 0.1);
    if (deviation < 0.3) return '#10b981'; // Dark green - close to target
    if (deviation < 0.7) return '#34d399'; // Medium green
    return '#6ee7b7'; // Light green
  };

  return (
    <div className="space-y-4">
      <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg p-4">
        <h4 className="font-semibold text-purple-900 dark:text-purple-100 mb-2 flex items-center">
          <span className="mr-2">🎯</span>
          Understanding FEM Contour Maps
        </h4>
        <ul className="text-sm text-purple-800 dark:text-purple-200 space-y-1">
          <li>• <strong className="text-green-600 dark:text-green-400">Green region</strong>: In-specification (process window)</li>
          <li>• <strong className="text-red-600 dark:text-red-400">Red points</strong>: Below spec (underexposed)</li>
          <li>• <strong className="text-orange-600 dark:text-orange-400">Orange points</strong>: Above spec (overexposed)</li>
          <li>• <strong className="text-blue-600 dark:text-blue-400">Blue star</strong>: Optimal process point</li>
          <li>• Larger green region = more robust process</li>
        </ul>
      </div>

      <ResponsiveContainer width="100%" height={500}>
        <ScatterChart margin={{ top: 20, right: 30, bottom: 20, left: 20 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.3} />
          <XAxis 
            type="number" 
            dataKey="exposure" 
            name="Exposure"
            label={{ value: 'Exposure Dose (mJ/cm²)', position: 'insideBottom', offset: -10 }}
            stroke="#6b7280"
            domain={['dataMin - 10', 'dataMax + 10']}
          />
          <YAxis 
            type="number" 
            dataKey="focus" 
            name="Focus"
            label={{ value: 'Focus (μm)', angle: -90, position: 'insideLeft' }}
            stroke="#6b7280"
            domain={['dataMin - 0.1', 'dataMax + 0.1']}
          />
          <Tooltip 
            cursor={{ strokeDasharray: '3 3' }}
            contentStyle={{ 
              backgroundColor: 'rgba(31, 41, 55, 0.95)', 
              border: '1px solid #4b5563',
              borderRadius: '8px',
              color: '#f3f4f6'
            }}
            formatter={(value, name) => {
              if (name === 'cd') return [`${value.toFixed(2)} nm`, 'CD'];
              if (name === 'exposure') return [`${value.toFixed(1)} mJ/cm²`, 'Exposure'];
              if (name === 'focus') return [`${value.toFixed(3)} μm`, 'Focus'];
              return value;
            }}
          />
          
          <Scatter name="FEM Data" data={scatterData} shape="circle">
            {scatterData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={getColor(entry.cd)} opacity={0.7} />
            ))}
          </Scatter>

          {/* Optimal point marker */}
          {optimalPoint && optimalPoint.found && (
            <ReferenceDot
              x={optimalPoint.exposure}
              y={optimalPoint.focus}
              r={8}
              fill="#3b82f6"
              stroke="#1e40af"
              strokeWidth={3}
              label={{ 
                value: '★', 
                position: 'center',
                fill: '#ffffff',
                fontSize: 16,
                fontWeight: 'bold'
              }}
            />
          )}
        </ScatterChart>
      </ResponsiveContainer>

      {/* Process window info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3">
          <p className="text-xs text-green-700 dark:text-green-300 font-medium mb-1">In-Spec Region</p>
          <p className="text-lg font-bold text-green-900 dark:text-green-100">
            {chartData.in_spec_points?.length || 0} points
          </p>
          <p className="text-xs text-green-600 dark:text-green-400">
            {((chartData.in_spec_points?.length || 0) / scatterData.length * 100).toFixed(1)}% of total
          </p>
        </div>

        {advancedMetrics?.inscribed_rectangle && (
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
            <p className="text-xs text-blue-700 dark:text-blue-300 font-medium mb-1">Max Rectangle</p>
            <p className="text-lg font-bold text-blue-900 dark:text-blue-100">
              {advancedMetrics.inscribed_rectangle.area.toFixed(1)}
            </p>
            <p className="text-xs text-blue-600 dark:text-blue-400">
              {advancedMetrics.inscribed_rectangle.width.toFixed(1)} × {advancedMetrics.inscribed_rectangle.height.toFixed(3)}
            </p>
          </div>
        )}

        {advancedMetrics?.process_robustness_score && (
          <div className={`border rounded-lg p-3 ${
            advancedMetrics.process_robustness_score.score >= 80 
              ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'
              : advancedMetrics.process_robustness_score.score >= 60
              ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800'
              : 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
          }`}>
            <p className="text-xs font-medium mb-1">Robustness Score</p>
            <p className="text-lg font-bold">
              {advancedMetrics.process_robustness_score.score.toFixed(0)}/100
            </p>
            <p className="text-xs">
              {advancedMetrics.process_robustness_score.rating}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
