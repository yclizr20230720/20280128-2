import { Link } from 'react-router-dom'
import { ArrowRight, Users, FileText } from 'lucide-react'

const ToolCard = ({ icon: Icon, title, description, features, link, status = 'active', caseCount = 0, userCount = 0 }) => {
  const isActive = status === 'active'
  
  return (
    <div className={`bg-white rounded-xl shadow-md overflow-hidden card-hover ${!isActive && 'opacity-60'}`}>
      <div className="p-6">
        {/* Icon and Status */}
        <div className="flex items-start justify-between mb-4">
          <div className="p-3 bg-gradient-to-br from-primary-50 to-secondary-50 rounded-lg">
            <Icon className="w-8 h-8 text-primary-600" />
          </div>
          {isActive ? (
            <span className="px-2 py-1 text-xs font-medium text-green-700 bg-green-100 rounded-full">
              Active
            </span>
          ) : (
            <span className="px-2 py-1 text-xs font-medium text-gray-600 bg-gray-100 rounded-full">
              Coming Soon
            </span>
          )}
        </div>
        
        {/* Title and Description */}
        <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{description}</p>
        
        {/* Statistics (only for active tools) */}
        {isActive && (caseCount > 0 || userCount > 0) && (
          <div className="flex items-center space-x-4 mb-4 pb-4 border-b border-gray-100">
            <div className="flex items-center text-sm text-gray-600">
              <FileText className="w-4 h-4 mr-1 text-primary-600" />
              <span className="font-semibold text-gray-900">{caseCount}</span>
              <span className="ml-1">cases</span>
            </div>
            <div className="flex items-center text-sm text-gray-600">
              <Users className="w-4 h-4 mr-1 text-secondary-600" />
              <span className="font-semibold text-gray-900">{userCount}</span>
              <span className="ml-1">users</span>
            </div>
          </div>
        )}
        
        {/* Features */}
        <ul className="space-y-2 mb-6">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center text-sm text-gray-700">
              <svg className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
              {feature}
            </li>
          ))}
        </ul>
        
        {/* Action Button */}
        {isActive ? (
          <Link
            to={link}
            className="inline-flex items-center justify-center w-full px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-primary-600 to-secondary-600 rounded-lg hover:from-primary-700 hover:to-secondary-700 transition-all duration-200 group"
          >
            Launch Tool
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Link>
        ) : (
          <button
            disabled
            className="inline-flex items-center justify-center w-full px-4 py-2 text-sm font-medium text-gray-500 bg-gray-100 rounded-lg cursor-not-allowed"
          >
            Coming Soon
          </button>
        )}
      </div>
    </div>
  )
}

export default ToolCard
