import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';

export default function FEMBossungChart({ bossungData, targetCD, specLimits }) {
  if (!bossungData || !bossungData.curves || bossungData.curves.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-500 dark:text-gray-400">
        No Bossung data available
      </div>
    );
  }

  // Prepare data for Recharts (combine all curves into one dataset)
  const allFocusPoints = bossungData.curves[0].data.map(d => d.focus);
  const chartData = allFocusPoints.map(focus => {
    const dataPoint = { focus };
    bossungData.curves.forEach(curve => {
      const point = curve.data.find(d => d.focus === focus);
      if (point) {
        dataPoint[`E${curve.exposure.toFixed(0)}`] = point.cd;
      }
    });
    return dataPoint;
  });

  // Generate colors for different exposure doses
  const colors = [
    '#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#a4de6c',
    '#d084d0', '#8dd1e1', '#ffb347', '#ff6b9d', '#c9c9ff'
  ];

  const cdMin = specLimits?.cd_min || targetCD * 0.9;
  const cdMax = specLimits?.cd_max || targetCD * 1.1;

  return (
    <div className="space-y-4">
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
        <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2 flex items-center">
          <span className="mr-2">📊</span>
          Understanding Bossung Curves
        </h4>
        <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
          <li>• Each line represents CD vs Focus at a specific exposure dose</li>
          <li>• <strong>Iso-focal Point</strong>: Where curves intersect (least dose-sensitive focus)</li>
          <li>• <strong>Smile Shape</strong> (↗↘): Isolated space/contact behavior</li>
          <li>• <strong>Frown Shape</strong> (↘↗): Isolated line behavior</li>
          <li>• Flatter curves = better focus tolerance</li>
        </ul>
      </div>

      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.3} />
          <XAxis 
            dataKey="focus" 
            label={{ value: 'Focus (μm)', position: 'insideBottom', offset: -5 }}
            stroke="#6b7280"
          />
          <YAxis 
            label={{ value: 'CD (nm)', angle: -90, position: 'insideLeft' }}
            stroke="#6b7280"
            domain={[cdMin * 0.95, cdMax * 1.05]}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: 'rgba(31, 41, 55, 0.95)', 
              border: '1px solid #4b5563',
              borderRadius: '8px',
              color: '#f3f4f6'
            }}
            formatter={(value) => `${value.toFixed(2)} nm`}
          />
          <Legend 
            wrapperStyle={{ paddingTop: '20px' }}
            formatter={(value) => `${value} mJ/cm²`}
          />
          
          {/* Spec limit lines */}
          <ReferenceLine 
            y={targetCD} 
            stroke="#10b981" 
            strokeDasharray="5 5" 
            label={{ value: 'Target', position: 'right', fill: '#10b981' }}
          />
          <ReferenceLine 
            y={cdMin} 
            stroke="#ef4444" 
            strokeDasharray="3 3" 
            label={{ value: 'LSL', position: 'right', fill: '#ef4444' }}
          />
          <ReferenceLine 
            y={cdMax} 
            stroke="#ef4444" 
            strokeDasharray="3 3" 
            label={{ value: 'USL', position: 'right', fill: '#ef4444' }}
          />

          {/* Iso-focal point indicator */}
          {bossungData.iso_focal_point && (
            <ReferenceLine 
              x={bossungData.iso_focal_point.focus} 
              stroke="#f59e0b" 
              strokeWidth={2}
              label={{ 
                value: 'Iso-focal', 
                position: 'top', 
                fill: '#f59e0b',
                fontWeight: 'bold'
              }}
            />
          )}

          {/* Plot curves for each exposure */}
          {bossungData.curves.map((curve, index) => (
            <Line
              key={`E${curve.exposure}`}
              type="monotone"
              dataKey={`E${curve.exposure.toFixed(0)}`}
              stroke={colors[index % colors.length]}
              strokeWidth={2}
              dot={{ r: 3 }}
              activeDot={{ r: 5 }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>

      {bossungData.iso_focal_point && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-3">
          <p className="text-sm text-amber-900 dark:text-amber-100">
            <strong>Iso-focal Point Detected:</strong> Focus = {bossungData.iso_focal_point.focus.toFixed(3)} μm, 
            CD = {bossungData.iso_focal_point.cd.toFixed(2)} nm
            <br />
            <span className="text-xs">This focus position shows minimum CD variation across different exposure doses.</span>
          </p>
        </div>
      )}
    </div>
  );
}
