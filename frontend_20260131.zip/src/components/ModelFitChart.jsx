import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine, ReferenceArea } from 'recharts'
import { Info } from 'lucide-react'

const ModelFitChart = ({ data }) => {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-50 rounded-lg">
        <p className="text-gray-500">No data available</p>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg">
      {/* Header with explanation */}
      <div className="mb-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-xl font-bold text-gray-900">Model Fit Quality (R²) vs Dose</h3>
          <div className="group relative">
            <Info className="w-5 h-5 text-blue-500 cursor-help" />
            <div className="invisible group-hover:visible absolute right-0 w-80 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
              <p className="font-semibold mb-2">Understanding R² (R-squared):</p>
              <ul className="space-y-1 text-xs">
                <li>• Measures how well parabolic model fits data</li>
                <li>• R² = 1.0 means perfect fit</li>
                <li>• R² &gt; 0.95 indicates excellent fit</li>
                <li>• Low R² suggests non-parabolic behavior or noise</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Engineering Insight:</span> R² tells you how reliable the Bossung curve 
            analysis is. High R² values (above 0.95) mean the parabolic model accurately describes your data, and you 
            can trust the extracted metrics like best focus and curvature. Low R² may indicate measurement noise, 
            non-ideal resist behavior, or the need for a more complex model.
          </p>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#d1d5db" opacity={0.5} />
          <XAxis 
            dataKey="dose" 
            label={{ value: 'Exposure Dose (mJ/cm²)', position: 'insideBottom', offset: -10, style: { fontSize: 14, fontWeight: 'bold' } }}
            stroke="#374151"
            tick={{ fontSize: 12 }}
          />
          <YAxis 
            domain={[0.9, 1.0]}
            label={{ value: 'R² (Goodness of Fit)', angle: -90, position: 'insideLeft', style: { fontSize: 14, fontWeight: 'bold' } }}
            stroke="#374151"
            tick={{ fontSize: 12 }}
          />
          <Tooltip 
            contentStyle={{ backgroundColor: '#fff', border: '1px solid #d1d5db', borderRadius: '8px', padding: '12px' }}
            formatter={(value) => [`${value.toFixed(4)}`, 'R²']}
            labelFormatter={(label) => `Dose: ${label.toFixed(1)} mJ/cm²`}
          />
          <Legend wrapperStyle={{ paddingTop: '20px' }} />
          
          <ReferenceArea
            y1={0.95}
            y2={1.0}
            fill="#22c55e"
            fillOpacity={0.1}
            label={{ value: 'Excellent Fit', fill: '#16a34a', fontSize: 11, position: 'insideTopRight' }}
          />
          
          <ReferenceLine 
            y={0.95} 
            stroke="#16a34a" 
            strokeDasharray="5 5"
            strokeWidth={1.5}
            label={{ value: 'Good Fit Threshold', fill: '#16a34a', fontSize: 11, position: 'right' }}
          />
          
          <Line
            type="monotone"
            dataKey="r_squared"
            name="R² Value"
            stroke="#6366f1"
            strokeWidth={3}
            dot={{ r: 6, fill: '#6366f1' }}
            activeDot={{ r: 8 }}
          />
        </LineChart>
      </ResponsiveContainer>
      
      {/* Key Takeaways */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-green-800 mb-1">✓ Good Process</p>
          <p className="text-xs text-gray-700">R² &gt; 0.95 indicates reliable parabolic fit</p>
        </div>
        <div className="bg-yellow-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-yellow-800 mb-1">⚠ Watch Out</p>
          <p className="text-xs text-gray-700">R² &lt; 0.90 suggests data quality issues</p>
        </div>
        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-xs font-semibold text-blue-800 mb-1">💡 Tip</p>
          <p className="text-xs text-gray-700">Trust metrics only when R² is high</p>
        </div>
      </div>
    </div>
  )
}

export default ModelFitChart
