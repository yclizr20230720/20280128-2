import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine, ReferenceArea } from 'recharts'
import { Info } from 'lucide-react'

const BossungChart = ({ data, targetLines, doses }) => {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-50 rounded-lg">
        <p className="text-gray-500">No data available</p>
      </div>
    )
  }

  // Viridis-like color palette (matching matplotlib)
  const colors = [
    '#440154', '#482878', '#3e4989', '#31688e', 
    '#26828e', '#1f9e89', '#35b779', '#6ece58', 
    '#b5de2b', '#fde724'
  ]

  // Group data by defocus for proper line rendering
  const groupedData = {}
  data.forEach(point => {
    const key = point.defocus.toFixed(4)
    if (!groupedData[key]) {
      groupedData[key] = { defocus: point.defocus }
    }
    groupedData[key][`dose_${point.dose}`] = point.cd
  })
  
  const chartData = Object.values(groupedData).sort((a, b) => a.defocus - b.defocus)

  return (
    <div className="bg-white rounded-lg p-6 shadow-lg border border-gray-200">
      {/* Header with explanation */}
      <div className="mb-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-xl font-bold text-gray-900">Bossung Curves - Focus-Exposure Matrix (FEM)</h3>
          <div className="group relative">
            <Info className="w-5 h-5 text-blue-500 cursor-help" />
            <div className="invisible group-hover:visible absolute right-0 w-96 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
              <p className="font-semibold mb-2">Understanding Bossung Curves:</p>
              <ul className="space-y-1 text-xs">
                <li>• Each colored line represents a different exposure dose</li>
                <li>• X-axis: Defocus position (negative = below focus, positive = above focus)</li>
                <li>• Y-axis: Critical Dimension (CD) measured in nanometers</li>
                <li>• Parabolic shape is characteristic of lithography process</li>
                <li>• Best focus is typically where curves reach minimum CD</li>
                <li>• Green zone shows acceptable CD tolerance range</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
          <p className="text-sm text-gray-700">
            <span className="font-semibold">Engineering Insight:</span> Bossung curves show how CD varies with focus at different exposure doses. 
            The parabolic shape helps identify the optimal focus position and exposure latitude. Look for curves that stay within the green tolerance 
            band across the widest defocus range - this indicates a robust process with good depth of focus (DOF).
          </p>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={600}>
        <LineChart data={chartData} margin={{ top: 20, right: 120, left: 20, bottom: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#d1d5db" opacity={0.5} />
          <XAxis 
            dataKey="defocus" 
            label={{ value: 'Defocus (μm)', position: 'insideBottom', offset: -10, style: { fontSize: 14, fontWeight: 'bold' } }}
            stroke="#374151"
            tick={{ fontSize: 12 }}
            domain={['dataMin', 'dataMax']}
          />
          <YAxis 
            label={{ value: 'Critical Dimension (nm)', angle: -90, position: 'insideLeft', style: { fontSize: 14, fontWeight: 'bold' } }}
            stroke="#374151"
            tick={{ fontSize: 12 }}
            domain={['auto', 'auto']}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#fff', 
              border: '1px solid #d1d5db', 
              borderRadius: '8px',
              padding: '12px'
            }}
            formatter={(value, name) => {
              if (value === undefined) return null
              const doseName = name.replace('dose_', '')
              return [`${value.toFixed(2)} nm`, `${doseName} mJ/cm²`]
            }}
            labelFormatter={(label) => `Defocus: ${Number(label).toFixed(3)} μm`}
          />
          <Legend 
            wrapperStyle={{ paddingTop: '20px', fontSize: '11px' }}
            iconType="line"
            formatter={(value) => value.replace('dose_', '') + ' mJ/cm²'}
          />
          
          {/* Target CD line */}
          {targetLines && (
            <>
              <ReferenceLine 
                y={targetLines.target_cd} 
                stroke="#dc2626" 
                strokeDasharray="5 5"
                strokeWidth={2.5}
                label={{ 
                  value: `Target CD: ${targetLines.target_cd.toFixed(1)} nm`, 
                  fill: '#dc2626', 
                  fontSize: 12,
                  fontWeight: 'bold',
                  position: 'right'
                }}
              />
              <ReferenceArea
                y1={targetLines.lower_limit}
                y2={targetLines.upper_limit}
                fill="#10b981"
                fillOpacity={0.15}
                label={{ 
                  value: `Tolerance: ±${((targetLines.upper_limit - targetLines.target_cd)).toFixed(1)} nm`, 
                  fill: '#059669', 
                  fontSize: 11,
                  position: 'insideTopRight'
                }}
              />
            </>
          )}
          
          {/* Lines for each dose */}
          {doses && doses.map((dose, index) => (
            <Line
              key={`dose_${dose.dose}`}
              type="monotone"
              dataKey={`dose_${dose.dose}`}
              stroke={colors[index % colors.length]}
              strokeWidth={2.5}
              dot={{ r: 5, strokeWidth: 1, fill: colors[index % colors.length] }}
              activeDot={{ r: 7, strokeWidth: 2 }}
              name={`dose_${dose.dose}`}
              connectNulls
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
      
      {/* Key Takeaways */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 p-4 rounded-lg border border-green-200">
          <p className="text-xs font-semibold text-green-800 mb-1">✓ Optimal Process</p>
          <p className="text-xs text-gray-700">Curves that remain in the green zone across wide defocus range indicate robust process</p>
        </div>
        <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
          <p className="text-xs font-semibold text-yellow-800 mb-1">⚠ Watch Out</p>
          <p className="text-xs text-gray-700">Steep parabolas indicate high focus sensitivity - tighter focus control needed</p>
        </div>
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <p className="text-xs font-semibold text-blue-800 mb-1">💡 Best Focus</p>
          <p className="text-xs text-gray-700">Look for the defocus position where curves converge near target CD</p>
        </div>
      </div>
    </div>
  )
}

export default BossungChart
