#!/usr/bin/env python3.11
"""
Advanced FEM Contour Visualization
Professional visualization of focus-exposure matrices
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.gridspec import GridSpec
import seaborn as sns
from typing import Dict, Tuple, Optional, List
from fem_processor import FEMMatrix, FEMProcessor


class FEMVisualizer:
    """
    Advanced visualizer for Focus-Exposure Matrix data.
    
    Creates professional publication-quality visualizations including
    contour maps, heatmaps, and multi-pattern comparisons.
    """
    
    def __init__(self, style: str = 'seaborn-v0_8-darkgrid', dpi: int = 300):
        """
        Initialize visualizer.
        
        Args:
            style: Matplotlib style
            dpi: Resolution for output
        """
        try:
            plt.style.use(style)
        except:
            plt.style.use('default')
        
        self.dpi = dpi
        self.current_fig = None
        self.current_ax = None
    
    def plot_fem_contour(self,
                        fem_matrix: FEMMatrix,
                        target_cd: Optional[float] = None,
                        cd_tolerance: Optional[float] = None,
                        figsize: Tuple[float, float] = (12, 8),
                        levels: int = 20,
                        colormap: str = 'viridis',
                        show_spec_limits: bool = True,
                        show_optimal_point: bool = True) -> Tuple[plt.Figure, plt.Axes]:
        """
        Plot FEM as contour map with specification limits.
        
        Args:
            fem_matrix: FEMMatrix object
            target_cd: Target CD in nm
            cd_tolerance: CD tolerance as fraction
            figsize: Figure size
            levels: Number of contour levels
            colormap: Colormap name
            show_spec_limits: Whether to show spec limit contours
            show_optimal_point: Whether to mark optimal point
            
        Returns:
            Tuple of (figure, axes)
        """
        fig, ax = plt.subplots(figsize=figsize, dpi=self.dpi)
        
        # Create contour plot
        contour = ax.contourf(
            fem_matrix.exp_grid,
            fem_matrix.foc_grid,
            fem_matrix.cd_matrix,
            levels=levels,
            cmap=colormap,
            alpha=0.8
        )
        
        # Add contour lines
        contour_lines = ax.contour(
            fem_matrix.exp_grid,
            fem_matrix.foc_grid,
            fem_matrix.cd_matrix,
            levels=levels,
            colors='black',
            linewidths=0.5,
            alpha=0.3
        )
        
        # Add specification limits if provided
        if show_spec_limits and target_cd is not None and cd_tolerance is not None:
            cd_min = target_cd * (1 - cd_tolerance)
            cd_max = target_cd * (1 + cd_tolerance)
            
            # Lower spec limit
            ax.contour(
                fem_matrix.exp_grid,
                fem_matrix.foc_grid,
                fem_matrix.cd_matrix,
                levels=[cd_min],
                colors='blue',
                linewidths=2.5,
                linestyles='--',
                alpha=0.8
            )
            
            # Upper spec limit
            ax.contour(
                fem_matrix.exp_grid,
                fem_matrix.foc_grid,
                fem_matrix.cd_matrix,
                levels=[cd_max],
                colors='red',
                linewidths=2.5,
                linestyles='--',
                alpha=0.8
            )
            
            # Target CD
            ax.contour(
                fem_matrix.exp_grid,
                fem_matrix.foc_grid,
                fem_matrix.cd_matrix,
                levels=[target_cd],
                colors='green',
                linewidths=2.0,
                linestyles='-',
                alpha=0.9
            )
        
        # Add colorbar
        cbar = plt.colorbar(contour, ax=ax, label='Critical Dimension (nm)')
        
        # Labels and title
        ax.set_xlabel('Exposure Dose (mJ/cm²)', fontsize=12, fontweight='bold')
        ax.set_ylabel('Focus Position (μm)', fontsize=12, fontweight='bold')
        
        if fem_matrix.pattern_info:
            title = f'FEM Contour Map - {fem_matrix.pattern_info.name}'
        else:
            title = 'FEM Contour Map'
        ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
        
        # Add legend
        blue_line = mpatches.Patch(color='blue', label=f'Lower Spec (CD_min)')
        red_line = mpatches.Patch(color='red', label=f'Upper Spec (CD_max)')
        green_line = mpatches.Patch(color='green', label=f'Target CD')
        ax.legend(handles=[blue_line, red_line, green_line], loc='upper right')
        
        # Grid
        ax.grid(True, alpha=0.3)
        
        self.current_fig = fig
        self.current_ax = ax
        
        return fig, ax
    
    def plot_fem_heatmap(self,
                        fem_matrix: FEMMatrix,
                        figsize: Tuple[float, float] = (12, 8),
                        cmap: str = 'RdYlBu_r',
                        annot: bool = False,
                        fmt: str = '.1f') -> Tuple[plt.Figure, plt.Axes]:
        """
        Plot FEM as heatmap with annotations.
        
        Args:
            fem_matrix: FEMMatrix object
            figsize: Figure size
            cmap: Colormap name
            annot: Whether to annotate cells
            fmt: Annotation format
            
        Returns:
            Tuple of (figure, axes)
        """
        fig, ax = plt.subplots(figsize=figsize, dpi=self.dpi)
        
        # Create heatmap
        sns.heatmap(
            fem_matrix.cd_matrix,
            xticklabels=np.round(fem_matrix.exposure_values, 1),
            yticklabels=np.round(fem_matrix.focus_values, 2),
            cmap=cmap,
            annot=annot,
            fmt=fmt,
            cbar_kws={'label': 'Critical Dimension (nm)'},
            ax=ax,
            linewidths=0.5,
            linecolor='gray'
        )
        
        # Labels
        ax.set_xlabel('Exposure Dose (mJ/cm²)', fontsize=12, fontweight='bold')
        ax.set_ylabel('Focus Position (μm)', fontsize=12, fontweight='bold')
        
        if fem_matrix.pattern_info:
            title = f'FEM Heatmap - {fem_matrix.pattern_info.name}'
        else:
            title = 'FEM Heatmap'
        ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
        
        self.current_fig = fig
        self.current_ax = ax
        
        return fig, ax
    
    def plot_process_window_overlay(self,
                                   fem_matrix: FEMMatrix,
                                   target_cd: float,
                                   cd_tolerance: float,
                                   figsize: Tuple[float, float] = (12, 8),
                                   levels: int = 20) -> Tuple[plt.Figure, plt.Axes]:
        """
        Plot FEM with process window highlighted.
        
        Args:
            fem_matrix: FEMMatrix object
            target_cd: Target CD
            cd_tolerance: CD tolerance
            figsize: Figure size
            levels: Number of contour levels
            
        Returns:
            Tuple of (figure, axes)
        """
        fig, ax = plt.subplots(figsize=figsize, dpi=self.dpi)
        
        # Create contour plot
        contour = ax.contourf(
            fem_matrix.exp_grid,
            fem_matrix.foc_grid,
            fem_matrix.cd_matrix,
            levels=levels,
            cmap='viridis',
            alpha=0.7
        )
        
        # Calculate spec limits
        cd_min = target_cd * (1 - cd_tolerance)
        cd_max = target_cd * (1 + cd_tolerance)
        
        # Create in-spec mask
        in_spec = (fem_matrix.cd_matrix >= cd_min) & (fem_matrix.cd_matrix <= cd_max)
        
        # Overlay in-spec region
        ax.contourf(
            fem_matrix.exp_grid,
            fem_matrix.foc_grid,
            in_spec.astype(float),
            levels=[0.5, 1.5],
            colors=['green'],
            alpha=0.2,
            hatches=['//']
        )
        
        # Contour lines for spec limits
        ax.contour(
            fem_matrix.exp_grid,
            fem_matrix.foc_grid,
            fem_matrix.cd_matrix,
            levels=[cd_min, target_cd, cd_max],
            colors=['blue', 'green', 'red'],
            linewidths=[2, 2, 2],
            linestyles=['--', '-', '--']
        )
        
        # Colorbar
        cbar = plt.colorbar(contour, ax=ax, label='Critical Dimension (nm)')
        
        # Labels
        ax.set_xlabel('Exposure Dose (mJ/cm²)', fontsize=12, fontweight='bold')
        ax.set_ylabel('Focus Position (μm)', fontsize=12, fontweight='bold')
        
        if fem_matrix.pattern_info:
            title = f'Process Window - {fem_matrix.pattern_info.name}'
        else:
            title = 'Process Window'
        ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
        
        # Legend
        in_spec_patch = mpatches.Patch(color='green', alpha=0.2, label='In-Spec Region')
        ax.legend(handles=[in_spec_patch], loc='upper right')
        
        ax.grid(True, alpha=0.3)
        
        self.current_fig = fig
        self.current_ax = ax
        
        return fig, ax
    
    def plot_gradient_field(self,
                           fem_matrix: FEMMatrix,
                           figsize: Tuple[float, float] = (12, 8),
                           skip: int = 2) -> Tuple[plt.Figure, plt.Axes]:
        """
        Plot CD gradient field (sensitivity to E and F).
        
        Args:
            fem_matrix: FEMMatrix object
            figsize: Figure size
            skip: Skip factor for arrows
            
        Returns:
            Tuple of (figure, axes)
        """
        fig, ax = plt.subplots(figsize=figsize, dpi=self.dpi)
        
        # Calculate gradients
        grad_e, grad_f = fem_matrix.get_gradient()
        
        # Create background contour
        contour = ax.contourf(
            fem_matrix.exp_grid,
            fem_matrix.foc_grid,
            fem_matrix.cd_matrix,
            levels=15,
            cmap='gray',
            alpha=0.5
        )
        
        # Plot gradient field
        ax.quiver(
            fem_matrix.exp_grid[::skip, ::skip],
            fem_matrix.foc_grid[::skip, ::skip],
            grad_e[::skip, ::skip],
            grad_f[::skip, ::skip],
            np.sqrt(grad_e[::skip, ::skip]**2 + grad_f[::skip, ::skip]**2),
            cmap='hot',
            scale=50,
            width=0.003
        )
        
        # Labels
        ax.set_xlabel('Exposure Dose (mJ/cm²)', fontsize=12, fontweight='bold')
        ax.set_ylabel('Focus Position (μm)', fontsize=12, fontweight='bold')
        ax.set_title('CD Gradient Field (Sensitivity)', fontsize=14, fontweight='bold', pad=20)
        
        ax.grid(True, alpha=0.3)
        
        self.current_fig = fig
        self.current_ax = ax
        
        return fig, ax
    
    def plot_multi_pattern_comparison(self,
                                     processor,
                                     target_cd: float,
                                     cd_tolerance: float,
                                     figsize: Tuple[float, float] = (16, 12)) -> Tuple[plt.Figure, np.ndarray]:
        """
        Plot multiple patterns for comparison.
        
        Args:
            processor: FEMProcessor instance
            target_cd: Target CD
            cd_tolerance: CD tolerance
            figsize: Figure size
            
        Returns:
            Tuple of (figure, axes array)
        """
        patterns = processor.list_patterns()
        n_patterns = len(patterns)
        
        # Create grid
        n_cols = min(3, n_patterns)
        n_rows = (n_patterns + n_cols - 1) // n_cols
        
        fig, axes = plt.subplots(n_rows, n_cols, figsize=figsize, dpi=self.dpi)
        
        if n_patterns == 1:
            axes = np.array([[axes]])
        elif n_rows == 1:
            axes = axes.reshape(1, -1)
        elif n_cols == 1:
            axes = axes.reshape(-1, 1)
        
        for idx, pattern_name in enumerate(patterns):
            row = idx // n_cols
            col = idx % n_cols
            ax = axes[row, col]
            
            fem_matrix = processor.get_matrix(pattern_name)
            
            # Create contour
            contour = ax.contourf(
                fem_matrix.exp_grid,
                fem_matrix.foc_grid,
                fem_matrix.cd_matrix,
                levels=15,
                cmap='viridis',
                alpha=0.8
            )
            
            # Spec limits
            cd_min = target_cd * (1 - cd_tolerance)
            cd_max = target_cd * (1 + cd_tolerance)
            
            ax.contour(
                fem_matrix.exp_grid,
                fem_matrix.foc_grid,
                fem_matrix.cd_matrix,
                levels=[cd_min, target_cd, cd_max],
                colors=['blue', 'green', 'red'],
                linewidths=[2, 2, 2],
                linestyles=['--', '-', '--']
            )
            
            # Labels
            ax.set_xlabel('Exposure (mJ/cm²)', fontsize=10)
            ax.set_ylabel('Focus (μm)', fontsize=10)
            ax.set_title(pattern_name, fontsize=11, fontweight='bold')
            ax.grid(True, alpha=0.3)
            
            # Colorbar
            plt.colorbar(contour, ax=ax, label='CD (nm)')
        
        # Hide unused subplots
        for idx in range(n_patterns, n_rows * n_cols):
            row = idx // n_cols
            col = idx % n_cols
            axes[row, col].axis('off')
        
        fig.suptitle('Multi-Pattern FEM Comparison', fontsize=16, fontweight='bold', y=0.995)
        plt.tight_layout()
        
        self.current_fig = fig
        self.current_ax = axes
        
        return fig, axes
    
    def plot_dof_el_analysis(self,
                            processor,
                            pattern_name: str = 'default',
                            target_cd: Optional[float] = None,
                            cd_tolerance: Optional[float] = None,
                            figsize: Tuple[float, float] = (14, 5)) -> Tuple[plt.Figure, np.ndarray]:
        """
        Plot DOF and EL analysis.
        
        Args:
            processor: FEMProcessor instance
            pattern_name: Pattern name
            target_cd: Target CD
            cd_tolerance: CD tolerance
            figsize: Figure size
            
        Returns:
            Tuple of (figure, axes array)
        """
        dof_el = processor.calculate_dof_el(pattern_name, target_cd, cd_tolerance)
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize, dpi=self.dpi)
        
        # DOF plot
        if dof_el['dof_values']:
            exposures = [d['exposure'] for d in dof_el['dof_values']]
            dofs = [d['dof'] for d in dof_el['dof_values']]
            
            ax1.plot(exposures, dofs, 'o-', linewidth=2, markersize=8, color='blue')
            ax1.axhline(y=dof_el['avg_dof'], color='red', linestyle='--', 
                       label=f"Avg DOF: {dof_el['avg_dof']:.4f} μm")
            ax1.set_xlabel('Exposure Dose (mJ/cm²)', fontsize=11, fontweight='bold')
            ax1.set_ylabel('Depth of Focus (μm)', fontsize=11, fontweight='bold')
            ax1.set_title('DOF vs Exposure', fontsize=12, fontweight='bold')
            ax1.grid(True, alpha=0.3)
            ax1.legend()
        
        # EL plot
        if dof_el['el_values']:
            focuses = [e['focus'] for e in dof_el['el_values']]
            els = [e['el'] for e in dof_el['el_values']]
            
            ax2.plot(focuses, els, 's-', linewidth=2, markersize=8, color='green')
            ax2.axhline(y=dof_el['avg_el'], color='red', linestyle='--',
                       label=f"Avg EL: {dof_el['avg_el']:.2f} mJ/cm²")
            ax2.set_xlabel('Focus Position (μm)', fontsize=11, fontweight='bold')
            ax2.set_ylabel('Exposure Latitude (mJ/cm²)', fontsize=11, fontweight='bold')
            ax2.set_title('EL vs Focus', fontsize=12, fontweight='bold')
            ax2.grid(True, alpha=0.3)
            ax2.legend()
        
        fig.suptitle(f'DOF/EL Analysis - {pattern_name}', fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        self.current_fig = fig
        self.current_ax = np.array([ax1, ax2])
        
        return fig, np.array([ax1, ax2])
    
    def save_figure(self, filename: str, dpi: Optional[int] = None) -> None:
        """
        Save current figure to file.
        
        Args:
            filename: Output filename
            dpi: DPI for output (if None, use default)
        """
        if self.current_fig is None:
            raise ValueError("No figure to save. Create a plot first.")
        
        self.current_fig.savefig(filename, dpi=dpi or self.dpi, bbox_inches='tight')
        print(f"✓ Figure saved to {filename}")
    
    def show(self) -> None:
        """Display current figure."""
        if self.current_fig is None:
            raise ValueError("No figure to show.")
        plt.show()
    
    def close(self) -> None:
        """Close current figure."""
        if self.current_fig is not None:
            plt.close(self.current_fig)
            self.current_fig = None
            self.current_ax = None
