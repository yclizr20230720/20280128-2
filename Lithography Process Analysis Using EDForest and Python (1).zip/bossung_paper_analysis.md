# EDForest and Bossung Curve Analysis - Paper Review

## Paper Information
- **Title**: Improved Model for Focus-Exposure Data Analysis
- **Authors**: Chris A. Mack and Jeffrey D. Byers
- **Organization**: KLA-Tencor, FINLE Division
- **Publication**: SPIE Vol. 5038, pp. 396-405 (2003)

## Key Concepts

### Bossung Curve Definition
A Bossung curve is a plot showing the relationship between **Critical Dimension (CD)** and **Focus (F)** at a constant **Exposure (E)** level. The paper presents Figure 1, which shows multiple Bossung curves for different exposure doses (160.0 to 320.0 mJ/cm²).

### Mathematical Model
The paper introduces a physics-based polynomial function for fitting focus-exposure matrix data:

**Equation (1) - General CD Model:**
```
CD = Σ(i=0 to 3) Σ(j=0 to 4) a_ij * E^i * F^j
```

Key coefficients typically fixed to zero: a₀₃, a₂₂, a₁₄, a₂₅, a₂₄, a₃₅, a₃₄

### Data Analysis Approach
1. **Chi-squared minimization** (Equation 2): Optimize coefficients to minimize deviation
2. **Weighted chi-squared** (Equation 4): Weight data points by measurement uncertainty
3. **Data flier removal**: Remove outliers exceeding 2σ deviation, then refit

### Physics-Based Fitting
The paper derives a physics-based model from first principles:
- **Aerial Image Model** (Equation 5): Fourier series representation
- **Taylor Series Expansion** (Equation 8): For small deviations from nominal size
- **Dose-to-Size Relationship** (Equation 10): Connects exposure dose to CD

### Process Window Analysis
- **Depth of Focus (DOF)**: Range of focus values where CD remains within specification
- **Exposure Latitude (EL)**: Range of exposure values where CD remains within specification
- **Maximum Inscribed Rectangle**: Optimal process window in E-D plane

## Bossung Curve Characteristics
- **X-axis**: Focus (typically -1.5 to +0.5 μm)
- **Y-axis**: Critical Dimension (CD in nm, typically 0-800 nm)
- **Multiple curves**: Each curve represents a constant exposure dose
- **U-shaped curves**: Typical parabolic shape with minimum around zero focus
- **Asymmetry**: Often shows asymmetric behavior at extreme focus values

## Data Structure for Implementation
- **Input**: Focus-Exposure matrix with CD measurements
- **Processing**: Fit polynomial coefficients to data
- **Output**: Bossung curves for visualization and process window analysis
