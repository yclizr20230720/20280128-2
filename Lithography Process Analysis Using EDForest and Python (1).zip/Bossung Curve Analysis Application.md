# Bossung Curve Analysis Application

Professional Python tool for lithography process window analysis based on EDForest methodology and focus-exposure matrix data.

## Overview

This application implements a complete workflow for analyzing semiconductor lithography process windows using Bossung curves. It provides:

- **Mock Data Generation**: Realistic focus-exposure matrix data based on physics-based polynomial models
- **Polynomial Fitting**: Chi-squared optimization with iterative outlier removal
- **Bossung Curve Visualization**: Professional publication-quality plots
- **Process Window Analysis**: Calculation of DOF, EL, and Maximum Inscribed Rectangle
- **Comprehensive Reporting**: Detailed analysis reports and metrics

## Features

### 1. Data Generation (`data_generator.py`)
- Generate realistic focus-exposure matrix data
- Physics-based polynomial model (Equation 1 from the reference paper)
- Configurable exposure and focus ranges
- Optional measurement noise and outliers
- Direct CSV export

### 2. Polynomial Fitting (`polynomial_fitter.py`)
- Implements chi-squared optimization from the reference paper
- Iterative outlier removal (>2σ threshold)
- Weighted fitting using measurement uncertainty
- Calculates R² and residual statistics
- Supports up to 20 adjustable coefficients

### 3. Bossung Curve Visualization (`bossung_plotter.py`)
- Multiple Bossung curves (CD vs Focus at constant Exposure)
- Color-coded by exposure level
- Specification limit bands (±10% CD tolerance)
- Data points with fitted curves
- Process window contour maps
- Residuals analysis plots
- 300 DPI publication-quality output

### 4. Process Window Analysis (`process_window_analyzer.py`)
- **Depth of Focus (DOF)**: Range of focus values within specification
- **Exposure Latitude (EL)**: Range of exposure values within specification
- **Maximum Inscribed Rectangle (MIR)**: Optimal process window
- Optimal process point identification
- Comprehensive analysis reports

### 5. Main Application (`bossung_app.py`)
- Unified command-line interface
- Complete analysis pipeline
- Batch processing capability
- Flexible output directory management

## Installation

### Requirements
- Python 3.11+
- NumPy, Pandas, SciPy
- Matplotlib, Seaborn
- scikit-learn

### Setup
```bash
# Install dependencies
sudo pip3 install scipy scikit-learn matplotlib seaborn

# Navigate to application directory
cd /home/ubuntu/bossung_app
```

## Usage

### Quick Start (with Mock Data)
```bash
python3.11 bossung_app.py
```

This generates a complete analysis with default parameters:
- Target CD: 250 nm
- Tolerance: ±10%
- Output directory: `./output`

### Using Custom Input Data
```bash
python3.11 bossung_app.py --input my_data.csv --output ./results
```

### Custom Parameters
```bash
python3.11 bossung_app.py \
  --target-cd 300 \
  --tolerance 0.15 \
  --output ./custom_output \
  --grid-points 60
```

### Command-Line Options
```
--input, -i         Input CSV file with focus-exposure data
--output, -o        Output directory for results (default: ./output)
--target-cd         Target critical dimension in nm (default: 250)
--tolerance         CD tolerance as fraction (default: 0.10 for ±10%)
--grid-points       Grid points for process window (default: 50)
--help              Show help message
```

## Input Data Format

The input CSV file should have the following columns:

| Column | Description | Unit |
|--------|-------------|------|
| exposure_dose | Exposure dose | mJ/cm² |
| focus | Focus position | μm |
| critical_dimension | Measured CD | nm |
| measurement_uncertainty | Measurement error (optional) | nm |

### Example Input
```csv
exposure_dose,focus,critical_dimension,measurement_uncertainty
160.0,-1.5,337.83,8.45
160.0,-1.36,309.39,7.73
160.0,-1.21,350.56,8.76
...
320.0,0.5,357.97,8.95
```

## Output Files

After running the analysis, the output directory contains:

| File | Description |
|------|-------------|
| `mock_data.csv` | Input data used for analysis |
| `bossung_curves.png` | Bossung curve visualization (300 DPI) |
| `process_window.png` | Process window contour map (300 DPI) |
| `process_window_report.txt` | Analysis report with metrics |

### Sample Output Report
```
======================================================================
PROCESS WINDOW ANALYSIS REPORT
======================================================================

Target CD: 250.0 nm
CD Tolerance: ±10%
Spec Limits: 225.0 - 275.0 nm

Depth of Focus (DOF):
  Average: 0.1190 μm
  Range: 0.0000 - 0.4286 μm

Exposure Latitude (EL):
  Average: 70.00 mJ/cm²
  Range: 0.00 - 120.00 mJ/cm²

Maximum Inscribed Rectangle (MIR):
  Exposure: 160.0 - 320.0 mJ/cm²
  Focus: -1.5 - 0.5 μm
  Area: 240.0 (mJ/cm² × μm)
  Center: E=240.0, F=-0.5
```

## Mathematical Model

### Polynomial Model (Equation 1)
The application uses a physics-based polynomial model:

```
CD = Σ(i=0 to 3) Σ(j=0 to 4) a_ij * E^i * F^j
```

Where:
- **E**: Exposure dose (normalized)
- **F**: Focus position
- **CD**: Critical dimension
- **a_ij**: Polynomial coefficients

### Fitting Procedure
1. **Initial Fit**: Minimize chi-squared with all data points
2. **Outlier Detection**: Identify points exceeding 2σ deviation
3. **Data Removal**: Remove outliers from dataset
4. **Refit**: Optimize coefficients with cleaned data

### Process Window Metrics
- **DOF**: Focus range where CD ∈ [CD_min, CD_max]
- **EL**: Exposure range where CD ∈ [CD_min, CD_max]
- **MIR**: Largest rectangle in E-F plane satisfying spec

## Module Architecture

```
bossung_app/
├── data_generator.py          # Mock data generation
├── polynomial_fitter.py       # Chi-squared fitting
├── bossung_plotter.py         # Visualization
├── process_window_analyzer.py # Analysis metrics
├── bossung_app.py             # Main application
├── mock_data.csv              # Sample input data
└── README.md                  # This file
```

## Example Workflow

### Python API Usage
```python
from bossung_app import BosungAnalysisApp

# Create application instance
app = BosungAnalysisApp(output_dir='./my_results')

# Generate mock data or load from file
app.generate_mock_data()
# OR
# app.load_data('my_data.csv')

# Fit polynomial model
results = app.fit_polynomial_model()
print(f"R² = {results['r_squared']:.6f}")

# Generate visualizations
app.plot_bossung_curves(target_cd=250, cd_tolerance=0.10)
app.plot_process_window(target_cd=250, cd_tolerance=0.10)

# Analyze process window
analysis = app.analyze_process_window()
print(analysis['report'])
```

## Reference

The application is based on the methodology described in:

**"Improved Model for Focus-Exposure Data Analysis"**
- Authors: Chris A. Mack and Jeffrey D. Byers
- Organization: KLA-Tencor, FINLE Division
- Publication: SPIE Vol. 5038, pp. 396-405 (2003)

Key concepts:
- Physics-based polynomial fitting for lithography data
- Iterative outlier removal for data quality
- Process window determination from focus-exposure matrices
- Bossung curve analysis for process characterization

## Advanced Features

### Custom Fitting Parameters
```python
from polynomial_fitter import PolynomialFitter

fitter = PolynomialFitter(
    max_iterations=3,           # More iterations
    sigma_threshold=2.5         # Stricter outlier removal
)
results = fitter.fit(df, use_weights=True)
```

### Custom Visualization Styles
```python
from bossung_plotter import BosungPlotter

plotter = BosungPlotter(
    style='seaborn-v0_8-whitegrid',
    dpi=300                     # Higher resolution
)
fig, ax = plotter.plot_bossung_curves(
    df,
    colormap='plasma',
    figsize=(14, 9)
)
```

### Batch Processing
```python
import os
from bossung_app import BosungAnalysisApp

data_files = ['data1.csv', 'data2.csv', 'data3.csv']

for data_file in data_files:
    app = BosungAnalysisApp(output_dir=f'./results/{data_file[:-4]}')
    app.load_data(data_file)
    app.fit_polynomial_model()
    app.plot_bossung_curves()
    app.analyze_process_window()
```

## Troubleshooting

### Issue: "No in-spec region found" in MIR analysis
**Cause**: Mock data model may not generate CD values within specification limits.
**Solution**: Adjust target CD or tolerance parameters to match data range.

### Issue: Low R² value in polynomial fit
**Cause**: Data has high noise or model is underfitted.
**Solution**: Increase iterations or adjust sigma threshold for outlier removal.

### Issue: Memory error with large datasets
**Cause**: Grid generation uses too many points.
**Solution**: Reduce `--grid-points` parameter (default: 50).

## Performance

Typical execution times (on modern hardware):
- Mock data generation (135 points): ~0.1 seconds
- Polynomial fitting: ~0.5 seconds
- Bossung curve plotting: ~1 second
- Process window analysis: ~1 second
- **Total**: ~2-3 seconds

## License

This application is provided as-is for research and educational purposes.

## Support

For issues, questions, or feature requests, please refer to the documentation or contact the development team.

---

**Version**: 1.0  
**Last Updated**: January 2026  
**Python Version**: 3.11+
