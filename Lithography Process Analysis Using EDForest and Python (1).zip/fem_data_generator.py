#!/usr/bin/env python3.11
"""
FEM Mock Data Generator
Generate realistic focus-exposure matrix data for multiple patterns
"""

import numpy as np
import pandas as pd
from typing import Dict, Tuple, List, Optional
from fem_processor import PatternInfo, FEMMatrix


class FEMDataGenerator:
    """
    Generator for realistic Focus-Exposure Matrix data.
    
    Creates physics-based mock data for multiple lithography patterns
    with configurable characteristics.
    """
    
    def __init__(self, seed: Optional[int] = None):
        """
        Initialize generator.
        
        Args:
            seed: Random seed for reproducibility
        """
        if seed is not None:
            np.random.seed(seed)
    
    def _polynomial_model(self,
                         exposure: np.ndarray,
                         focus: np.ndarray,
                         coefficients: Dict[str, float]) -> np.ndarray:
        """
        Physics-based polynomial model for CD.
        
        Args:
            exposure: Exposure dose values
            focus: Focus values
            coefficients: Model coefficients
            
        Returns:
            Predicted CD values
        """
        # Normalize inputs
        e_norm = (exposure - 240) / 80  # Normalized exposure
        f_norm = focus / 1.0  # Normalized focus
        
        # Polynomial model
        cd = (coefficients['a0'] +
              coefficients['a1'] * e_norm +
              coefficients['a2'] * e_norm**2 +
              coefficients['a3'] * f_norm +
              coefficients['a4'] * f_norm**2 +
              coefficients['a5'] * e_norm * f_norm +
              coefficients['a6'] * e_norm**2 * f_norm +
              coefficients['a7'] * e_norm * f_norm**2)
        
        return cd
    
    def generate_pattern_matrix(self,
                               pattern_name: str,
                               pattern_type: str,
                               target_cd: float = 250.0,
                               exposure_range: Tuple[float, float] = (160.0, 320.0),
                               exposure_points: int = 9,
                               focus_range: Tuple[float, float] = (-1.5, 0.5),
                               focus_points: int = 15,
                               coefficients: Optional[Dict] = None,
                               noise_level: float = 0.03,
                               add_outliers: bool = False) -> FEMMatrix:
        """
        Generate FEM matrix for a specific pattern.
        
        Args:
            pattern_name: Name of pattern
            pattern_type: Type of pattern (line, contact, via, dense, isolated)
            target_cd: Target CD in nm
            exposure_range: (min, max) exposure dose
            exposure_points: Number of exposure levels
            focus_range: (min, max) focus
            focus_points: Number of focus points
            coefficients: Model coefficients (if None, use defaults)
            noise_level: Measurement noise as fraction
            add_outliers: Whether to add outlier points
            
        Returns:
            FEMMatrix object
        """
        # Create exposure and focus grids
        exposures = np.linspace(exposure_range[0], exposure_range[1], exposure_points)
        focuses = np.linspace(focus_range[0], focus_range[1], focus_points)
        
        # Default coefficients (tuned for different pattern types)
        if coefficients is None:
            coefficients = self._get_default_coefficients(pattern_type, target_cd)
        
        # Generate CD matrix
        cd_matrix = np.zeros((len(focuses), len(exposures)))
        
        for i, f in enumerate(focuses):
            for j, e in enumerate(exposures):
                exp_arr = np.array([e])
                foc_arr = np.array([f])
                cd_matrix[i, j] = self._polynomial_model(exp_arr, foc_arr, coefficients)[0]
        
        # Add measurement noise
        if noise_level > 0:
            noise = np.random.normal(0, noise_level * target_cd, cd_matrix.shape)
            cd_matrix += noise
        
        # Add outliers
        if add_outliers:
            n_outliers = max(1, int(0.02 * cd_matrix.size))
            outlier_indices = np.random.choice(cd_matrix.size, n_outliers, replace=False)
            for idx in outlier_indices:
                i, j = np.unravel_index(idx, cd_matrix.shape)
                cd_matrix[i, j] += np.random.choice([-1, 1]) * np.random.uniform(20, 50)
        
        # Create pattern info
        pattern_info = PatternInfo(
            name=pattern_name,
            pattern_type=pattern_type,
            target_cd=target_cd,
            cd_tolerance=0.10,
            description=f"{pattern_type.capitalize()} pattern with target CD {target_cd} nm"
        )
        
        # Create FEM matrix
        fem_matrix = FEMMatrix(
            exposure_values=exposures,
            focus_values=focuses,
            cd_matrix=cd_matrix,
            pattern_info=pattern_info
        )
        
        return fem_matrix
    
    def _get_default_coefficients(self, pattern_type: str, target_cd: float) -> Dict[str, float]:
        """
        Get default coefficients for pattern type.
        
        Args:
            pattern_type: Type of pattern
            target_cd: Target CD
            
        Returns:
            Dictionary of coefficients
        """
        # Base coefficients
        base = {
            'a0': target_cd,
            'a1': 0.5,      # Exposure sensitivity
            'a2': 0.05,     # Exposure quadratic
            'a3': -2.0,     # Focus sensitivity
            'a4': 8.0,      # Focus quadratic
            'a5': 0.2,      # Cross term
            'a6': 0.05,     # Higher order
            'a7': -0.1
        }
        
        # Adjust for pattern type
        if pattern_type == 'line':
            base['a3'] *= 1.2  # More focus sensitive
            base['a4'] *= 1.1
        elif pattern_type == 'contact':
            base['a3'] *= 0.8  # Less focus sensitive
            base['a4'] *= 0.9
        elif pattern_type == 'via':
            base['a1'] *= 0.9  # Less exposure sensitive
            base['a2'] *= 0.8
        elif pattern_type == 'dense':
            base['a1'] *= 1.1  # More exposure sensitive
            base['a2'] *= 1.2
        elif pattern_type == 'isolated':
            base['a1'] *= 0.7  # Less exposure sensitive
            base['a3'] *= 1.3  # More focus sensitive
        
        return base
    
    def generate_multi_pattern_dataset(self,
                                      patterns: List[Dict],
                                      exposure_range: Tuple[float, float] = (160.0, 320.0),
                                      exposure_points: int = 9,
                                      focus_range: Tuple[float, float] = (-1.5, 0.5),
                                      focus_points: int = 15,
                                      noise_level: float = 0.03) -> Dict[str, FEMMatrix]:
        """
        Generate FEM matrices for multiple patterns.
        
        Args:
            patterns: List of pattern dictionaries with keys:
                     'name', 'type', 'target_cd', 'tolerance'
            exposure_range: Exposure range
            exposure_points: Number of exposure points
            focus_range: Focus range
            focus_points: Number of focus points
            noise_level: Measurement noise level
            
        Returns:
            Dictionary of pattern_name -> FEMMatrix
        """
        matrices = {}
        
        for pattern in patterns:
            fem_matrix = self.generate_pattern_matrix(
                pattern_name=pattern['name'],
                pattern_type=pattern['type'],
                target_cd=pattern.get('target_cd', 250.0),
                exposure_range=exposure_range,
                exposure_points=exposure_points,
                focus_range=focus_range,
                focus_points=focus_points,
                noise_level=noise_level,
                add_outliers=False
            )
            matrices[pattern['name']] = fem_matrix
        
        return matrices
    
    def generate_standard_patterns(self,
                                  exposure_range: Tuple[float, float] = (160.0, 320.0),
                                  exposure_points: int = 9,
                                  focus_range: Tuple[float, float] = (-1.5, 0.5),
                                  focus_points: int = 15,
                                  noise_level: float = 0.03) -> Dict[str, FEMMatrix]:
        """
        Generate standard set of patterns.
        
        Args:
            exposure_range: Exposure range
            exposure_points: Number of exposure points
            focus_range: Focus range
            focus_points: Number of focus points
            noise_level: Measurement noise level
            
        Returns:
            Dictionary of pattern_name -> FEMMatrix
        """
        standard_patterns = [
            {'name': 'Line_45nm', 'type': 'line', 'target_cd': 45.0},
            {'name': 'Contact_50nm', 'type': 'contact', 'target_cd': 50.0},
            {'name': 'Via_60nm', 'type': 'via', 'target_cd': 60.0},
            {'name': 'Dense_250nm', 'type': 'dense', 'target_cd': 250.0},
            {'name': 'Isolated_300nm', 'type': 'isolated', 'target_cd': 300.0},
        ]
        
        return self.generate_multi_pattern_dataset(
            patterns=standard_patterns,
            exposure_range=exposure_range,
            exposure_points=exposure_points,
            focus_range=focus_range,
            focus_points=focus_points,
            noise_level=noise_level
        )
    
    def generate_combined_dataframe(self,
                                   matrices: Dict[str, FEMMatrix]) -> pd.DataFrame:
        """
        Combine multiple FEM matrices into single DataFrame.
        
        Args:
            matrices: Dictionary of pattern_name -> FEMMatrix
            
        Returns:
            Combined DataFrame with pattern column
        """
        dfs = []
        
        for pattern_name, fem_matrix in matrices.items():
            df = fem_matrix.to_dataframe()
            df['pattern'] = pattern_name
            dfs.append(df)
        
        return pd.concat(dfs, ignore_index=True)
    
    def export_matrices_to_csv(self,
                              matrices: Dict[str, FEMMatrix],
                              output_dir: str) -> None:
        """
        Export all matrices to CSV files.
        
        Args:
            matrices: Dictionary of pattern_name -> FEMMatrix
            output_dir: Output directory path
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        for pattern_name, fem_matrix in matrices.items():
            filename = os.path.join(output_dir, f"{pattern_name}_fem_data.csv")
            fem_matrix.to_csv(filename)
            print(f"✓ Exported {pattern_name} to {filename}")
    
    def generate_sensitivity_study(self,
                                  base_pattern: str = 'Dense_250nm',
                                  variations: Optional[Dict] = None) -> Dict[str, FEMMatrix]:
        """
        Generate sensitivity study with parameter variations.
        
        Args:
            base_pattern: Base pattern name
            variations: Dictionary of parameter variations
            
        Returns:
            Dictionary of variation_name -> FEMMatrix
        """
        if variations is None:
            variations = {
                'high_focus_sensitivity': {'a3': 1.5, 'a4': 1.2},
                'low_focus_sensitivity': {'a3': 0.5, 'a4': 0.8},
                'high_exposure_sensitivity': {'a1': 1.3, 'a2': 1.2},
                'low_exposure_sensitivity': {'a1': 0.7, 'a2': 0.8},
            }
        
        matrices = {}
        base_coeff = self._get_default_coefficients('dense', 250.0)
        
        for var_name, var_coeff in variations.items():
            # Modify coefficients
            modified_coeff = base_coeff.copy()
            modified_coeff.update(var_coeff)
            
            fem_matrix = self.generate_pattern_matrix(
                pattern_name=var_name,
                pattern_type='dense',
                target_cd=250.0,
                coefficients=modified_coeff,
                noise_level=0.03
            )
            matrices[var_name] = fem_matrix
        
        return matrices


class FEMDataValidator:
    """
    Validator for FEM data quality and consistency.
    """
    
    @staticmethod
    def validate_matrix(fem_matrix: FEMMatrix) -> Dict[str, bool]:
        """
        Validate FEM matrix.
        
        Args:
            fem_matrix: FEMMatrix object
            
        Returns:
            Dictionary of validation results
        """
        results = {}
        
        # Check for NaN values
        results['no_nans'] = not np.isnan(fem_matrix.cd_matrix).any()
        
        # Check for reasonable CD range
        cd_mean = np.mean(fem_matrix.cd_matrix)
        cd_std = np.std(fem_matrix.cd_matrix)
        results['reasonable_range'] = (cd_std > 0) and (cd_std < cd_mean)
        
        # Check monotonicity
        grad_e, grad_f = fem_matrix.get_gradient()
        results['smooth_gradient'] = (np.abs(grad_e).max() < 100) and (np.abs(grad_f).max() < 100)
        
        # Check matrix shape
        results['valid_shape'] = fem_matrix.cd_matrix.ndim == 2
        
        return results
    
    @staticmethod
    def print_validation_report(fem_matrix: FEMMatrix) -> None:
        """Print validation report."""
        results = FEMDataValidator.validate_matrix(fem_matrix)
        
        print("\nFEM Data Validation Report")
        print("=" * 50)
        for check, passed in results.items():
            status = "✓ PASS" if passed else "✗ FAIL"
            print(f"{check:.<40} {status}")
        print("=" * 50)
