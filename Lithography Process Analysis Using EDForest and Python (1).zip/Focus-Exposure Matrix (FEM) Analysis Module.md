# Focus-Exposure Matrix (FEM) Analysis Module

Comprehensive Python framework for lithography process window analysis with advanced Focus-Exposure Matrix (FEM) capabilities.

## Overview

The FEM module extends the Bossung curve application with professional-grade tools for:

- **Dose-Focus Matrix Analysis**: Analyze focus-exposure matrices to identify optimal lithography conditions
- **Contour Map Visualization**: Multi-level contour visualizations with specification limits
- **Optimal Point Detection**: Automatic detection of best process settings
- **Process Window Extraction**: Quantification of usable process margins
- **Multi-Pattern Analysis**: Comparative analysis across different lithography patterns
- **DOF/EL Metrics**: Depth of Focus and Exposure Latitude calculation

## Architecture

### Core Modules

#### 1. **fem_processor.py** - FEM Data Processing
- `FEMMatrix`: Core data structure for dose-focus matrices
- `FEMProcessor`: Main processor for matrix operations
- `MultiPatternAnalyzer`: Comparative analysis across patterns

**Key Features**:
- Matrix interpolation and smoothing
- In-specification region detection
- Process window extraction
- DOF/EL calculation
- Optimal point finding

#### 2. **fem_visualizer.py** - Advanced Visualization
- `FEMVisualizer`: Professional visualization engine

**Visualization Types**:
- Contour maps with specification limits
- Heatmaps with annotations
- Process window overlays
- Gradient field visualization
- Multi-pattern comparison grids
- DOF/EL analysis plots

#### 3. **fem_data_generator.py** - Mock Data Generation
- `FEMDataGenerator`: Realistic data generation
- `FEMDataValidator`: Data quality validation

**Supported Patterns**:
- Line patterns (45 nm)
- Contact patterns (50 nm)
- Via patterns (60 nm)
- Dense patterns (250 nm)
- Isolated patterns (300 nm)

#### 4. **fem_app.py** - Integrated Application
- `FEMAnalysisApp`: Main application interface

**Workflow**:
1. Load or generate FEM data
2. Analyze individual patterns
3. Generate visualizations
4. Compare multiple patterns
5. Generate comprehensive reports

## Quick Start

### Installation

```bash
cd /home/ubuntu/bossung_app

# Verify dependencies
python3.11 -c "import numpy, pandas, matplotlib, scipy; print('✓ OK')"
```

### Basic Usage

#### Command-Line Interface

```bash
# Generate and analyze standard patterns
python3.11 fem_app.py

# Analyze custom data
python3.11 fem_app.py --input my_fem_data.csv

# Custom parameters
python3.11 fem_app.py --target-cd 300 --tolerance 0.15 --output ./results
```

#### Python API

```python
from fem_app import FEMAnalysisApp

# Create application
app = FEMAnalysisApp(output_dir='./fem_results')

# Generate mock data
app.generate_mock_data(pattern_type='standard')

# Analyze pattern
results = app.analyze_pattern('Dense_250nm', target_cd=250.0, cd_tolerance=0.10)

# Generate visualizations
plots = app.visualize_pattern(
    'Dense_250nm',
    plot_types=['contour', 'process_window', 'dof_el']
)

# Compare patterns
app.compare_patterns(target_cd=250.0, cd_tolerance=0.10)
```

## Data Format

### Input CSV Format

```csv
exposure_dose,focus,critical_dimension
160.0,-1.5,337.83
160.0,-1.36,309.39
...
320.0,0.5,357.97
```

**Columns**:
- `exposure_dose`: Exposure dose in mJ/cm²
- `focus`: Focus position in μm
- `critical_dimension`: Measured CD in nm

### Pattern Information

```python
from fem_processor import PatternInfo

pattern_info = PatternInfo(
    name='Dense_250nm',
    pattern_type='dense',
    target_cd=250.0,
    cd_tolerance=0.10,
    description='Dense pattern with 250 nm target'
)
```

## Key Features

### 1. Matrix Operations

```python
from fem_processor import FEMProcessor

processor = FEMProcessor()
fem_matrix = processor.load_matrix_from_csv('data.csv')

# Get interpolated CD value
cd = fem_matrix.get_cd_at_point(exposure=200.0, focus=-0.5)

# Extract Bossung curve
focus_vals, cd_vals = fem_matrix.get_bossung_curve(exposure=200.0)

# Get statistics
stats = fem_matrix.get_statistics()
print(f"Mean CD: {stats['mean_cd']:.2f} nm")
```

### 2. Process Window Analysis

```python
# Extract process window
pw = processor.extract_process_window(
    pattern_name='Dense_250nm',
    target_cd=250.0,
    tolerance=0.10
)

print(f"Exposure Range: {pw['exposure_range']}")
print(f"Focus Range: {pw['focus_range']}")
print(f"Area: {pw['area']:.2f}")
```

### 3. DOF/EL Calculation

```python
# Calculate DOF and EL
dof_el = processor.calculate_dof_el(
    pattern_name='Dense_250nm',
    target_cd=250.0,
    tolerance=0.10
)

print(f"Average DOF: {dof_el['avg_dof']:.4f} μm")
print(f"Average EL: {dof_el['avg_el']:.2f} mJ/cm²")
```

### 4. Optimal Point Detection

```python
# Find optimal process point
optimal = processor.get_optimal_point(
    pattern_name='Dense_250nm',
    target_cd=250.0,
    tolerance=0.10
)

print(f"Optimal E: {optimal['exposure']:.1f} mJ/cm²")
print(f"Optimal F: {optimal['focus']:.3f} μm")
print(f"CD: {optimal['cd']:.2f} nm")
```

### 5. Multi-Pattern Comparison

```python
from fem_processor import MultiPatternAnalyzer

analyzer = MultiPatternAnalyzer(processor)

# Generate comparison report
report = analyzer.generate_comparison_report()

# Get best pattern
best = analyzer.get_best_pattern(metric='area')

# Rank patterns
ranking = analyzer.get_pattern_ranking(metric='dof')
```

### 6. Advanced Visualization

```python
from fem_visualizer import FEMVisualizer

visualizer = FEMVisualizer(dpi=300)

# Contour plot
fig, ax = visualizer.plot_fem_contour(
    fem_matrix,
    target_cd=250.0,
    cd_tolerance=0.10,
    levels=20
)
visualizer.save_figure('contour.png')

# Process window overlay
fig, ax = visualizer.plot_process_window_overlay(
    fem_matrix,
    target_cd=250.0,
    cd_tolerance=0.10
)
visualizer.save_figure('process_window.png')

# Multi-pattern comparison
fig, axes = visualizer.plot_multi_pattern_comparison(
    processor,
    target_cd=250.0,
    cd_tolerance=0.10
)
visualizer.save_figure('comparison.png')
```

## Output Files

### Generated Visualizations

| File | Description |
|------|-------------|
| `{pattern}_contour.png` | FEM contour map with spec limits |
| `{pattern}_heatmap.png` | Heatmap representation |
| `{pattern}_process_window.png` | Process window overlay |
| `{pattern}_gradient.png` | CD gradient field |
| `{pattern}_dof_el.png` | DOF/EL analysis plots |
| `multi_pattern_comparison.png` | Multi-pattern grid comparison |
| `multi_pattern_report.txt` | Comprehensive analysis report |

### Data Files

| File | Description |
|------|-------------|
| `{pattern}_fem_data.csv` | FEM matrix in CSV format |
| `fem_data/` | Directory with all pattern data |

## Mathematical Foundations

### Polynomial Model

The FEM analysis uses a physics-based polynomial model:

```
CD = Σ(i=0 to 3) Σ(j=0 to 4) a_ij * E^i * F^j
```

Where:
- **E**: Normalized exposure dose
- **F**: Focus position
- **CD**: Critical dimension
- **a_ij**: Polynomial coefficients

### Process Window Metrics

**Depth of Focus (DOF)**:
```
DOF = max(F) - min(F) where CD ∈ [CD_min, CD_max]
```

**Exposure Latitude (EL)**:
```
EL = max(E) - min(E) where CD ∈ [CD_min, CD_max]
```

**In-Specification Region**:
```
In-spec if: CD_target × (1 - tolerance) ≤ CD ≤ CD_target × (1 + tolerance)
```

## Pattern Types

### Line Patterns
- **Characteristics**: High focus sensitivity
- **Use Case**: Gate patterns, metal lines
- **Typical CD**: 45-90 nm

### Contact Patterns
- **Characteristics**: Lower focus sensitivity
- **Use Case**: Contact holes
- **Typical CD**: 50-100 nm

### Via Patterns
- **Characteristics**: Moderate sensitivity
- **Use Case**: Via connections
- **Typical CD**: 60-120 nm

### Dense Patterns
- **Characteristics**: High exposure sensitivity
- **Use Case**: Densely packed features
- **Typical CD**: 200-300 nm

### Isolated Patterns
- **Characteristics**: Low exposure sensitivity, high focus sensitivity
- **Use Case**: Isolated features
- **Typical CD**: 250-400 nm

## Advanced Usage

### Custom Pattern Definition

```python
from fem_processor import PatternInfo
from fem_data_generator import FEMDataGenerator

generator = FEMDataGenerator(seed=42)

# Define custom pattern
custom_pattern = PatternInfo(
    name='custom_45nm',
    pattern_type='line',
    target_cd=45.0,
    cd_tolerance=0.10,
    description='Custom 45nm line pattern'
)

# Generate with custom coefficients
coefficients = {
    'a0': 45.0,
    'a1': 0.6,
    'a2': 0.08,
    'a3': -2.5,
    'a4': 9.0,
    'a5': 0.25,
    'a6': 0.06,
    'a7': -0.12
}

fem_matrix = generator.generate_pattern_matrix(
    pattern_name='custom_45nm',
    pattern_type='line',
    target_cd=45.0,
    coefficients=coefficients
)
```

### Sensitivity Study

```python
# Generate sensitivity variations
variations = {
    'high_focus': {'a3': 1.5, 'a4': 1.2},
    'low_focus': {'a3': 0.5, 'a4': 0.8},
    'high_exposure': {'a1': 1.3, 'a2': 1.2},
    'low_exposure': {'a1': 0.7, 'a2': 0.8},
}

sensitivity_matrices = generator.generate_sensitivity_study(
    base_pattern='Dense_250nm',
    variations=variations
)
```

### Batch Processing

```python
import os
from fem_app import FEMAnalysisApp

# Process multiple files
data_files = ['pattern1.csv', 'pattern2.csv', 'pattern3.csv']

for filename in data_files:
    app = FEMAnalysisApp(output_dir=f'./results/{filename[:-4]}')
    app.load_data_from_csv(filename)
    app.analyze_pattern(target_cd=250.0, cd_tolerance=0.10)
    app.visualize_pattern(plot_types=['contour', 'process_window'])
    print(f"✓ Processed {filename}")
```

## Performance Characteristics

### Typical Execution Times

| Operation | Time |
|-----------|------|
| Generate 5 patterns (135 pts each) | ~2 seconds |
| Analyze single pattern | ~0.5 seconds |
| Generate contour plot (300 DPI) | ~1 second |
| Multi-pattern comparison | ~3 seconds |
| **Total workflow** | **~6-8 seconds** |

### Memory Usage

| Scenario | Memory |
|----------|--------|
| Single pattern (135 points) | ~5 MB |
| 5 patterns | ~25 MB |
| High-res grid (100×100) | ~50 MB |

### Output File Sizes

| File Type | Size |
|-----------|------|
| Contour plot (300 DPI) | ~500-1200 KB |
| Heatmap | ~100-300 KB |
| Multi-pattern grid | ~800-1000 KB |
| CSV data | ~8-10 KB |

## Troubleshooting

### Issue: "No in-spec region found"

**Cause**: Generated data doesn't match target CD within tolerance

**Solution**:
```python
# Adjust target CD to match data range
app.analyze_pattern(target_cd=240.0, cd_tolerance=0.15)

# Or adjust data generation
app.generate_mock_data(pattern_type='standard')
```

### Issue: Low R² in polynomial fit

**Cause**: High noise or poor model fit

**Solution**:
- Reduce noise level in data generation
- Use higher polynomial order
- Increase number of data points

### Issue: Memory error with large grids

**Cause**: Grid too fine for available memory

**Solution**:
```bash
# Reduce grid resolution
python3.11 fem_app.py --output ./results  # Uses default grid
```

## Integration with Bossung Module

The FEM module integrates seamlessly with the existing Bossung curve analysis:

```python
from bossung_app import BosungAnalysisApp
from fem_app import FEMAnalysisApp

# Generate Bossung curves
bossung_app = BosungAnalysisApp()
bossung_app.generate_mock_data()
bossung_app.plot_bossung_curves()

# Generate FEM analysis
fem_app = FEMAnalysisApp()
fem_app.generate_mock_data()
fem_app.visualize_pattern()

# Both can use same data format
df = bossung_app.data
fem_app.processor.load_matrix_from_dataframe(df)
```

## References

- Mack, C. A., & Byers, J. D. (2003). "Improved Model for Focus-Exposure Data Analysis"
- SPIE Vol. 5038, pp. 396-405
- Semiconductor lithography process window theory
- Focus-exposure matrix analysis methodology

## Support

For detailed API reference, see `API_REFERENCE.md`

For usage examples, see `USAGE_GUIDE.md`

For quick start, see `QUICKSTART.md`

---

**Version**: 1.0  
**Updated**: January 2026  
**Python**: 3.11+
