#!/usr/bin/env python3.11
"""
Focus-Exposure Matrix (FEM) Data Processor
Handles dose-focus matrix analysis and operations
"""

import numpy as np
import pandas as pd
from typing import Dict, Tuple, List, Optional, Union
from dataclasses import dataclass
from scipy.interpolate import griddata, RectBivariateSpline
from scipy.ndimage import label, find_objects
import warnings


@dataclass
class PatternInfo:
    """Information about a lithography pattern."""
    name: str
    pattern_type: str  # 'line', 'contact', 'via', 'dense', 'isolated'
    target_cd: float
    cd_tolerance: float
    description: str = ""


class FEMMatrix:
    """
    Focus-Exposure Matrix representation and operations.
    
    Stores and manipulates dose-focus matrix data with support for
    multiple patterns and metrics.
    """
    
    def __init__(self,
                 exposure_values: np.ndarray,
                 focus_values: np.ndarray,
                 cd_matrix: np.ndarray,
                 pattern_info: Optional[PatternInfo] = None,
                 metadata: Optional[Dict] = None):
        """
        Initialize FEM matrix.
        
        Args:
            exposure_values: 1D array of exposure doses (mJ/cm²)
            focus_values: 1D array of focus positions (μm)
            cd_matrix: 2D array of CD values (nm), shape (len(focus), len(exposure))
            pattern_info: Pattern information
            metadata: Additional metadata dictionary
        """
        self.exposure_values = np.asarray(exposure_values)
        self.focus_values = np.asarray(focus_values)
        self.cd_matrix = np.asarray(cd_matrix)
        self.pattern_info = pattern_info
        self.metadata = metadata or {}
        
        # Validate dimensions
        if self.cd_matrix.shape != (len(focus_values), len(exposure_values)):
            raise ValueError(
                f"CD matrix shape {self.cd_matrix.shape} does not match "
                f"exposure ({len(exposure_values)}) x focus ({len(focus_values)})"
            )
        
        # Create meshgrid for interpolation
        self.exp_grid, self.foc_grid = np.meshgrid(
            self.exposure_values, self.focus_values
        )
    
    def get_shape(self) -> Tuple[int, int]:
        """Get matrix shape (n_focus, n_exposure)."""
        return self.cd_matrix.shape
    
    def get_cd_at_point(self, exposure: float, focus: float) -> float:
        """
        Get interpolated CD value at specific exposure-focus point.
        
        Args:
            exposure: Exposure dose (mJ/cm²)
            focus: Focus position (μm)
            
        Returns:
            Interpolated CD value (nm)
        """
        # Use bivariate spline for smooth interpolation
        try:
            spline = RectBivariateSpline(
                self.focus_values, self.exposure_values, self.cd_matrix
            )
            cd = spline(focus, exposure)[0, 0]
            return float(cd)
        except Exception:
            # Fallback to nearest neighbor
            idx_f = np.argmin(np.abs(self.focus_values - focus))
            idx_e = np.argmin(np.abs(self.exposure_values - exposure))
            return float(self.cd_matrix[idx_f, idx_e])
    
    def get_bossung_curve(self, exposure: float) -> Tuple[np.ndarray, np.ndarray]:
        """
        Extract Bossung curve (CD vs Focus) at constant exposure.
        
        Args:
            exposure: Exposure dose (mJ/cm²)
            
        Returns:
            Tuple of (focus_values, cd_values)
        """
        idx = np.argmin(np.abs(self.exposure_values - exposure))
        return self.focus_values, self.cd_matrix[:, idx]
    
    def get_exposure_curve(self, focus: float) -> Tuple[np.ndarray, np.ndarray]:
        """
        Extract exposure curve (CD vs Exposure) at constant focus.
        
        Args:
            focus: Focus position (μm)
            
        Returns:
            Tuple of (exposure_values, cd_values)
        """
        idx = np.argmin(np.abs(self.focus_values - focus))
        return self.exposure_values, self.cd_matrix[idx, :]
    
    def get_statistics(self) -> Dict[str, float]:
        """
        Get matrix statistics.
        
        Returns:
            Dictionary with statistics
        """
        return {
            'mean_cd': float(np.mean(self.cd_matrix)),
            'std_cd': float(np.std(self.cd_matrix)),
            'min_cd': float(np.min(self.cd_matrix)),
            'max_cd': float(np.max(self.cd_matrix)),
            'range_cd': float(np.max(self.cd_matrix) - np.min(self.cd_matrix)),
            'median_cd': float(np.median(self.cd_matrix)),
        }
    
    def get_gradient(self) -> Tuple[np.ndarray, np.ndarray]:
        """
        Calculate CD gradient in E and F directions.
        
        Returns:
            Tuple of (gradient_E, gradient_F)
        """
        grad_f, grad_e = np.gradient(self.cd_matrix)
        return grad_e, grad_f
    
    def get_curvature(self) -> np.ndarray:
        """
        Calculate Laplacian (curvature) of CD surface.
        
        Returns:
            2D array of curvature values
        """
        grad_e, grad_f = self.get_gradient()
        grad2_e = np.gradient(grad_e, axis=1)
        grad2_f = np.gradient(grad_f, axis=0)
        return grad2_e + grad2_f
    
    def to_dataframe(self) -> pd.DataFrame:
        """
        Convert matrix to DataFrame format.
        
        Returns:
            DataFrame with columns: exposure_dose, focus, critical_dimension
        """
        data = []
        for i, f in enumerate(self.focus_values):
            for j, e in enumerate(self.exposure_values):
                data.append({
                    'exposure_dose': e,
                    'focus': f,
                    'critical_dimension': self.cd_matrix[i, j]
                })
        return pd.DataFrame(data)
    
    def to_csv(self, filename: str) -> None:
        """Export matrix to CSV file."""
        self.to_dataframe().to_csv(filename, index=False)


class FEMProcessor:
    """
    Processor for Focus-Exposure Matrix data.
    
    Handles loading, processing, and analyzing FEM data with support
    for multiple patterns and comprehensive metrics.
    """
    
    def __init__(self):
        """Initialize FEM processor."""
        self.matrices: Dict[str, FEMMatrix] = {}
        self.patterns: Dict[str, PatternInfo] = {}
    
    def load_matrix_from_dataframe(self,
                                   df: pd.DataFrame,
                                   pattern_name: str = 'default',
                                   pattern_info: Optional[PatternInfo] = None) -> FEMMatrix:
        """
        Load FEM matrix from DataFrame.
        
        Args:
            df: DataFrame with columns: exposure_dose, focus, critical_dimension
            pattern_name: Name for this pattern
            pattern_info: Pattern information
            
        Returns:
            FEMMatrix object
        """
        # Extract unique values
        exposures = sorted(df['exposure_dose'].unique())
        focuses = sorted(df['focus'].unique())
        
        # Create matrix
        cd_matrix = np.zeros((len(focuses), len(exposures)))
        
        for i, f in enumerate(focuses):
            for j, e in enumerate(exposures):
                mask = (df['exposure_dose'] == e) & (df['focus'] == f)
                if mask.any():
                    cd_matrix[i, j] = df.loc[mask, 'critical_dimension'].values[0]
                else:
                    cd_matrix[i, j] = np.nan
        
        # Create FEM matrix
        fem_matrix = FEMMatrix(
            exposure_values=np.array(exposures),
            focus_values=np.array(focuses),
            cd_matrix=cd_matrix,
            pattern_info=pattern_info
        )
        
        self.matrices[pattern_name] = fem_matrix
        if pattern_info:
            self.patterns[pattern_name] = pattern_info
        
        return fem_matrix
    
    def load_matrix_from_csv(self,
                            filename: str,
                            pattern_name: str = 'default',
                            pattern_info: Optional[PatternInfo] = None) -> FEMMatrix:
        """
        Load FEM matrix from CSV file.
        
        Args:
            filename: Path to CSV file
            pattern_name: Name for this pattern
            pattern_info: Pattern information
            
        Returns:
            FEMMatrix object
        """
        df = pd.read_csv(filename)
        return self.load_matrix_from_dataframe(df, pattern_name, pattern_info)
    
    def create_matrix(self,
                     exposure_values: np.ndarray,
                     focus_values: np.ndarray,
                     cd_matrix: np.ndarray,
                     pattern_name: str = 'default',
                     pattern_info: Optional[PatternInfo] = None) -> FEMMatrix:
        """
        Create FEM matrix from arrays.
        
        Args:
            exposure_values: 1D array of exposures
            focus_values: 1D array of focuses
            cd_matrix: 2D array of CDs
            pattern_name: Name for this pattern
            pattern_info: Pattern information
            
        Returns:
            FEMMatrix object
        """
        fem_matrix = FEMMatrix(
            exposure_values=exposure_values,
            focus_values=focus_values,
            cd_matrix=cd_matrix,
            pattern_info=pattern_info
        )
        
        self.matrices[pattern_name] = fem_matrix
        if pattern_info:
            self.patterns[pattern_name] = pattern_info
        
        return fem_matrix
    
    def get_matrix(self, pattern_name: str = 'default') -> Optional[FEMMatrix]:
        """Get FEM matrix by pattern name."""
        return self.matrices.get(pattern_name)
    
    def list_patterns(self) -> List[str]:
        """Get list of loaded pattern names."""
        return list(self.matrices.keys())
    
    def get_pattern_info(self, pattern_name: str = 'default') -> Optional[PatternInfo]:
        """Get pattern information."""
        return self.patterns.get(pattern_name)
    
    def interpolate_matrix(self,
                          pattern_name: str = 'default',
                          grid_points: int = 50) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Interpolate FEM matrix to finer grid.
        
        Args:
            pattern_name: Pattern name
            grid_points: Number of grid points per dimension
            
        Returns:
            Tuple of (exposure_grid, focus_grid, cd_grid)
        """
        fem_matrix = self.get_matrix(pattern_name)
        if fem_matrix is None:
            raise ValueError(f"Pattern '{pattern_name}' not found")
        
        # Create fine grid
        exp_fine = np.linspace(
            fem_matrix.exposure_values.min(),
            fem_matrix.exposure_values.max(),
            grid_points
        )
        foc_fine = np.linspace(
            fem_matrix.focus_values.min(),
            fem_matrix.focus_values.max(),
            grid_points
        )
        
        exp_grid, foc_grid = np.meshgrid(exp_fine, foc_fine)
        
        # Interpolate
        cd_grid = griddata(
            (fem_matrix.exp_grid.ravel(), fem_matrix.foc_grid.ravel()),
            fem_matrix.cd_matrix.ravel(),
            (exp_grid, foc_grid),
            method='cubic'
        )
        
        return exp_grid, foc_grid, cd_grid
    
    def find_in_spec_region(self,
                           pattern_name: str = 'default',
                           target_cd: Optional[float] = None,
                           tolerance: Optional[float] = None) -> np.ndarray:
        """
        Find in-specification region in matrix.
        
        Args:
            pattern_name: Pattern name
            target_cd: Target CD (if None, use pattern_info)
            tolerance: CD tolerance as fraction (if None, use pattern_info)
            
        Returns:
            Boolean array indicating in-spec points
        """
        fem_matrix = self.get_matrix(pattern_name)
        if fem_matrix is None:
            raise ValueError(f"Pattern '{pattern_name}' not found")
        
        # Get target and tolerance
        if target_cd is None:
            if fem_matrix.pattern_info:
                target_cd = fem_matrix.pattern_info.target_cd
            else:
                target_cd = np.mean(fem_matrix.cd_matrix)
        
        if tolerance is None:
            if fem_matrix.pattern_info:
                tolerance = fem_matrix.pattern_info.cd_tolerance
            else:
                tolerance = 0.10
        
        # Calculate spec limits
        cd_min = target_cd * (1 - tolerance)
        cd_max = target_cd * (1 + tolerance)
        
        # Find in-spec region
        in_spec = (fem_matrix.cd_matrix >= cd_min) & (fem_matrix.cd_matrix <= cd_max)
        
        return in_spec
    
    def extract_process_window(self,
                              pattern_name: str = 'default',
                              target_cd: Optional[float] = None,
                              tolerance: Optional[float] = None) -> Dict:
        """
        Extract process window from FEM matrix.
        
        Args:
            pattern_name: Pattern name
            target_cd: Target CD
            tolerance: CD tolerance
            
        Returns:
            Dictionary with process window information
        """
        fem_matrix = self.get_matrix(pattern_name)
        if fem_matrix is None:
            raise ValueError(f"Pattern '{pattern_name}' not found")
        
        in_spec = self.find_in_spec_region(pattern_name, target_cd, tolerance)
        
        # Find exposure and focus ranges
        in_spec_indices = np.where(in_spec)
        
        if len(in_spec_indices[0]) == 0:
            # No in-spec points
            return {
                'found': False,
                'exposure_range': None,
                'focus_range': None,
                'area': 0,
                'in_spec_points': 0
            }
        
        focus_min_idx = in_spec_indices[0].min()
        focus_max_idx = in_spec_indices[0].max()
        exp_min_idx = in_spec_indices[1].min()
        exp_max_idx = in_spec_indices[1].max()
        
        focus_min = fem_matrix.focus_values[focus_min_idx]
        focus_max = fem_matrix.focus_values[focus_max_idx]
        exp_min = fem_matrix.exposure_values[exp_min_idx]
        exp_max = fem_matrix.exposure_values[exp_max_idx]
        
        # Calculate area
        area = (exp_max - exp_min) * (focus_max - focus_min)
        
        return {
            'found': True,
            'exposure_range': (exp_min, exp_max),
            'focus_range': (focus_min, focus_max),
            'area': area,
            'in_spec_points': int(np.sum(in_spec)),
            'total_points': in_spec.size,
            'in_spec_fraction': float(np.sum(in_spec) / in_spec.size)
        }
    
    def calculate_dof_el(self,
                        pattern_name: str = 'default',
                        target_cd: Optional[float] = None,
                        tolerance: Optional[float] = None) -> Dict:
        """
        Calculate Depth of Focus (DOF) and Exposure Latitude (EL).
        
        Args:
            pattern_name: Pattern name
            target_cd: Target CD
            tolerance: CD tolerance
            
        Returns:
            Dictionary with DOF and EL values
        """
        fem_matrix = self.get_matrix(pattern_name)
        if fem_matrix is None:
            raise ValueError(f"Pattern '{pattern_name}' not found")
        
        in_spec = self.find_in_spec_region(pattern_name, target_cd, tolerance)
        
        dof_values = []
        el_values = []
        
        # Calculate DOF for each exposure
        for j, exp in enumerate(fem_matrix.exposure_values):
            in_spec_col = in_spec[:, j]
            if np.any(in_spec_col):
                indices = np.where(in_spec_col)[0]
                focus_min = fem_matrix.focus_values[indices.min()]
                focus_max = fem_matrix.focus_values[indices.max()]
                dof = focus_max - focus_min
                dof_values.append({'exposure': exp, 'dof': dof})
        
        # Calculate EL for each focus
        for i, foc in enumerate(fem_matrix.focus_values):
            in_spec_row = in_spec[i, :]
            if np.any(in_spec_row):
                indices = np.where(in_spec_row)[0]
                exp_min = fem_matrix.exposure_values[indices.min()]
                exp_max = fem_matrix.exposure_values[indices.max()]
                el = exp_max - exp_min
                el_values.append({'focus': foc, 'el': el})
        
        avg_dof = np.mean([d['dof'] for d in dof_values]) if dof_values else 0
        avg_el = np.mean([e['el'] for e in el_values]) if el_values else 0
        
        return {
            'dof_values': dof_values,
            'el_values': el_values,
            'avg_dof': avg_dof,
            'avg_el': avg_el,
            'max_dof': max([d['dof'] for d in dof_values]) if dof_values else 0,
            'max_el': max([e['el'] for e in el_values]) if el_values else 0
        }
    
    def compare_patterns(self,
                        metric: str = 'area',
                        target_cd: Optional[float] = None,
                        tolerance: Optional[float] = None) -> pd.DataFrame:
        """
        Compare process windows across multiple patterns.
        
        Args:
            metric: Metric to compare ('area', 'dof', 'el', 'points')
            target_cd: Target CD
            tolerance: CD tolerance
            
        Returns:
            DataFrame with comparison results
        """
        results = []
        
        for pattern_name in self.list_patterns():
            pw = self.extract_process_window(pattern_name, target_cd, tolerance)
            dof_el = self.calculate_dof_el(pattern_name, target_cd, tolerance)
            
            if metric == 'area':
                value = pw['area']
            elif metric == 'dof':
                value = dof_el['avg_dof']
            elif metric == 'el':
                value = dof_el['avg_el']
            elif metric == 'points':
                value = pw['in_spec_points']
            else:
                value = None
            
            results.append({
                'pattern': pattern_name,
                'value': value,
                'in_spec_points': pw['in_spec_points'],
                'total_points': pw['total_points']
            })
        
        return pd.DataFrame(results)
    
    def get_optimal_point(self,
                         pattern_name: str = 'default',
                         target_cd: Optional[float] = None,
                         tolerance: Optional[float] = None) -> Dict:
        """
        Find optimal process point (center of in-spec region).
        
        Args:
            pattern_name: Pattern name
            target_cd: Target CD
            tolerance: CD tolerance
            
        Returns:
            Dictionary with optimal point information
        """
        fem_matrix = self.get_matrix(pattern_name)
        if fem_matrix is None:
            raise ValueError(f"Pattern '{pattern_name}' not found")
        
        in_spec = self.find_in_spec_region(pattern_name, target_cd, tolerance)
        
        if not np.any(in_spec):
            return {'found': False}
        
        # Find center of mass of in-spec region
        in_spec_indices = np.where(in_spec)
        avg_focus_idx = np.mean(in_spec_indices[0])
        avg_exp_idx = np.mean(in_spec_indices[1])
        
        # Clip to valid indices
        avg_focus_idx = int(np.clip(avg_focus_idx, 0, len(fem_matrix.focus_values) - 1))
        avg_exp_idx = int(np.clip(avg_exp_idx, 0, len(fem_matrix.exposure_values) - 1))
        
        optimal_exposure = fem_matrix.exposure_values[avg_exp_idx]
        optimal_focus = fem_matrix.focus_values[avg_focus_idx]
        optimal_cd = fem_matrix.cd_matrix[avg_focus_idx, avg_exp_idx]
        
        return {
            'found': True,
            'exposure': optimal_exposure,
            'focus': optimal_focus,
            'cd': optimal_cd,
            'cd_deviation': optimal_cd - (target_cd if target_cd else optimal_cd)
        }


class MultiPatternAnalyzer:
    """
    Analyzer for multiple pattern FEM data.
    
    Provides comparative analysis and visualization across different
    lithography patterns.
    """
    
    def __init__(self, fem_processor: FEMProcessor):
        """
        Initialize multi-pattern analyzer.
        
        Args:
            fem_processor: FEMProcessor instance
        """
        self.processor = fem_processor
    
    def generate_comparison_report(self,
                                  target_cd: Optional[float] = None,
                                  tolerance: Optional[float] = None) -> str:
        """
        Generate comparison report across all patterns.
        
        Args:
            target_cd: Target CD
            tolerance: CD tolerance
            
        Returns:
            Formatted report string
        """
        report = "=" * 70 + "\n"
        report += "MULTI-PATTERN FEM ANALYSIS REPORT\n"
        report += "=" * 70 + "\n\n"
        
        for pattern_name in self.processor.list_patterns():
            pattern_info = self.processor.get_pattern_info(pattern_name)
            pw = self.processor.extract_process_window(pattern_name, target_cd, tolerance)
            dof_el = self.processor.calculate_dof_el(pattern_name, target_cd, tolerance)
            optimal = self.processor.get_optimal_point(pattern_name, target_cd, tolerance)
            
            report += f"Pattern: {pattern_name}\n"
            if pattern_info:
                report += f"  Type: {pattern_info.pattern_type}\n"
                report += f"  Description: {pattern_info.description}\n"
            
            report += f"\nProcess Window:\n"
            if pw['found']:
                exp_min, exp_max = pw['exposure_range']
                foc_min, foc_max = pw['focus_range']
                report += f"  Exposure Range: {exp_min:.1f} - {exp_max:.1f} mJ/cm²\n"
                report += f"  Focus Range: {foc_min:.3f} - {foc_max:.3f} μm\n"
                report += f"  Area: {pw['area']:.2f} (mJ/cm² × μm)\n"
                report += f"  In-spec Points: {pw['in_spec_points']}/{pw['total_points']}\n"
            else:
                report += "  No in-spec region found\n"
            
            report += f"\nDOF/EL Metrics:\n"
            report += f"  Average DOF: {dof_el['avg_dof']:.4f} μm\n"
            report += f"  Average EL: {dof_el['avg_el']:.2f} mJ/cm²\n"
            report += f"  Max DOF: {dof_el['max_dof']:.4f} μm\n"
            report += f"  Max EL: {dof_el['max_el']:.2f} mJ/cm²\n"
            
            if optimal['found']:
                report += f"\nOptimal Process Point:\n"
                report += f"  Exposure: {optimal['exposure']:.1f} mJ/cm²\n"
                report += f"  Focus: {optimal['focus']:.3f} μm\n"
                report += f"  CD: {optimal['cd']:.2f} nm\n"
                report += f"  CD Deviation: {optimal['cd_deviation']:+.2f} nm\n"
            
            report += "\n" + "-" * 70 + "\n\n"
        
        return report
    
    def get_best_pattern(self, metric: str = 'area') -> str:
        """
        Get pattern with best metric value.
        
        Args:
            metric: Metric to compare ('area', 'dof', 'el')
            
        Returns:
            Pattern name with best metric
        """
        comparison = self.processor.compare_patterns(metric=metric)
        if comparison.empty:
            return None
        
        best_idx = comparison['value'].idxmax()
        return comparison.loc[best_idx, 'pattern']
    
    def get_pattern_ranking(self, metric: str = 'area') -> pd.DataFrame:
        """
        Get patterns ranked by metric.
        
        Args:
            metric: Metric to rank by
            
        Returns:
            DataFrame with ranked patterns
        """
        comparison = self.processor.compare_patterns(metric=metric)
        return comparison.sort_values('value', ascending=False)
