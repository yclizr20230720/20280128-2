"""
Professional Bossung Curve Plotter
Generates publication-quality visualizations of focus-exposure data
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib import rcParams
import seaborn as sns
from typing import Dict, Optional, Tuple, List
import warnings

warnings.filterwarnings('ignore')


class BosungPlotter:
    """
    Create professional Bossung curve visualizations.
    
    Bossung curves show the relationship between Critical Dimension (CD)
    and Focus (F) at constant Exposure (E) levels.
    """
    
    def __init__(self, style: str = 'seaborn-v0_8-darkgrid', dpi: int = 300):
        """
        Initialize the plotter.
        
        Args:
            style: Matplotlib style ('seaborn-v0_8-darkgrid', 'default', etc.)
            dpi: Resolution for output (300 for publication quality)
        """
        self.style = style
        self.dpi = dpi
        self.figure = None
        self.axes = None
        
        # Set professional styling
        self._setup_style()
    
    def _setup_style(self):
        """Configure matplotlib for professional output."""
        try:
            plt.style.use(self.style)
        except:
            plt.style.use('default')
        
        # Professional font settings
        rcParams['font.family'] = 'sans-serif'
        rcParams['font.sans-serif'] = ['Arial', 'Helvetica', 'DejaVu Sans']
        rcParams['font.size'] = 10
        rcParams['axes.labelsize'] = 11
        rcParams['axes.titlesize'] = 13
        rcParams['xtick.labelsize'] = 9
        rcParams['ytick.labelsize'] = 9
        rcParams['legend.fontsize'] = 9
        rcParams['figure.titlesize'] = 14
        
        # Line and marker settings
        rcParams['lines.linewidth'] = 2.0
        rcParams['lines.markersize'] = 6
        rcParams['patch.linewidth'] = 1.5
        
        # Grid settings
        rcParams['axes.grid'] = True
        rcParams['grid.alpha'] = 0.3
        rcParams['grid.linestyle'] = '--'
        rcParams['grid.linewidth'] = 0.5
    
    def plot_bossung_curves(self,
                           df: pd.DataFrame,
                           exposure_levels: Optional[List[float]] = None,
                           target_cd: float = 250.0,
                           cd_tolerance: float = 0.10,
                           figsize: Tuple[float, float] = (12, 8),
                           show_spec_limits: bool = True,
                           show_data_points: bool = True,
                           colormap: str = 'viridis') -> Tuple[plt.Figure, plt.Axes]:
        """
        Plot Bossung curves with data points and specification limits.
        
        Args:
            df: DataFrame with columns: exposure_dose, focus, critical_dimension, measurement_uncertainty
            exposure_levels: List of exposure levels to plot (if None, use all unique values)
            target_cd: Target critical dimension in nm
            cd_tolerance: CD tolerance as fraction (e.g., 0.10 for ±10%)
            figsize: Figure size (width, height) in inches
            show_spec_limits: Whether to show specification limit bands
            show_data_points: Whether to show individual data points
            colormap: Matplotlib colormap name
            
        Returns:
            Tuple of (figure, axes)
        """
        
        # Create figure
        self.figure, self.axes = plt.subplots(figsize=figsize, dpi=self.dpi)
        
        # Determine exposure levels
        if exposure_levels is None:
            exposure_levels = sorted(df['exposure_dose'].unique())
        
        # Color map
        colors = plt.cm.get_cmap(colormap)(np.linspace(0, 1, len(exposure_levels)))
        
        # Calculate specification limits
        cd_min = target_cd * (1 - cd_tolerance)
        cd_max = target_cd * (1 + cd_tolerance)
        
        # Plot data points and curves for each exposure level
        for idx, exposure in enumerate(exposure_levels):
            # Filter data for this exposure
            mask = df['exposure_dose'] == exposure
            data_exp = df[mask]
            
            # Sort by focus for plotting
            data_exp = data_exp.sort_values('focus')
            
            # Plot data points
            if show_data_points:
                self.axes.scatter(data_exp['focus'], data_exp['critical_dimension'],
                                 color=colors[idx], s=50, alpha=0.6, 
                                 label=f'E = {exposure:.0f} mJ/cm²',
                                 edgecolors='black', linewidth=0.5, zorder=3)
            
            # Plot fitted curve (smooth interpolation)
            focus_smooth = np.linspace(data_exp['focus'].min(), data_exp['focus'].max(), 100)
            # Use polynomial interpolation
            z = np.polyfit(data_exp['focus'], data_exp['critical_dimension'], 3)
            p = np.poly1d(z)
            cd_smooth = p(focus_smooth)
            
            self.axes.plot(focus_smooth, cd_smooth, color=colors[idx], 
                          linewidth=2.5, alpha=0.8, zorder=2)
        
        # Add specification limit bands
        if show_spec_limits:
            self.axes.axhline(cd_max, color='red', linestyle='--', linewidth=2, 
                             alpha=0.7, label=f'Spec Limit (±{cd_tolerance*100:.0f}%)')
            self.axes.axhline(cd_min, color='red', linestyle='--', linewidth=2, alpha=0.7)
            self.axes.axhline(target_cd, color='green', linestyle=':', linewidth=1.5, 
                             alpha=0.7, label=f'Target CD = {target_cd:.0f} nm')
            
            # Shade the specification window
            self.axes.fill_between(self.axes.get_xlim(), cd_min, cd_max, 
                                  color='green', alpha=0.1, zorder=1)
        
        # Labels and title
        self.axes.set_xlabel('Focus (μm)', fontweight='bold')
        self.axes.set_ylabel('Critical Dimension (nm)', fontweight='bold')
        self.axes.set_title('Bossung Curves: CD vs Focus at Various Exposure Levels', 
                           fontweight='bold', fontsize=14, pad=20)
        
        # Legend
        self.axes.legend(loc='best', framealpha=0.95, edgecolor='black', 
                        fancybox=True, shadow=True)
        
        # Grid
        self.axes.grid(True, alpha=0.3, linestyle='--')
        
        # Tight layout
        plt.tight_layout()
        
        return self.figure, self.axes
    
    def plot_process_window_contour(self,
                                   exposures: np.ndarray,
                                   focuses: np.ndarray,
                                   cd_grid: np.ndarray,
                                   target_cd: float = 250.0,
                                   cd_tolerance: float = 0.10,
                                   figsize: Tuple[float, float] = (10, 8),
                                   levels: int = 20) -> Tuple[plt.Figure, plt.Axes]:
        """
        Plot process window as a 2D contour plot.
        
        Args:
            exposures: Exposure dose values (1D array)
            focuses: Focus values (1D array)
            cd_grid: 2D grid of CD values
            target_cd: Target critical dimension
            cd_tolerance: CD tolerance as fraction
            figsize: Figure size
            levels: Number of contour levels
            
        Returns:
            Tuple of (figure, axes)
        """
        
        self.figure, self.axes = plt.subplots(figsize=figsize, dpi=self.dpi)
        
        # Create meshgrid
        E_grid, F_grid = np.meshgrid(exposures, focuses)
        
        # Calculate specification limits
        cd_min = target_cd * (1 - cd_tolerance)
        cd_max = target_cd * (1 + cd_tolerance)
        
        # Plot contours
        contour = self.axes.contourf(E_grid, F_grid, cd_grid, levels=levels, 
                                     cmap='RdYlGn_r', alpha=0.8)
        contour_lines = self.axes.contour(E_grid, F_grid, cd_grid, levels=levels, 
                                         colors='black', alpha=0.3, linewidths=0.5)
        
        # Add contour labels
        self.axes.clabel(contour_lines, inline=True, fontsize=8, fmt='%.0f')
        
        # Add specification boundary contours
        contour_min = self.axes.contour(E_grid, F_grid, cd_grid, levels=[cd_min], 
                                       colors='blue', linewidths=2.5, linestyles='--')
        contour_max = self.axes.contour(E_grid, F_grid, cd_grid, levels=[cd_max], 
                                       colors='red', linewidths=2.5, linestyles='--')
        contour_target = self.axes.contour(E_grid, F_grid, cd_grid, levels=[target_cd], 
                                          colors='green', linewidths=2.0, linestyles=':')
        
        # Colorbar
        cbar = plt.colorbar(contour, ax=self.axes, label='Critical Dimension (nm)')
        cbar.ax.tick_params(labelsize=9)
        
        # Labels and title
        self.axes.set_xlabel('Exposure Dose (mJ/cm²)', fontweight='bold')
        self.axes.set_ylabel('Focus (μm)', fontweight='bold')
        self.axes.set_title('Process Window: CD Contour Map', fontweight='bold', 
                           fontsize=14, pad=20)
        
        # Add legend
        from matplotlib.lines import Line2D
        legend_elements = [
            Line2D([0], [0], color='green', linewidth=2, linestyle=':', label=f'Target CD = {target_cd:.0f} nm'),
            Line2D([0], [0], color='blue', linewidth=2, linestyle='--', label=f'Lower Spec = {cd_min:.0f} nm'),
            Line2D([0], [0], color='red', linewidth=2, linestyle='--', label=f'Upper Spec = {cd_max:.0f} nm'),
        ]
        self.axes.legend(handles=legend_elements, loc='best', framealpha=0.95)
        
        # Grid
        self.axes.grid(True, alpha=0.3, linestyle='--')
        
        plt.tight_layout()
        
        return self.figure, self.axes
    
    def plot_residuals(self,
                      df: pd.DataFrame,
                      predicted_cd: np.ndarray,
                      figsize: Tuple[float, float] = (14, 5)) -> Tuple[plt.Figure, np.ndarray]:
        """
        Plot residuals analysis (actual vs predicted, residuals vs focus).
        
        Args:
            df: Original data
            predicted_cd: Predicted CD values
            figsize: Figure size
            
        Returns:
            Tuple of (figure, axes array)
        """
        
        self.figure, axes = plt.subplots(1, 2, figsize=figsize, dpi=self.dpi)
        
        actual_cd = df['critical_dimension'].values
        residuals = actual_cd - predicted_cd
        focus = df['focus'].values
        
        # Plot 1: Actual vs Predicted
        axes[0].scatter(actual_cd, predicted_cd, alpha=0.6, s=40, edgecolors='black', linewidth=0.5)
        min_val = min(actual_cd.min(), predicted_cd.min())
        max_val = max(actual_cd.max(), predicted_cd.max())
        axes[0].plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2, label='Perfect Fit')
        axes[0].set_xlabel('Actual CD (nm)', fontweight='bold')
        axes[0].set_ylabel('Predicted CD (nm)', fontweight='bold')
        axes[0].set_title('Actual vs Predicted CD', fontweight='bold')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # Plot 2: Residuals vs Focus
        axes[1].scatter(focus, residuals, alpha=0.6, s=40, color='orange', 
                       edgecolors='black', linewidth=0.5)
        axes[1].axhline(0, color='red', linestyle='--', linewidth=2)
        axes[1].axhline(np.std(residuals), color='gray', linestyle=':', linewidth=1.5, alpha=0.7)
        axes[1].axhline(-np.std(residuals), color='gray', linestyle=':', linewidth=1.5, alpha=0.7)
        axes[1].set_xlabel('Focus (μm)', fontweight='bold')
        axes[1].set_ylabel('Residuals (nm)', fontweight='bold')
        axes[1].set_title(f'Residuals vs Focus (σ = {np.std(residuals):.2f} nm)', fontweight='bold')
        axes[1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        return self.figure, axes
    
    def save_figure(self, filename: str, dpi: Optional[int] = None):
        """
        Save current figure to file.
        
        Args:
            filename: Output filename (supports .png, .pdf, .jpg, etc.)
            dpi: DPI for output (if None, use default)
        """
        if self.figure is None:
            raise ValueError("No figure to save. Create a plot first.")
        
        save_dpi = dpi or self.dpi
        self.figure.savefig(filename, dpi=save_dpi, bbox_inches='tight', 
                           facecolor='white', edgecolor='none')
        print(f"✓ Figure saved to {filename}")
    
    def show(self):
        """Display the current figure."""
        if self.figure is None:
            raise ValueError("No figure to show.")
        plt.show()


def main():
    """Test Bossung plotter with mock data."""
    
    print("="*70)
    print("Bossung Curve Visualization")
    print("="*70)
    
    # Load mock data
    print("\n[1] Loading mock data...")
    df = pd.read_csv('/home/ubuntu/bossung_app/mock_data.csv')
    print(f"  Loaded {len(df)} data points")
    
    # Create plotter
    print("\n[2] Creating plotter...")
    plotter = BosungPlotter(style='seaborn-v0_8-darkgrid', dpi=150)
    
    # Plot Bossung curves
    print("\n[3] Plotting Bossung curves...")
    fig, ax = plotter.plot_bossung_curves(
        df,
        target_cd=250.0,
        cd_tolerance=0.10,
        figsize=(12, 8),
        show_spec_limits=True,
        show_data_points=True,
        colormap='viridis'
    )
    plotter.save_figure('/home/ubuntu/bossung_app/bossung_curves.png')
    
    # Generate process window data
    print("\n[4] Generating process window...")
    from data_generator import BosungMockDataGenerator
    generator = BosungMockDataGenerator()
    exp_grid, foc_grid, cd_grid = generator.generate_process_window(grid_points=40)
    
    # Plot process window
    print("\n[5] Plotting process window contour...")
    fig2, ax2 = plotter.plot_process_window_contour(
        exp_grid, foc_grid, cd_grid,
        target_cd=250.0,
        cd_tolerance=0.10,
        figsize=(10, 8),
        levels=25
    )
    plotter.save_figure('/home/ubuntu/bossung_app/process_window.png')
    
    print("\n" + "="*70)
    print("Visualization completed successfully!")
    print("="*70)


if __name__ == "__main__":
    main()
