# Bossung Curve Analysis - Quick Start Guide

## 30-Second Setup

```bash
# Navigate to application directory
cd /home/ubuntu/bossung_app

# Run with default mock data
python3.11 bossung_app.py

# Check results
ls -la output/
```

**Done!** Your analysis is complete. Check the `output/` directory for:
- `bossung_curves.png` - Professional Bossung curve plot
- `process_window.png` - Process window contour map
- `process_window_report.txt` - Analysis metrics
- `mock_data.csv` - Input data

## 5-Minute Tutorial

### Step 1: Prepare Your Data
Create a CSV file with your lithography data:

```csv
exposure_dose,focus,critical_dimension,measurement_uncertainty
160.0,-1.5,337.83,8.45
160.0,-1.36,309.39,7.73
...
320.0,0.5,357.97,8.95
```

### Step 2: Run Analysis
```bash
python3.11 bossung_app.py --input my_data.csv --output ./my_results
```

### Step 3: Review Results
```bash
# View the generated plots
open my_results/bossung_curves.png
open my_results/process_window.png

# Read the analysis report
cat my_results/process_window_report.txt
```

## Common Commands

### Generate Mock Data
```bash
python3.11 bossung_app.py
```

### Analyze Your Data
```bash
python3.11 bossung_app.py --input my_data.csv
```

### Custom Target CD
```bash
python3.11 bossung_app.py --target-cd 300 --tolerance 0.15
```

### High-Resolution Analysis
```bash
python3.11 bossung_app.py --grid-points 100
```

### Specify Output Directory
```bash
python3.11 bossung_app.py --output ./results_2026
```

## Python API Quick Start

### Basic Usage
```python
from bossung_app import BosungAnalysisApp

# Create app
app = BosungAnalysisApp(output_dir='./results')

# Generate and analyze
app.generate_mock_data()
app.fit_polynomial_model()
app.plot_bossung_curves()
app.plot_process_window()
app.analyze_process_window()
```

### Load Your Data
```python
from bossung_app import BosungAnalysisApp

app = BosungAnalysisApp(output_dir='./my_results')
app.load_data('my_data.csv')
app.fit_polynomial_model()
app.plot_bossung_curves(target_cd=250, cd_tolerance=0.10)
```

### Get Analysis Results
```python
from bossung_app import BosungAnalysisApp

app = BosungAnalysisApp()
app.load_data('my_data.csv')
app.fit_polynomial_model()
analysis = app.analyze_process_window()

# Access results
print(analysis['report'])
print(f"Optimal E: {analysis['optimal']['exposure']:.1f} mJ/cm²")
print(f"Optimal F: {analysis['optimal']['focus']:.3f} μm")
```

## Output Files Explained

| File | What It Shows |
|------|---------------|
| `bossung_curves.png` | CD vs Focus at different exposures |
| `process_window.png` | 2D map of process window |
| `process_window_report.txt` | DOF, EL, and optimal settings |
| `mock_data.csv` | Input data used |

## Understanding the Results

### Bossung Curves Plot
- **X-axis**: Focus position (μm)
- **Y-axis**: Critical dimension (nm)
- **Green shaded area**: Specification window
- **Multiple curves**: Different exposure levels

**Good sign**: Curves stay within green area

### Process Window Contour
- **Green region**: In-specification area
- **Blue/Red contours**: Specification limits
- **Larger green area**: Better process robustness

### Analysis Report
```
DOF: 0.1190 μm          → Focus tolerance
EL: 70.00 mJ/cm²        → Exposure tolerance
Optimal Point: E=200, F=-0.5
```

## Troubleshooting

### Issue: "No module named 'scipy'"
```bash
sudo pip3 install scipy scikit-learn
```

### Issue: Permission denied
```bash
chmod +x bossung_app.py
```

### Issue: No output files
- Check output directory exists: `ls -la output/`
- Check disk space: `df -h`
- Verify input data format

### Issue: Low R² value
- Your data has high noise
- Try: `python3.11 bossung_app.py --input my_data.csv`
- Check data quality

## Next Steps

1. **Read full documentation**: See `README.md`
2. **Learn advanced usage**: See `USAGE_GUIDE.md`
3. **API reference**: See `API_REFERENCE.md`
4. **Customize parameters**: Edit `bossung_app.py`

## File Structure

```
bossung_app/
├── bossung_app.py              # Main application
├── data_generator.py           # Mock data generation
├── polynomial_fitter.py        # Model fitting
├── bossung_plotter.py          # Visualization
├── process_window_analyzer.py  # Analysis
├── mock_data.csv              # Sample data
├── README.md                  # Full documentation
├── USAGE_GUIDE.md            # Detailed examples
├── API_REFERENCE.md          # API documentation
└── QUICKSTART.md             # This file
```

## Example Workflow

```bash
# 1. Generate analysis with mock data
python3.11 bossung_app.py --output ./demo

# 2. View results
ls -la demo/

# 3. Load your own data
python3.11 bossung_app.py --input my_data.csv --output ./analysis

# 4. Custom parameters
python3.11 bossung_app.py \
  --input my_data.csv \
  --target-cd 300 \
  --tolerance 0.15 \
  --output ./custom_analysis
```

## Getting Help

### Command-line help
```bash
python3.11 bossung_app.py --help
```

### Check dependencies
```bash
python3.11 -c "import numpy, pandas, matplotlib, scipy; print('✓ OK')"
```

### Verify installation
```bash
python3.11 data_generator.py
python3.11 polynomial_fitter.py
python3.11 bossung_plotter.py
python3.11 process_window_analyzer.py
```

## Performance

- **Mock data generation**: ~0.1 seconds
- **Polynomial fitting**: ~0.5 seconds
- **Visualization**: ~1 second
- **Analysis**: ~1 second
- **Total**: ~2-3 seconds

## Tips

✓ Use `--grid-points 50` for fast analysis  
✓ Use `--grid-points 100` for detailed analysis  
✓ Export plots at 300 DPI for publications  
✓ Check R² value (should be >0.7)  
✓ Review residuals for fitting quality  

## Support

For detailed information:
- **General usage**: See `README.md`
- **Advanced examples**: See `USAGE_GUIDE.md`
- **API details**: See `API_REFERENCE.md`
- **Paper reference**: Mack & Byers, 2003

---

**Ready to start?** Run: `python3.11 bossung_app.py`

**Questions?** Check the documentation files or review the code comments.

**Version**: 1.0 | **Updated**: January 2026
