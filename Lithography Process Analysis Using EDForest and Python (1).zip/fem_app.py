#!/usr/bin/env python3.11
"""
Focus-Exposure Matrix (FEM) Analysis Application
Integrated tool for lithography process window analysis with multi-pattern support
"""

import argparse
import sys
import os
from pathlib import Path
import pandas as pd
import numpy as np
from typing import Optional, Dict, List

from fem_processor import FEMProcessor, PatternInfo, MultiPatternAnalyzer
from fem_visualizer import FEMVisualizer
from fem_data_generator import FEMDataGenerator, FEMDataValidator


class FEMAnalysisApp:
    """
    Main application for FEM analysis.
    
    Provides integrated workflow for loading, analyzing, and visualizing
    focus-exposure matrix data with support for multiple patterns.
    """
    
    def __init__(self, output_dir: str = './fem_output'):
        """
        Initialize application.
        
        Args:
            output_dir: Directory for output files
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        self.processor = FEMProcessor()
        self.visualizer = FEMVisualizer(dpi=300)
        self.analyzer = None
    
    def generate_mock_data(self,
                          pattern_type: str = 'standard',
                          exposure_range: tuple = (160.0, 320.0),
                          exposure_points: int = 9,
                          focus_range: tuple = (-1.5, 0.5),
                          focus_points: int = 15,
                          noise_level: float = 0.03) -> Dict:
        """
        Generate mock FEM data for testing.
        
        Args:
            pattern_type: 'standard' for predefined patterns or 'custom'
            exposure_range: Exposure range
            exposure_points: Number of exposure points
            focus_range: Focus range
            focus_points: Number of focus points
            noise_level: Measurement noise level
            
        Returns:
            Dictionary with generated matrices
        """
        print("\n[1] Generating mock FEM data...")
        
        generator = FEMDataGenerator(seed=42)
        
        if pattern_type == 'standard':
            matrices = generator.generate_standard_patterns(
                exposure_range=exposure_range,
                exposure_points=exposure_points,
                focus_range=focus_range,
                focus_points=focus_points,
                noise_level=noise_level
            )
        else:
            # Generate single custom pattern
            matrices = {
                'custom_pattern': generator.generate_pattern_matrix(
                    pattern_name='custom_pattern',
                    pattern_type='dense',
                    target_cd=250.0,
                    exposure_range=exposure_range,
                    exposure_points=exposure_points,
                    focus_range=focus_range,
                    focus_points=focus_points,
                    noise_level=noise_level
                )
            }
        
        # Load into processor
        for pattern_name, fem_matrix in matrices.items():
            self.processor.matrices[pattern_name] = fem_matrix
            if fem_matrix.pattern_info:
                self.processor.patterns[pattern_name] = fem_matrix.pattern_info
        
        print(f"  ✓ Generated {len(matrices)} patterns")
        for pattern_name in matrices.keys():
            print(f"    - {pattern_name}")
        
        # Export to CSV
        generator.export_matrices_to_csv(matrices, str(self.output_dir / 'fem_data'))
        
        return matrices
    
    def load_data_from_csv(self, csv_file: str, pattern_name: str = 'default') -> None:
        """
        Load FEM data from CSV file.
        
        Args:
            csv_file: Path to CSV file
            pattern_name: Name for this pattern
        """
        print(f"\n[1] Loading FEM data from {csv_file}...")
        
        df = pd.read_csv(csv_file)
        self.processor.load_matrix_from_dataframe(df, pattern_name)
        
        print(f"  ✓ Loaded pattern: {pattern_name}")
        print(f"  Data points: {len(df)}")
    
    def analyze_pattern(self,
                       pattern_name: str = 'default',
                       target_cd: float = 250.0,
                       cd_tolerance: float = 0.10) -> Dict:
        """
        Analyze single pattern.
        
        Args:
            pattern_name: Pattern name
            target_cd: Target CD
            cd_tolerance: CD tolerance
            
        Returns:
            Analysis results dictionary
        """
        print(f"\n[2] Analyzing pattern: {pattern_name}...")
        
        # Extract process window
        pw = self.processor.extract_process_window(pattern_name, target_cd, cd_tolerance)
        print(f"  ✓ Process window extracted")
        if pw['found']:
            exp_min, exp_max = pw['exposure_range']
            foc_min, foc_max = pw['focus_range']
            print(f"    Exposure: {exp_min:.1f} - {exp_max:.1f} mJ/cm²")
            print(f"    Focus: {foc_min:.3f} - {foc_max:.3f} μm")
            print(f"    Area: {pw['area']:.2f} (mJ/cm² × μm)")
        
        # Calculate DOF/EL
        dof_el = self.processor.calculate_dof_el(pattern_name, target_cd, cd_tolerance)
        print(f"  ✓ DOF/EL calculated")
        print(f"    Average DOF: {dof_el['avg_dof']:.4f} μm")
        print(f"    Average EL: {dof_el['avg_el']:.2f} mJ/cm²")
        
        # Find optimal point
        optimal = self.processor.get_optimal_point(pattern_name, target_cd, cd_tolerance)
        print(f"  ✓ Optimal point found")
        if optimal['found']:
            print(f"    E: {optimal['exposure']:.1f} mJ/cm²")
            print(f"    F: {optimal['focus']:.3f} μm")
            print(f"    CD: {optimal['cd']:.2f} nm")
        
        return {
            'process_window': pw,
            'dof_el': dof_el,
            'optimal': optimal
        }
    
    def visualize_pattern(self,
                         pattern_name: str = 'default',
                         target_cd: float = 250.0,
                         cd_tolerance: float = 0.10,
                         plot_types: Optional[List[str]] = None) -> Dict[str, str]:
        """
        Generate visualizations for pattern.
        
        Args:
            pattern_name: Pattern name
            target_cd: Target CD
            cd_tolerance: CD tolerance
            plot_types: List of plot types to generate
                       ('contour', 'heatmap', 'process_window', 'gradient', 'dof_el')
            
        Returns:
            Dictionary of plot_type -> output_path
        """
        if plot_types is None:
            plot_types = ['contour', 'process_window', 'dof_el']
        
        print(f"\n[3] Generating visualizations for {pattern_name}...")
        
        fem_matrix = self.processor.get_matrix(pattern_name)
        if fem_matrix is None:
            raise ValueError(f"Pattern '{pattern_name}' not found")
        
        output_paths = {}
        
        # Contour plot
        if 'contour' in plot_types:
            fig, ax = self.visualizer.plot_fem_contour(
                fem_matrix,
                target_cd=target_cd,
                cd_tolerance=cd_tolerance,
                levels=20
            )
            output_path = self.output_dir / f'{pattern_name}_contour.png'
            self.visualizer.save_figure(str(output_path))
            output_paths['contour'] = str(output_path)
            self.visualizer.close()
        
        # Heatmap
        if 'heatmap' in plot_types:
            fig, ax = self.visualizer.plot_fem_heatmap(fem_matrix, annot=False)
            output_path = self.output_dir / f'{pattern_name}_heatmap.png'
            self.visualizer.save_figure(str(output_path))
            output_paths['heatmap'] = str(output_path)
            self.visualizer.close()
        
        # Process window overlay
        if 'process_window' in plot_types:
            fig, ax = self.visualizer.plot_process_window_overlay(
                fem_matrix,
                target_cd=target_cd,
                cd_tolerance=cd_tolerance
            )
            output_path = self.output_dir / f'{pattern_name}_process_window.png'
            self.visualizer.save_figure(str(output_path))
            output_paths['process_window'] = str(output_path)
            self.visualizer.close()
        
        # Gradient field
        if 'gradient' in plot_types:
            fig, ax = self.visualizer.plot_gradient_field(fem_matrix)
            output_path = self.output_dir / f'{pattern_name}_gradient.png'
            self.visualizer.save_figure(str(output_path))
            output_paths['gradient'] = str(output_path)
            self.visualizer.close()
        
        # DOF/EL analysis
        if 'dof_el' in plot_types:
            fig, axes = self.visualizer.plot_dof_el_analysis(
                self.processor,
                pattern_name=pattern_name,
                target_cd=target_cd,
                cd_tolerance=cd_tolerance
            )
            output_path = self.output_dir / f'{pattern_name}_dof_el.png'
            self.visualizer.save_figure(str(output_path))
            output_paths['dof_el'] = str(output_path)
            self.visualizer.close()
        
        print(f"  ✓ Generated {len(output_paths)} visualizations")
        
        return output_paths
    
    def compare_patterns(self,
                        target_cd: float = 250.0,
                        cd_tolerance: float = 0.10) -> str:
        """
        Compare all loaded patterns.
        
        Args:
            target_cd: Target CD
            cd_tolerance: CD tolerance
            
        Returns:
            Path to comparison report
        """
        print("\n[4] Comparing patterns...")
        
        self.analyzer = MultiPatternAnalyzer(self.processor)
        report = self.analyzer.generate_comparison_report(target_cd, cd_tolerance)
        
        # Save report
        report_path = self.output_dir / 'multi_pattern_report.txt'
        with open(report_path, 'w') as f:
            f.write(report)
        
        print(f"  ✓ Report saved to {report_path}")
        
        # Generate comparison visualization
        if len(self.processor.list_patterns()) > 1:
            fig, axes = self.visualizer.plot_multi_pattern_comparison(
                self.processor,
                target_cd=target_cd,
                cd_tolerance=cd_tolerance
            )
            viz_path = self.output_dir / 'multi_pattern_comparison.png'
            self.visualizer.save_figure(str(viz_path))
            self.visualizer.close()
            print(f"  ✓ Comparison visualization saved to {viz_path}")
        
        return str(report_path)
    
    def run_full_analysis(self,
                         input_file: Optional[str] = None,
                         pattern_type: str = 'standard',
                         target_cd: float = 250.0,
                         cd_tolerance: float = 0.10):
        """
        Run complete FEM analysis pipeline.
        
        Args:
            input_file: Path to input CSV (if None, generate mock data)
            pattern_type: Type of pattern data
            target_cd: Target CD
            cd_tolerance: CD tolerance
        """
        print("\n" + "=" * 70)
        print("FOCUS-EXPOSURE MATRIX (FEM) ANALYSIS APPLICATION")
        print("=" * 70)
        
        # Load or generate data
        if input_file:
            self.load_data_from_csv(input_file)
        else:
            self.generate_mock_data(pattern_type=pattern_type)
        
        # Analyze each pattern
        patterns = self.processor.list_patterns()
        analysis_results = {}
        
        for pattern_name in patterns:
            results = self.analyze_pattern(pattern_name, target_cd, cd_tolerance)
            analysis_results[pattern_name] = results
            
            # Generate visualizations
            self.visualize_pattern(
                pattern_name,
                target_cd=target_cd,
                cd_tolerance=cd_tolerance,
                plot_types=['contour', 'process_window', 'dof_el']
            )
        
        # Compare patterns if multiple
        if len(patterns) > 1:
            self.compare_patterns(target_cd, cd_tolerance)
        
        print("\n" + "=" * 70)
        print("ANALYSIS COMPLETED SUCCESSFULLY")
        print("=" * 70)
        print(f"\nOutput directory: {self.output_dir.absolute()}")
        print(f"Patterns analyzed: {len(patterns)}")
        print(f"  {', '.join(patterns)}")
        
        # List output files
        output_files = list(self.output_dir.glob('*'))
        print(f"\nGenerated {len(output_files)} files:")
        for f in sorted(output_files):
            if f.is_file():
                size = f.stat().st_size
                if size > 1024*1024:
                    size_str = f"{size/(1024*1024):.1f} MB"
                elif size > 1024:
                    size_str = f"{size/1024:.1f} KB"
                else:
                    size_str = f"{size} B"
                print(f"  - {f.name} ({size_str})")


def main():
    """Command-line interface."""
    
    parser = argparse.ArgumentParser(
        description='Focus-Exposure Matrix (FEM) Analysis Tool',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Generate and analyze standard patterns
  python fem_app.py
  
  # Load custom data
  python fem_app.py --input my_fem_data.csv
  
  # Specify output directory
  python fem_app.py --output ./fem_results
  
  # Custom parameters
  python fem_app.py --target-cd 300 --tolerance 0.15
        """
    )
    
    parser.add_argument('--input', '-i', type=str, default=None,
                       help='Input CSV file with FEM data')
    parser.add_argument('--output', '-o', type=str, default='./fem_output',
                       help='Output directory for results')
    parser.add_argument('--pattern-type', type=str, default='standard',
                       choices=['standard', 'custom'],
                       help='Type of pattern data to generate')
    parser.add_argument('--target-cd', type=float, default=250.0,
                       help='Target critical dimension in nm')
    parser.add_argument('--tolerance', type=float, default=0.10,
                       help='CD tolerance as fraction')
    
    args = parser.parse_args()
    
    # Create and run application
    app = FEMAnalysisApp(output_dir=args.output)
    
    try:
        app.run_full_analysis(
            input_file=args.input,
            pattern_type=args.pattern_type,
            target_cd=args.target_cd,
            cd_tolerance=args.tolerance
        )
    except Exception as e:
        print(f"\n✗ Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
