# 🚀 Quick Start Guide - EDForest Analysis Platform

## Launch in 30 Seconds!

---

## Step 1: Launch the Platform

### **Windows (Easiest):**
Double-click:
```
LAUNCH.bat
```

This automatically starts:
- ✅ Backend server (Python Flask) on port 5000
- ✅ Frontend server (React + Vite) on port 5174
- ✅ Opens browser to http://localhost:5174

---

## Step 2: Navigate to EDForest

1. You'll see the **VSMC Litho Platform** homepage
2. Click the **"EDForest"** card (first tool)
3. You're now in the Bossung Curve Analysis tool!

---

## Step 3: Upload or Generate Data

### **Option A: Generate Mock Data (Fastest)**
1. Click **"Upload"** tab (should be active)
2. Scroll down to "Generate Mock Data" section
3. Click **"Generate Mock Data"** button
4. Wait 2 seconds - Done! ✅

### **Option B: Upload Your Own Data**
1. Click **"Upload"** tab
2. Click **"Choose a file"** or drag & drop
3. Select your CSV file (format: Dose, Defocus, CD columns)
4. Click **"Upload File"**
5. Done! ✅

---

## Step 4: Run Analysis

1. Click **"Analyze"** tab
2. Set parameters:
   - **Target CD**: 45.0 nm (default)
   - **Tolerance**: 10% (default)
3. Click **"Run Analysis"** button
4. Wait 3-5 seconds for calculation
5. Automatically switches to **"Results"** tab!

---

## Step 5: Explore Results!

### **You'll See 5 Sections:**

#### **Section 1: Main Analysis** 📊
- **Bossung Curves**: CD vs Defocus at multiple doses
- **Process Window**: Heatmap showing optimal region
- **CD Distribution**: Histogram with spec limits

#### **Section 2: Advanced Analysis** 🔬
- **Dose Sensitivity**: How CD changes with dose
- **Best Focus vs Dose**: Optimal focus for each dose
- **CD at Best Focus**: Ideal CD achievable

#### **Section 3: Model Quality** ✅
- **Curvature Analysis**: Focus sensitivity quantification
- **R² Fit Quality**: Model reliability check

#### **Section 4: Process Metrics** 📈
- DOF, EL, Optimal Dose, Yield, etc.
- CD Statistics (Mean, Std Dev, Min, Max)

#### **Section 5: Download** 💾
- High-resolution PNG/PDF plots
- For reports and presentations

---

## Step 6: Learn from the Charts!

### **Every Chart Has:**

1. **Info Icon (ℹ️)** - Hover to see explanation
2. **Engineering Insight** - Colored banner with guidance
3. **Key Takeaways** - Three boxes:
   - ✓ Good Process (Green)
   - ⚠ Watch Out (Yellow)
   - 💡 Tip (Blue)

### **Interactive Features:**
- **Hover** over data points for details
- **Zoom** by selecting area (some charts)
- **Toggle** legend items to show/hide

---

## 🎯 Quick Example

### **Scenario**: Find optimal exposure dose

1. **Generate mock data** (Step 3)
2. **Run analysis** with Target CD = 45nm (Step 4)
3. **Look at Section 2** → "CD at Best Focus vs Dose"
4. **Find where line crosses target** (red dashed line)
5. **That's your optimal dose!** (usually around 22 mJ/cm²)
6. **Check Section 4** → Confirm "Optimal Dose" metric matches
7. **Done!** You've identified the best process condition! ✅

---

## 📊 Understanding the Results

### **Key Metrics to Check:**

1. **DOF (Depth of Focus)**: 
   - Higher = better focus tolerance
   - Target: > 0.5 μm

2. **EL (Exposure Latitude)**:
   - Higher = better dose tolerance
   - Target: > 5 mJ/cm²

3. **Yield**:
   - Percentage of points in spec
   - Target: > 90%

4. **R² (Model Fit)**:
   - How well model fits data
   - Target: > 0.95

5. **Curvature**:
   - Lower = better focus tolerance
   - Choose dose with minimum curvature

---

## 🎓 Educational Tips

### **For Each Chart, Ask:**

1. **What does this show?** → Read the title
2. **How do I interpret it?** → Hover on info icon (ℹ️)
3. **What should I look for?** → Read "Good Process" box
4. **What are the risks?** → Read "Watch Out" box
5. **What's the best action?** → Read "Tip" box

### **Decision-Making Flow:**

```
1. Check R² → Is model reliable? (> 0.95)
   ↓ Yes
2. Check Yield → Is process capable? (> 90%)
   ↓ Yes
3. Find Optimal Dose → Where CD crosses target
   ↓
4. Check Curvature → Is focus tolerance good? (low value)
   ↓ Yes
5. Verify DOF/EL → Are margins sufficient?
   ↓ Yes
6. ✅ Process is ready for manufacturing!
```

---

## 🔧 Troubleshooting

### **Backend won't start:**
```
cd backend
python run.py
```
Check: Python installed? Dependencies installed? (`pip install -r requirements.txt`)

### **Frontend won't start:**
```
cd frontend
npm install
npm run dev
```
Check: Node.js installed? Dependencies installed?

### **Charts not showing:**
- Did you run analysis? (Step 4)
- Check browser console for errors (F12)
- Refresh page (Ctrl+R)

### **Data upload fails:**
- Check CSV format: Must have columns `Dose`, `Defocus`, `CD`
- Check file size: < 16MB
- Try generating mock data first

---

## 📁 File Locations

### **Your Data:**
- Uploaded files: `backend/uploads/`
- Generated plots: `backend/outputs/`

### **Mock Data:**
- Generated with timestamp: `lithography_data_YYYYMMDD_HHMMSS.csv`

### **Downloaded Plots:**
- Check your browser's download folder
- Format: PNG or PDF (300 DPI)

---

## 🎨 Chart Types Reference

| Chart | Type | Purpose |
|-------|------|---------|
| Bossung Curves | Line | CD vs Defocus |
| Process Window | Heatmap | 2D dose-focus |
| CD Distribution | Histogram | Frequency |
| Dose Sensitivity | Multi-line | CD vs Dose |
| Best Focus | Line | Focus vs Dose |
| CD at Best Focus | Line | Optimal CD |
| Curvature | Line | Sensitivity |
| R² | Line | Fit quality |

---

## ✅ Success Checklist

After running analysis, you should see:

- [ ] 8 interactive charts displayed
- [ ] All charts have data (not "No data available")
- [ ] Info icons (ℹ️) on all charts
- [ ] Engineering insight banners (colored)
- [ ] Key takeaways boxes (3 per chart)
- [ ] Process metrics cards (10 total)
- [ ] Download buttons (if plots generated)

If all checked → **You're good to go!** 🎉

---

## 🚀 Advanced Usage

### **Compare Different Conditions:**
1. Run analysis with Target CD = 45nm, Tolerance = 10%
2. Note the optimal dose
3. Run again with Tolerance = 5%
4. Compare DOF/EL values
5. Understand robustness trade-offs

### **Sensitivity Analysis:**
1. Look at "Dose Sensitivity" chart
2. Identify steepest curves (high sensitivity)
3. Look at "Curvature" chart
4. Choose dose with low curvature
5. Balance between target CD and robustness

### **Model Validation:**
1. Check "R² Fit Quality" chart
2. If R² < 0.95 for some doses → data quality issue
3. Investigate those doses
4. May need more data points or better measurement

---

## 📚 Learn More

- **Full Documentation**: See `✅_COMPREHENSIVE_CHARTS_COMPLETE.md`
- **Chart Guide**: See `📊_CHART_IMPLEMENTATION_GUIDE.md`
- **Technical Details**: See `VSMC_LITHO_PLATFORM_README.md`

---

## 🎊 You're Ready!

**Time to analyze**: < 1 minute  
**Time to understand**: 5-10 minutes  
**Time to make decision**: 2-3 minutes  

**Total**: ~15 minutes from launch to decision! 🚀

---

**Happy Analyzing!** 📊✨

---

**Platform**: VSMC Litho Platform  
**Tool**: EDForest - Bossung Curve Analysis  
**Version**: 1.0  
**Date**: January 23, 2026
