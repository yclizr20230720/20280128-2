# VSMC Litho Platform - Complete Setup Guide

## 📋 Table of Contents

1. [System Requirements](#system-requirements)
2. [Backend Setup](#backend-setup)
3. [Frontend Setup](#frontend-setup)
4. [Running the Application](#running-the-application)
5. [Testing](#testing)
6. [Troubleshooting](#troubleshooting)

## 🖥️ System Requirements

### Minimum Requirements
- **OS**: Windows 10/11, macOS 10.15+, or Linux
- **RAM**: 4GB
- **Storage**: 2GB free space
- **Node.js**: 18.0 or higher
- **Python**: 3.8 or higher
- **Browser**: Chrome 90+, Firefox 88+, Safari 14+, Edge 90+

### Recommended Requirements
- **RAM**: 8GB or more
- **Storage**: 5GB free space
- **Node.js**: 20.0 or higher
- **Python**: 3.10 or higher

## 🐍 Backend Setup

### Step 1: Install Python

**Windows:**
1. Download Python from [python.org](https://www.python.org/downloads/)
2. Run installer and check "Add Python to PATH"
3. Verify installation:
   ```cmd
   python --version
   ```

**macOS:**
```bash
brew install python@3.10
```

**Linux:**
```bash
sudo apt update
sudo apt install python3.10 python3-pip python3-venv
```

### Step 2: Create Virtual Environment

```bash
# Navigate to backend directory
cd backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows (CMD):
venv\Scripts\activate

# Windows (PowerShell):
venv\Scripts\Activate.ps1

# macOS/Linux:
source venv/bin/activate
```

### Step 3: Install Dependencies

```bash
# Upgrade pip
python -m pip install --upgrade pip

# Install requirements
pip install -r requirements.txt
```

### Step 4: Verify Installation

```bash
# Check installed packages
pip list

# Should see:
# Flask, Flask-CORS, numpy, pandas, matplotlib, scipy, seaborn, etc.
```

### Step 5: Test Backend

```bash
# Run the backend server
python run.py

# You should see:
# ======================================================================
# VSMC Litho Platform - Backend API
# ======================================================================
# Environment: development
# Port: 5000
# Debug: True
# ======================================================================
#  * Running on http://0.0.0.0:5000
```

Keep this terminal open!

## ⚛️ Frontend Setup

### Step 1: Install Node.js

**Windows:**
1. Download from [nodejs.org](https://nodejs.org/)
2. Run installer
3. Verify installation:
   ```cmd
   node --version
   npm --version
   ```

**macOS:**
```bash
brew install node
```

**Linux:**
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### Step 2: Install Frontend Dependencies

Open a **NEW** terminal (keep backend running):

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# This will install:
# - React, React Router
# - Vite
# - TailwindCSS
# - Axios
# - Recharts
# - Lucide React (icons)
```

### Step 3: Configure Environment

Create `.env` file in `frontend/` directory:

```env
VITE_API_URL=http://localhost:5000/api/v1
```

### Step 4: Test Frontend

```bash
# Start development server
npm run dev

# You should see:
#   VITE v5.0.8  ready in 500 ms
#
#   ➜  Local:   http://localhost:5173/
#   ➜  Network: use --host to expose
```

## 🚀 Running the Application

### Terminal 1: Backend

```bash
cd backend
venv\Scripts\activate  # Windows
# or
source venv/bin/activate  # macOS/Linux

python run.py
```

### Terminal 2: Frontend

```bash
cd frontend
npm run dev
```

### Access the Application

Open your browser and go to:
```
http://localhost:5173
```

You should see the VSMC Litho Platform home page!

## 🧪 Testing

### Test Backend API

```bash
# Test health endpoint
curl http://localhost:5000/api/v1/health

# Expected response:
# {
#   "status": "healthy",
#   "timestamp": "2026-01-23T...",
#   "service": "VSMC Litho Platform API"
# }
```

### Test Frontend

1. Open `http://localhost:5173`
2. Click on "EDForest - Bossung Curve Analysis" card
3. Click "Generate Mock Data"
4. Click "Run Analysis"
5. View results and download plots

### Test File Upload

1. Go to EDForest tool
2. Upload the `lithography_data.csv` file from root directory
3. Set Target CD: 45.0
4. Set Tolerance: 10%
5. Click "Run Analysis"
6. Click "Generate Plots"
7. Download plots

## 🔧 Troubleshooting

### Backend Issues

#### Issue 1: "Module not found" error

**Solution:**
```bash
# Make sure virtual environment is activated
# Reinstall dependencies
pip install -r requirements.txt
```

#### Issue 2: Port 5000 already in use

**Solution (Windows):**
```cmd
# Find process using port 5000
netstat -ano | findstr :5000

# Kill the process
taskkill /PID <PID> /F
```

**Solution (macOS/Linux):**
```bash
# Find and kill process
lsof -ti:5000 | xargs kill -9
```

#### Issue 3: Import error for bossung_plotter

**Solution:**
```bash
# Make sure you're in the correct directory
# The backend should be able to import from parent directory
# Check that bossung_plotter.py exists in the root directory
```

### Frontend Issues

#### Issue 1: npm install fails

**Solution:**
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and package-lock.json
rm -rf node_modules package-lock.json  # macOS/Linux
# or
rmdir /s node_modules  # Windows
del package-lock.json  # Windows

# Reinstall
npm install
```

#### Issue 2: "Cannot connect to backend" error

**Solution:**
1. Check backend is running on port 5000
2. Check `.env` file has correct API URL
3. Check CORS settings in `backend/config.py`
4. Try accessing `http://localhost:5000/api/v1/health` directly

#### Issue 3: Vite port already in use

**Solution:**
```bash
# Use a different port
npm run dev -- --port 3000
```

### Common Issues

#### Issue: "Permission denied" on Linux/macOS

**Solution:**
```bash
# Don't use sudo with npm
# Fix npm permissions:
mkdir ~/.npm-global
npm config set prefix '~/.npm-global'
echo 'export PATH=~/.npm-global/bin:$PATH' >> ~/.profile
source ~/.profile
```

#### Issue: Plots not generating

**Solution:**
1. Check backend logs for errors
2. Verify matplotlib is installed: `pip list | grep matplotlib`
3. Check output folder permissions
4. Try generating mock data first

## 📊 Verification Checklist

- [ ] Python 3.8+ installed
- [ ] Node.js 18+ installed
- [ ] Backend virtual environment created
- [ ] Backend dependencies installed
- [ ] Backend server running on port 5000
- [ ] Frontend dependencies installed
- [ ] Frontend server running on port 5173
- [ ] Can access home page
- [ ] Can navigate to EDForest tool
- [ ] Can generate mock data
- [ ] Can run analysis
- [ ] Can generate plots
- [ ] Can download plots

## 🎯 Next Steps

Once everything is working:

1. **Explore the Platform**
   - Try different analysis parameters
   - Upload your own data
   - Export plots and reports

2. **Customize**
   - Modify color scheme in `tailwind.config.js`
   - Add your company logo
   - Customize analysis parameters

3. **Develop**
   - Add new analysis tools
   - Extend API endpoints
   - Create custom visualizations

## 📚 Additional Resources

- [React Documentation](https://react.dev/)
- [Vite Documentation](https://vitejs.dev/)
- [Flask Documentation](https://flask.palletsprojects.com/)
- [TailwindCSS Documentation](https://tailwindcss.com/)

## 💡 Tips

1. **Development Workflow**
   - Keep both terminals open
   - Backend auto-reloads on code changes (debug mode)
   - Frontend hot-reloads automatically

2. **Performance**
   - Use Chrome DevTools for debugging
   - Check Network tab for API calls
   - Monitor Console for errors

3. **Data Management**
   - Uploaded files are stored in `backend/uploads/`
   - Generated plots are in `backend/outputs/`
   - Files are timestamped automatically

## 🆘 Getting Help

If you encounter issues:

1. Check this troubleshooting guide
2. Review error messages carefully
3. Check browser console (F12)
4. Check backend terminal logs
5. Search for similar issues online
6. Contact support team

---

**Happy Analyzing! 🎉**

*VSMC Litho Platform Team*
