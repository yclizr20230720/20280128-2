# Bossung Curve Plotter for Lithography Process Window Analysis

A professional Python tool for generating Bossung curves and analyzing process windows in semiconductor lithography, inspired by the EDForest methodology for Energy-Dose (ED) curve analysis.

## Overview

This tool enables visualization and analysis of Critical Dimension (CD) variations across dose-focus matrices in photolithography processes. Bossung curves are essential for:

- **Process Window Optimization**: Identifying optimal exposure dose and focus settings
- **Depth of Focus (DOF) Analysis**: Measuring the focus range within specification
- **Exposure Latitude (EL) Evaluation**: Determining acceptable dose variation
- **Manufacturing Margin Assessment**: Quantifying process robustness

## Features

### 1. Bossung Curve Plotting
- Professional multi-dose CD vs. Defocus curves
- Customizable plot styles (professional, colorful, minimal)
- Target CD and tolerance band visualization
- High-quality output suitable for presentations and publications

### 2. Process Window Visualization
- 2D contour plots showing dose-focus-CD relationships
- Color-coded CD distribution across the parameter space
- Target CD contour highlighting
- Process window boundary identification

### 3. Quantitative Analysis
- **Depth of Focus (DOF)**: Maximum defocus range within CD tolerance
- **Exposure Latitude (EL)**: Acceptable dose variation range
- **Optimal Process Point**: Center of the process window
- **Yield Estimation**: Percentage of conditions within specification

### 4. Comprehensive Reporting
- Multi-panel analysis combining all visualizations
- Statistical CD distribution analysis
- Automated report generation in multiple formats (PNG, PDF)

## Installation

### Requirements

```bash
pip install numpy pandas matplotlib scipy seaborn
```

### Python Version
- Python 3.7 or higher

## Usage

### Quick Start

```python
from bossung_plotter import BossungPlotter, generate_mock_data

# Generate mock data
data = generate_mock_data('my_litho_data.csv')

# Create plotter
plotter = BossungPlotter(data_file='my_litho_data.csv')

# Set target specifications
plotter.set_target_specs(target_cd=45.0, tolerance_percent=10)

# Generate plots
plotter.plot_bossung_curves()
plotter.plot_process_window()
plotter.plot_comprehensive_analysis()

# Calculate metrics
metrics = plotter.calculate_process_window_metrics()
print(f"DOF: {metrics['DOF']:.3f} μm")
print(f"EL: {metrics['EL']:.2f} mJ/cm²")
```

### Running the Demo

```bash
python bossung_plotter.py
```

This will:
1. Generate mock lithography data
2. Create Bossung curves
3. Generate process window plots
4. Calculate DOF and EL metrics
5. Save all plots as PNG and PDF files

## Data Format

### Input CSV Structure

The tool expects a CSV file with the following columns:

| Column   | Description                          | Unit      | Example |
|----------|--------------------------------------|-----------|---------|
| Dose     | Exposure dose                        | mJ/cm²    | 22.5    |
| Defocus  | Focus offset from nominal            | μm        | -0.2    |
| CD       | Measured critical dimension          | nm        | 45.3    |
| Wafer_ID | Wafer identifier (optional)          | -         | W001    |
| Field    | Field location (optional)            | -         | Center  |

### Example Data

```csv
Dose,Defocus,CD,Wafer_ID,Field
18.0,-0.4,52.3,W001,Center
18.0,-0.3,49.8,W001,Center
18.0,-0.2,47.5,W001,Center
20.0,-0.4,50.8,W001,Center
20.0,-0.3,48.2,W001,Center
```

## API Reference

### BossungPlotter Class

#### Initialization

```python
plotter = BossungPlotter(data_file='data.csv')
# or
plotter = BossungPlotter(dataframe=df)
```

#### Methods

**set_target_specs(target_cd, tolerance_percent=10)**
- Set target CD and tolerance specifications
- `target_cd`: Target critical dimension in nm
- `tolerance_percent`: Tolerance as percentage of target

**plot_bossung_curves(figsize=(12, 8), style='professional')**
- Generate Bossung curves
- Returns: `(fig, ax)` matplotlib objects
- Styles: 'professional', 'colorful', 'minimal'

**plot_process_window(figsize=(12, 8))**
- Generate 2D process window contour plot
- Returns: `(fig, ax)` matplotlib objects

**plot_comprehensive_analysis(figsize=(18, 10))**
- Generate multi-panel comprehensive analysis
- Returns: `fig` matplotlib figure object

**calculate_process_window_metrics()**
- Calculate DOF, EL, and optimal process point
- Returns: Dictionary with metrics

**save_plots(prefix='bossung', formats=['png', 'pdf'])**
- Save all plots to files
- `prefix`: Filename prefix
- `formats`: List of output formats

### Utility Functions

**generate_mock_data(output_file='lithography_data.csv')**
- Generate realistic mock lithography data
- Returns: pandas DataFrame

## Process Window Metrics

### Depth of Focus (DOF)
The range of defocus values where CD remains within specification:

```
DOF = max(Defocus_in_spec) - min(Defocus_in_spec)
```

### Exposure Latitude (EL)
The range of exposure doses where CD remains within specification:

```
EL = max(Dose_in_spec) - min(Dose_in_spec)
```

### Optimal Process Point
The center of the process window, providing maximum margin:

```
Optimal_Dose = (max(Dose_in_spec) + min(Dose_in_spec)) / 2
Optimal_Focus = (max(Defocus_in_spec) + min(Defocus_in_spec)) / 2
```

## Theoretical Background

### Bossung Curves

Bossung curves characterize the relationship between CD and defocus at various exposure doses. The typical behavior shows:

1. **Parabolic Shape**: CD increases with defocus magnitude (both positive and negative)
2. **Dose Sensitivity**: Higher doses generally produce smaller CDs
3. **Asymmetry**: Real lithography systems often show asymmetric behavior
4. **Best Focus**: The defocus value producing the target CD

### EDForest Methodology

This tool is inspired by the EDForest approach (Li et al., 2019), which uses Random Forest machine learning to:

- Predict CD across the dose-focus plane
- Generate ED-trees and ED-curves efficiently
- Handle high-dimensional parameter spaces
- Maintain accuracy at process window edges

### Process Window Definition

The process window is the region in dose-focus space where:

```
|CD - Target_CD| ≤ Tolerance
```

A larger process window indicates:
- More robust manufacturing process
- Higher yield potential
- Greater tolerance to process variations

## Output Files

Running the tool generates:

1. **bossung_curves.png/pdf**: Bossung curves with all dose conditions
2. **bossung_process_window.png/pdf**: 2D contour plot of the process window
3. **bossung_comprehensive.png/pdf**: Multi-panel comprehensive analysis
4. **lithography_data.csv**: Mock data file (if generated)

## Customization

### Custom Plot Styles

```python
# Professional style (default)
plotter.plot_bossung_curves(style='professional')

# Colorful style
plotter.plot_bossung_curves(style='colorful')

# Minimal style
plotter.plot_bossung_curves(style='minimal')
```

### Custom Figure Sizes

```python
# Larger figure
plotter.plot_bossung_curves(figsize=(16, 10))

# Presentation format
plotter.plot_comprehensive_analysis(figsize=(20, 12))
```

### Custom Color Maps

Modify the code to use different colormaps:

```python
colors = plt.cm.plasma(np.linspace(0.2, 0.9, len(doses)))  # Plasma colormap
colors = plt.cm.coolwarm(np.linspace(0, 1, len(doses)))    # Cool-warm colormap
```

## Applications

### 1. Process Development
- Optimize lithography recipes
- Characterize new resist materials
- Evaluate scanner performance

### 2. Process Control
- Monitor process stability
- Detect process drift
- Validate process corrections

### 3. Yield Enhancement
- Identify process margins
- Optimize for maximum yield
- Reduce defect density

### 4. Technology Transfer
- Compare processes across fabs
- Validate equipment matching
- Document process capabilities

## References

1. Li, Y., et al. (2019). "EDForest: an efficient and accurate process window model based on random forest." *Proceedings of SPIE - The International Society for Optical Engineering*.

2. Bossung, J. W. (1977). "Projection printing characterization." *Proceedings of SPIE*, Vol. 100, Developments in Semiconductor Microlithography II.

3. Mack, C. A. (2007). *Fundamental Principles of Optical Lithography: The Science of Microfabrication*. Wiley.

## License

MIT License - Feel free to use and modify for your lithography analysis needs.

## Contributing

Contributions are welcome! Areas for enhancement:
- Additional process window metrics
- 3D visualization capabilities
- Integration with lithography simulators
- Machine learning model integration (EDForest implementation)
- Automated report generation

## Contact

For questions, suggestions, or issues, please open an issue on the repository.

---

**Note**: This tool is designed for educational and research purposes. For production lithography applications, validate results against your specific process requirements and equipment capabilities.
