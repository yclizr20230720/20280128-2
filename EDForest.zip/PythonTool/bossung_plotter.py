"""
Bossung Curve Plotter for Lithography Process Window Analysis
==============================================================
This tool generates professional Bossung curves for semiconductor lithography
process window evaluation, based on EDForest methodology.

Bossung curves plot Critical Dimension (CD) vs Defocus for various exposure doses,
enabling visualization of the process window and optimization of lithography parameters.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from scipy.interpolate import interp1d
import seaborn as sns


class BossungPlotter:
    """
    Professional Bossung curve plotter for lithography process window analysis.
    """
    
    def __init__(self, data_file=None, dataframe=None):
        """
        Initialize the Bossung plotter.
        
        Parameters:
        -----------
        data_file : str, optional
            Path to CSV file containing dose-focus-CD data
        dataframe : pd.DataFrame, optional
            DataFrame containing the data directly
        """
        if data_file:
            self.data = pd.read_csv(data_file)
        elif dataframe is not None:
            self.data = dataframe
        else:
            raise ValueError("Either data_file or dataframe must be provided")
        
        # Validate required columns
        required_cols = ['Dose', 'Defocus', 'CD']
        if not all(col in self.data.columns for col in required_cols):
            raise ValueError(f"Data must contain columns: {required_cols}")
        
        self.target_cd = None
        self.cd_tolerance = None
        
    def set_target_specs(self, target_cd, tolerance_percent=10):
        """
        Set target CD and tolerance specifications.
        
        Parameters:
        -----------
        target_cd : float
            Target critical dimension (nm)
        tolerance_percent : float
            Tolerance as percentage of target CD (default: 10%)
        """
        self.target_cd = target_cd
        self.cd_tolerance = target_cd * tolerance_percent / 100
        
    def plot_bossung_curves(self, figsize=(12, 8), style='professional'):
        """
        Generate professional Bossung curves.
        
        Parameters:
        -----------
        figsize : tuple
            Figure size (width, height)
        style : str
            Plot style: 'professional', 'colorful', or 'minimal'
        """
        # Set style
        if style == 'professional':
            plt.style.use('seaborn-v0_8-darkgrid')
            colors = plt.cm.viridis(np.linspace(0.2, 0.9, len(self.data['Dose'].unique())))
        elif style == 'colorful':
            plt.style.use('seaborn-v0_8-bright')
            colors = plt.cm.rainbow(np.linspace(0, 1, len(self.data['Dose'].unique())))
        else:
            plt.style.use('seaborn-v0_8-whitegrid')
            colors = plt.cm.coolwarm(np.linspace(0.2, 0.8, len(self.data['Dose'].unique())))
        
        fig, ax = plt.subplots(figsize=figsize)
        
        # Get unique doses and sort them
        doses = sorted(self.data['Dose'].unique())
        
        # Plot each dose curve
        for idx, dose in enumerate(doses):
            dose_data = self.data[self.data['Dose'] == dose].sort_values('Defocus')
            
            # Plot the curve
            ax.plot(dose_data['Defocus'], dose_data['CD'], 
                   marker='o', markersize=6, linewidth=2.5,
                   color=colors[idx], label=f'{dose:.1f} mJ/cm²',
                   alpha=0.85)
        
        # Add target CD line and tolerance band if specified
        if self.target_cd is not None:
            ax.axhline(y=self.target_cd, color='red', linestyle='--', 
                      linewidth=2, label=f'Target CD: {self.target_cd:.1f} nm', alpha=0.7)
            
            if self.cd_tolerance is not None:
                ax.axhspan(self.target_cd - self.cd_tolerance, 
                          self.target_cd + self.cd_tolerance,
                          alpha=0.15, color='green', 
                          label=f'Tolerance: ±{self.cd_tolerance:.1f} nm')
        
        # Formatting
        ax.set_xlabel('Defocus (μm)', fontsize=14, fontweight='bold')
        ax.set_ylabel('Critical Dimension (nm)', fontsize=14, fontweight='bold')
        ax.set_title('Bossung Curves - Process Window Analysis', 
                    fontsize=16, fontweight='bold', pad=20)
        ax.legend(loc='best', fontsize=10, framealpha=0.9)
        ax.grid(True, alpha=0.3, linestyle='--')
        ax.tick_params(labelsize=11)
        
        plt.tight_layout()
        return fig, ax
    
    def plot_process_window(self, figsize=(12, 8)):
        """
        Generate 2D process window contour plot (Dose vs Defocus with CD contours).
        
        Parameters:
        -----------
        figsize : tuple
            Figure size (width, height)
        """
        fig, ax = plt.subplots(figsize=figsize)
        
        # Create pivot table for contour plot
        pivot_data = self.data.pivot_table(
            values='CD', 
            index='Defocus', 
            columns='Dose'
        )
        
        # Create contour plot
        doses = pivot_data.columns.values
        defocus = pivot_data.index.values
        CD_grid = pivot_data.values
        
        # Contour plot
        contour = ax.contourf(doses, defocus, CD_grid, levels=15, cmap='RdYlGn_r', alpha=0.8)
        contour_lines = ax.contour(doses, defocus, CD_grid, levels=10, colors='black', 
                                   linewidths=0.5, alpha=0.4)
        ax.clabel(contour_lines, inline=True, fontsize=8, fmt='%.1f nm')
        
        # Add colorbar
        cbar = plt.colorbar(contour, ax=ax, label='Critical Dimension (nm)')
        cbar.ax.tick_params(labelsize=10)
        
        # Add target CD contour if specified
        if self.target_cd is not None:
            target_contour = ax.contour(doses, defocus, CD_grid, 
                                       levels=[self.target_cd], 
                                       colors='red', linewidths=3, linestyles='--')
            ax.clabel(target_contour, inline=True, fontsize=10, 
                     fmt=f'Target: {self.target_cd:.1f} nm')
        
        # Formatting
        ax.set_xlabel('Exposure Dose (mJ/cm²)', fontsize=14, fontweight='bold')
        ax.set_ylabel('Defocus (μm)', fontsize=14, fontweight='bold')
        ax.set_title('Process Window - Dose-Focus Matrix', 
                    fontsize=16, fontweight='bold', pad=20)
        ax.grid(True, alpha=0.2, linestyle='--')
        ax.tick_params(labelsize=11)
        
        plt.tight_layout()
        return fig, ax
    
    def calculate_process_window_metrics(self):
        """
        Calculate process window metrics: Depth of Focus (DOF) and Exposure Latitude (EL).
        
        Returns:
        --------
        dict : Dictionary containing DOF, EL, and optimal dose/focus
        """
        if self.target_cd is None or self.cd_tolerance is None:
            raise ValueError("Target CD and tolerance must be set first using set_target_specs()")
        
        # Define acceptable CD range
        cd_min = self.target_cd - self.cd_tolerance
        cd_max = self.target_cd + self.cd_tolerance
        
        # Filter data within tolerance
        in_spec = self.data[
            (self.data['CD'] >= cd_min) & 
            (self.data['CD'] <= cd_max)
        ]
        
        if len(in_spec) == 0:
            return {
                'DOF': 0,
                'EL': 0,
                'optimal_dose': None,
                'optimal_focus': None,
                'message': 'No data points within specification'
            }
        
        # Calculate DOF (range of defocus within spec)
        dof = in_spec['Defocus'].max() - in_spec['Defocus'].min()
        
        # Calculate EL (range of dose within spec)
        el = in_spec['Dose'].max() - in_spec['Dose'].min()
        
        # Find optimal point (center of process window)
        optimal_dose = (in_spec['Dose'].max() + in_spec['Dose'].min()) / 2
        optimal_focus = (in_spec['Defocus'].max() + in_spec['Defocus'].min()) / 2
        
        return {
            'DOF': dof,
            'EL': el,
            'optimal_dose': optimal_dose,
            'optimal_focus': optimal_focus,
            'in_spec_points': len(in_spec),
            'total_points': len(self.data)
        }
    
    def plot_comprehensive_analysis(self, figsize=(18, 10)):
        """
        Generate comprehensive analysis with multiple subplots.
        
        Parameters:
        -----------
        figsize : tuple
            Figure size (width, height)
        """
        fig = plt.figure(figsize=figsize)
        gs = fig.add_gridspec(2, 2, hspace=0.3, wspace=0.3)
        
        # 1. Bossung Curves
        ax1 = fig.add_subplot(gs[0, :])
        doses = sorted(self.data['Dose'].unique())
        colors = plt.cm.viridis(np.linspace(0.2, 0.9, len(doses)))
        
        for idx, dose in enumerate(doses):
            dose_data = self.data[self.data['Dose'] == dose].sort_values('Defocus')
            ax1.plot(dose_data['Defocus'], dose_data['CD'], 
                    marker='o', markersize=5, linewidth=2,
                    color=colors[idx], label=f'{dose:.1f} mJ/cm²', alpha=0.85)
        
        if self.target_cd is not None:
            ax1.axhline(y=self.target_cd, color='red', linestyle='--', 
                       linewidth=2, label=f'Target: {self.target_cd:.1f} nm')
            if self.cd_tolerance is not None:
                ax1.axhspan(self.target_cd - self.cd_tolerance, 
                           self.target_cd + self.cd_tolerance,
                           alpha=0.15, color='green')
        
        ax1.set_xlabel('Defocus (μm)', fontsize=12, fontweight='bold')
        ax1.set_ylabel('CD (nm)', fontsize=12, fontweight='bold')
        ax1.set_title('Bossung Curves', fontsize=14, fontweight='bold')
        ax1.legend(loc='best', fontsize=9, ncol=2)
        ax1.grid(True, alpha=0.3)
        
        # 2. Process Window Contour
        ax2 = fig.add_subplot(gs[1, 0])
        pivot_data = self.data.pivot_table(values='CD', index='Defocus', columns='Dose')
        contour = ax2.contourf(pivot_data.columns, pivot_data.index, pivot_data.values, 
                              levels=15, cmap='RdYlGn_r', alpha=0.8)
        plt.colorbar(contour, ax=ax2, label='CD (nm)')
        ax2.set_xlabel('Dose (mJ/cm²)', fontsize=12, fontweight='bold')
        ax2.set_ylabel('Defocus (μm)', fontsize=12, fontweight='bold')
        ax2.set_title('Process Window', fontsize=14, fontweight='bold')
        ax2.grid(True, alpha=0.2)
        
        # 3. CD Distribution
        ax3 = fig.add_subplot(gs[1, 1])
        ax3.hist(self.data['CD'], bins=20, color='steelblue', alpha=0.7, edgecolor='black')
        if self.target_cd is not None:
            ax3.axvline(x=self.target_cd, color='red', linestyle='--', linewidth=2)
        ax3.set_xlabel('CD (nm)', fontsize=12, fontweight='bold')
        ax3.set_ylabel('Frequency', fontsize=12, fontweight='bold')
        ax3.set_title('CD Distribution', fontsize=14, fontweight='bold')
        ax3.grid(True, alpha=0.3, axis='y')
        
        fig.suptitle('Comprehensive Lithography Process Window Analysis', 
                    fontsize=16, fontweight='bold', y=0.995)
        
        return fig
    
    def save_plots(self, prefix='bossung', formats=['png', 'pdf']):
        """
        Save all plots to files.
        
        Parameters:
        -----------
        prefix : str
            Prefix for output filenames
        formats : list
            List of file formats to save
        """
        # Bossung curves
        fig1, _ = self.plot_bossung_curves()
        for fmt in formats:
            fig1.savefig(f'{prefix}_curves.{fmt}', dpi=300, bbox_inches='tight')
        plt.close(fig1)
        
        # Process window
        fig2, _ = self.plot_process_window()
        for fmt in formats:
            fig2.savefig(f'{prefix}_process_window.{fmt}', dpi=300, bbox_inches='tight')
        plt.close(fig2)
        
        # Comprehensive analysis
        fig3 = self.plot_comprehensive_analysis()
        for fmt in formats:
            fig3.savefig(f'{prefix}_comprehensive.{fmt}', dpi=300, bbox_inches='tight')
        plt.close(fig3)
        
        print(f"Plots saved with prefix '{prefix}' in formats: {formats}")


def generate_mock_data(output_file='lithography_data.csv'):
    """
    Generate realistic mock data for lithography process window analysis.
    
    The data simulates CD measurements across a dose-focus matrix typical
    in semiconductor lithography.
    
    Parameters:
    -----------
    output_file : str
        Output CSV filename
    
    Returns:
    --------
    pd.DataFrame : Generated mock data
    """
    # Define parameter ranges
    doses = np.linspace(18, 26, 9)  # Exposure dose in mJ/cm²
    defocus_values = np.linspace(-0.4, 0.4, 17)  # Defocus in μm
    
    # Target CD and parameters
    target_cd = 45.0  # nm
    
    data_records = []
    
    for dose in doses:
        # Optimal dose is around 22 mJ/cm²
        dose_offset = (dose - 22) * 0.8
        
        for defocus in defocus_values:
            # Bossung curve model: parabolic relationship with defocus
            # CD increases with defocus magnitude (typical behavior)
            cd_base = target_cd + dose_offset
            
            # Parabolic defocus effect
            defocus_effect = 15 * (defocus ** 2)
            
            # Add some asymmetry (typical in real lithography)
            asymmetry = 2 * defocus if defocus > 0 else 1.5 * defocus
            
            # Calculate CD with noise
            cd = cd_base + defocus_effect + asymmetry + np.random.normal(0, 0.3)
            
            data_records.append({
                'Dose': dose,
                'Defocus': defocus,
                'CD': cd,
                'Wafer_ID': 'W001',
                'Field': 'Center'
            })
    
    df = pd.DataFrame(data_records)
    df.to_csv(output_file, index=False)
    print(f"Mock data generated: {output_file}")
    print(f"Data shape: {df.shape}")
    print(f"\nData preview:")
    print(df.head(10))
    print(f"\nDose range: {df['Dose'].min():.1f} - {df['Dose'].max():.1f} mJ/cm²")
    print(f"Defocus range: {df['Defocus'].min():.2f} - {df['Defocus'].max():.2f} μm")
    print(f"CD range: {df['CD'].min():.2f} - {df['CD'].max():.2f} nm")
    
    return df


if __name__ == "__main__":
    # Generate mock data
    print("=" * 70)
    print("Bossung Curve Plotter - Lithography Process Window Analysis")
    print("=" * 70)
    print()
    
    mock_data = generate_mock_data('lithography_data.csv')
    
    print("\n" + "=" * 70)
    print("Generating Bossung Curves...")
    print("=" * 70)
    
    # Create plotter instance
    plotter = BossungPlotter(data_file='lithography_data.csv')
    
    # Set target specifications
    target_cd = 45.0  # nm
    tolerance = 10  # ±10%
    plotter.set_target_specs(target_cd, tolerance)
    
    # Calculate process window metrics
    metrics = plotter.calculate_process_window_metrics()
    print("\nProcess Window Metrics:")
    print(f"  Depth of Focus (DOF): {metrics['DOF']:.3f} μm")
    print(f"  Exposure Latitude (EL): {metrics['EL']:.2f} mJ/cm²")
    print(f"  Optimal Dose: {metrics['optimal_dose']:.2f} mJ/cm²")
    print(f"  Optimal Focus: {metrics['optimal_focus']:.3f} μm")
    print(f"  Points in spec: {metrics['in_spec_points']}/{metrics['total_points']}")
    
    # Generate and display plots
    print("\nGenerating plots...")
    
    # Individual plots
    fig1, ax1 = plotter.plot_bossung_curves(style='professional')
    fig2, ax2 = plotter.plot_process_window()
    fig3 = plotter.plot_comprehensive_analysis()
    
    # Save plots
    plotter.save_plots(prefix='bossung_analysis', formats=['png', 'pdf'])
    
    print("\n" + "=" * 70)
    print("Analysis complete! Plots have been saved.")
    print("=" * 70)
    
    plt.show()
