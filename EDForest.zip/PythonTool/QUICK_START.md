# Quick Start Guide - Bossung Curve Plotter

## Installation

```bash
# Install required packages
pip install -r requirements.txt
```

## Basic Usage (3 Steps)

### Step 1: Generate Mock Data (or use your own)

```python
from bossung_plotter import generate_mock_data

# Generate sample lithography data
data = generate_mock_data('my_data.csv')
```

### Step 2: Create Plots

```python
from bossung_plotter import BossungPlotter

# Initialize plotter
plotter = BossungPlotter(data_file='my_data.csv')

# Set target specifications
plotter.set_target_specs(target_cd=45.0, tolerance_percent=10)

# Generate Bossung curves
plotter.plot_bossung_curves()

# Generate process window
plotter.plot_process_window()
```

### Step 3: Analyze Results

```python
# Calculate process window metrics
metrics = plotter.calculate_process_window_metrics()

print(f"Depth of Focus: {metrics['DOF']:.3f} μm")
print(f"Exposure Latitude: {metrics['EL']:.2f} mJ/cm²")
print(f"Optimal Dose: {metrics['optimal_dose']:.2f} mJ/cm²")
```

## Run Demo

```bash
# Basic demo
python bossung_plotter.py

# Advanced analysis
python advanced_analysis.py

# Multiple examples
python example_usage.py
```

## Your Own Data

Create a CSV file with these columns:

```csv
Dose,Defocus,CD
18.0,-0.4,52.3
18.0,-0.3,49.8
20.0,-0.4,50.8
...
```

Then load it:

```python
plotter = BossungPlotter(data_file='your_data.csv')
```

## Output Files

After running, you'll get:

- **Bossung curves**: CD vs Defocus for each dose
- **Process window**: 2D contour map
- **Comprehensive analysis**: Multi-panel report
- **Metrics**: DOF, EL, optimal settings

## Key Features

✓ Professional publication-quality plots  
✓ Process window quantification (DOF, EL)  
✓ Multiple plot styles and formats  
✓ Advanced curve fitting and analysis  
✓ Automated report generation  

## Need Help?

See `README.md` for detailed documentation.

## Example Output

The tool generates:
- `bossung_curves.png/pdf` - Main Bossung curves
- `process_window.png/pdf` - 2D process window map
- `comprehensive.png/pdf` - Complete analysis report

## Advanced Features

For advanced analysis including curve fitting and sensitivity analysis:

```python
from advanced_analysis import AdvancedBossungAnalysis

analyzer = AdvancedBossungAnalysis(plotter)
analyzer.print_report()
analyzer.plot_dose_sensitivity()
analyzer.plot_best_focus_vs_dose()
```

## Tips

1. **Target CD**: Set this to your design target (e.g., 45 nm)
2. **Tolerance**: Typical values are 5-10% of target CD
3. **Dose Range**: Usually 15-30 mJ/cm² for DUV lithography
4. **Defocus Range**: Typically ±0.3 to ±0.5 μm

## Troubleshooting

**Issue**: No plots showing  
**Solution**: Add `plt.show()` at the end or check saved files

**Issue**: Import errors  
**Solution**: Run `pip install -r requirements.txt`

**Issue**: CSV format error  
**Solution**: Ensure columns are named: Dose, Defocus, CD

---

**Ready to analyze your lithography data!** 🎯
