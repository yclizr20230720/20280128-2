# VSMC Litho Platform - Project Structure

## Overview
Modern web-based lithography analysis platform for Scanner, Track, and Litho Process/Equipment data analysis.

## Technology Stack
- **Frontend**: React + Vite + TailwindCSS + Recharts
- **Backend**: Python Flask + Flask-CORS
- **Analysis**: NumPy, Pandas, Matplotlib, SciPy
- **Deployment**: Docker (optional)

## Project Structure

```
vsmc-litho-platform/
├── frontend/                      # React + Vite Frontend
│   ├── public/
│   │   ├── logo.svg              # VSMC Litho Platform Logo
│   │   └── favicon.ico
│   ├── src/
│   │   ├── assets/               # Images, icons, styles
│   │   │   ├── logo.svg
│   │   │   └── tool-icons/
│   │   ├── components/           # Reusable components
│   │   │   ├── Header.jsx
│   │   │   ├── Footer.jsx
│   │   │   ├── ToolCard.jsx
│   │   │   ├── Sidebar.jsx
│   │   │   └── LoadingSpinner.jsx
│   │   ├── pages/                # Page components
│   │   │   ├── Home.jsx          # Main portal page
│   │   │   ├── EDForest.jsx      # Bossung curve tool
│   │   │   ├── About.jsx
│   │   │   └── NotFound.jsx
│   │   ├── services/             # API services
│   │   │   └── api.js
│   │   ├── utils/                # Utility functions
│   │   │   └── helpers.js
│   │   ├── App.jsx               # Main app component
│   │   ├── main.jsx              # Entry point
│   │   └── index.css             # Global styles
│   ├── package.json
│   ├── vite.config.js
│   └── tailwind.config.js
│
├── backend/                       # Python Flask Backend
│   ├── app/
│   │   ├── __init__.py           # Flask app initialization
│   │   ├── routes/               # API routes
│   │   │   ├── __init__.py
│   │   │   ├── edforest.py       # EDForest/Bossung endpoints
│   │   │   └── health.py         # Health check
│   │   ├── services/             # Business logic
│   │   │   ├── __init__.py
│   │   │   └── bossung_service.py
│   │   ├── models/               # Data models
│   │   │   └── __init__.py
│   │   └── utils/                # Utility functions
│   │       ├── __init__.py
│   │       └── file_handler.py
│   ├── uploads/                  # Temporary file uploads
│   ├── outputs/                  # Generated plots/reports
│   ├── requirements.txt
│   ├── config.py                 # Configuration
│   └── run.py                    # Application entry point
│
├── shared/                        # Shared resources
│   └── docs/
│       ├── API.md                # API documentation
│       └── USER_GUIDE.md         # User guide
│
├── docker/                        # Docker configuration
│   ├── Dockerfile.frontend
│   ├── Dockerfile.backend
│   └── docker-compose.yml
│
├── README.md                      # Project README
└── .gitignore
```

## Tool Cards on Home Page

### 1. EDForest - Bossung Curve Analysis
- **Icon**: 📊 Chart with curves
- **Description**: Generate professional Bossung curves and analyze process windows (DOF, EL)
- **Features**: Upload CSV, Interactive plots, Process metrics

### 2. Focus-Exposure Matrix (FEM) Analysis
- **Icon**: 🎯 Target grid
- **Description**: Analyze dose-focus matrices for optimal lithography conditions
- **Features**: Contour maps, Optimal point detection

### 3. CD Uniformity Analysis
- **Icon**: 📏 Ruler
- **Description**: Evaluate critical dimension uniformity across wafer
- **Features**: Wafer maps, Statistical analysis, Trend charts

### 4. Overlay Analysis
- **Icon**: 🔄 Overlapping circles
- **Description**: Analyze overlay performance and alignment accuracy
- **Features**: Vector plots, CPK analysis, Trend monitoring

### 5. Scanner Performance Monitor
- **Icon**: 🔬 Microscope
- **Description**: Real-time scanner performance tracking and diagnostics
- **Features**: Live dashboards, Alert system, Historical trends

### 6. Track Equipment Monitor
- **Icon**: ⚙️ Gear
- **Description**: Monitor track equipment parameters and performance
- **Features**: Temperature/humidity tracking, Maintenance alerts

### 7. Defect Analysis
- **Icon**: 🔍 Magnifying glass
- **Description**: Analyze defect patterns and root cause analysis
- **Features**: Pareto charts, Spatial analysis, Classification

### 8. Yield Prediction
- **Icon**: 📈 Trending up
- **Description**: Predict yield based on process parameters using ML
- **Features**: ML models, What-if analysis, Recommendations

## Color Scheme (VSMC Litho Platform)

- **Primary**: #2563EB (Blue - Technology, Trust)
- **Secondary**: #7C3AED (Purple - Innovation)
- **Accent**: #10B981 (Green - Success, Process)
- **Background**: #F9FAFB (Light gray)
- **Text**: #1F2937 (Dark gray)
- **Card**: #FFFFFF with shadow

## Key Features

1. **Responsive Design**: Works on desktop, tablet, mobile
2. **Dark Mode**: Toggle between light/dark themes
3. **Real-time Updates**: WebSocket for live data
4. **Export Options**: PNG, PDF, CSV, Excel
5. **User Authentication**: Role-based access (future)
6. **Data Security**: Encrypted uploads, secure API
7. **Performance**: Lazy loading, code splitting
8. **Accessibility**: WCAG 2.1 AA compliant
