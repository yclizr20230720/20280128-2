# VSMC Litho Platform - PowerShell Launcher
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "VSMC Litho Platform - Starting All Services" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This will start:" -ForegroundColor Yellow
Write-Host "  1. Backend API (Port 5000)" -ForegroundColor Green
Write-Host "  2. Frontend Web App (Port 5173/5174)" -ForegroundColor Green
Write-Host ""
Write-Host "Two terminal windows will open." -ForegroundColor Yellow
Write-Host "Close them to stop the services." -ForegroundColor Yellow
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""

# Start backend in new window
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PSScriptRoot\backend'; .\venv\Scripts\Activate.ps1; python run.py" -WindowStyle Normal

# Wait 3 seconds for backend to start
Write-Host "Starting Backend..." -ForegroundColor Yellow
Start-Sleep -Seconds 3

# Start frontend in new window
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PSScriptRoot\frontend'; npm run dev" -WindowStyle Normal

Write-Host ""
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "Services are starting..." -ForegroundColor Green
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Backend API:     http://localhost:5000" -ForegroundColor Green
Write-Host "Frontend App:    http://localhost:5174" -ForegroundColor Green
Write-Host ""
Write-Host "Opening browser in 5 seconds..." -ForegroundColor Yellow
Write-Host "======================================================================" -ForegroundColor Cyan

# Wait 5 seconds then open browser
Start-Sleep -Seconds 5
Start-Process "http://localhost:5174"

Write-Host ""
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "VSMC Litho Platform is now running!" -ForegroundColor Green
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "To stop: Close the two PowerShell windows that opened" -ForegroundColor Yellow
Write-Host ""
Write-Host "Press any key to exit this window..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
